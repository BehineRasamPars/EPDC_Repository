import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import QgsFeature, QgsPoint, QgsPointXY, QgsGeometry, QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from .feature_inserter import FeatureInserter
from math import atan2,degrees
import math
from math import sin, cos, radians, pi
import numpy as np

class DrawLineAndPoint2(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas, lineLayerName, pointLayerName,DRAWING_ORDER=None):
        print("Starting DrawTwoPointsLine...", lineLayerName)
        self.canvas = canvas
        self.DRAWING_ORDER = DRAWING_ORDER
        self.lineLayerName = lineLayerName
        self.pointLayerName = pointLayerName
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubberBand.setColor(Qt.red)
        self.rubberBand.setWidth(3)
        self.snapIndicator = QgsSnapIndicator(canvas)
        self.snapper = self.canvas.snappingUtils()
        self.reset()

    def reset(self):
        self.startPoint = self.endPoint = None
        self.midPoint = None
        self.isEmittingPoint = False
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        snapMatch = self.snapper.snapToMap(event.pos())
        self.snapIndicator.setMatch(snapMatch)
        self.snapPoint = snapMatch.point()
        if self.startPoint is None:
            return
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        if not self.midPoint is None:
            self.showRubber(self.startPoint, point, self.midPoint)
        else:
            self.showRubber(self.startPoint, point)
        # self.rubberBand.setGeometry([self.startPoint,event])

    def canvasReleaseEvent(self, event):
        # Get the click
        point = QgsPointXY(self.snapPoint.x(), self.snapPoint.y())
        if self.snapPoint.x() == 0.0 and self.snapPoint.y() == 0.0:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        if self.startPoint is None:
            self.startPoint = point
            self.endPoint = self.startPoint
            self.isEmittingPoint = True
        elif self.midPoint is None:
            self.midPoint = point
            self.endPoint = self.midPoint
            self.isEmittingPoint = True
        else:
            self.endPoint = point
            self.isEmittingPoint = False
            self.showRubber(self.startPoint, self.endPoint)
            self.insertFeature()

    def AngleBtw2Points(self,pointA, pointB):
        changeInX = pointB.x() - pointA.x()
        changeInY = pointB.y() - pointA.y()
        return degrees(atan2(changeInY,changeInX))
  
    def AngleBtw2Points2(self, pointA, pointB):
        TheAngle = self.AngleBtw2Points(pointA, pointB)
        if TheAngle >= 0:
            PointAngle = 360-TheAngle
        else:
            PointAngle = 180-TheAngle
        return PointAngle

    def angleOfPoints_rad(self, p1, p2):
        xDiff = p2.x() - p1.x()
        yDiff = p2.y() - p1.y()
        return atan2(yDiff, xDiff)

    def movePoint(self, point, angle, dist):
        angle += pi/2
        xx = point.x() + (dist * math.cos(angle))
        yy = point.y() + (dist * math.sin(angle))
        return QgsPoint(xx, yy)

    def pointDist(self, p1, p2):
        dist = math.hypot(p2.x() - p1.x(), p2.y() - p1.y())
        return dist

    def pointMiddle(self, p1, p2):
        return QgsPoint((p1.x() + p2.x())/2, (p1.y() + p2.y())/2)


    def insertFeature(self):
        self.showRubber(self.startPoint, self.endPoint, self.midPoint)
        self.rubberBand.hide()

        middlePoint = QgsPoint( (self.startPoint.x()+self.endPoint.x())/2 , (self.startPoint.y()+self.endPoint.y())/2)

        angle_rad = self.angleOfPoints_rad(self.endPoint, self.startPoint)
        if self.isInside(middlePoint.x(), middlePoint.y(), 0.1, self.midPoint.x(), self.midPoint.y()):
            self.midPoint = middlePoint
        elif not self.isInside(middlePoint.x(), middlePoint.y(), 0.7, self.midPoint.x(), self.midPoint.y()):
            mid1 = self.movePoint(middlePoint, angle_rad, 1)
            mid2 = self.movePoint(middlePoint, angle_rad + pi, 1)
            if self.pointDist(self.midPoint, mid1) < self.pointDist(self.midPoint, mid2):
                self.midPoint = mid1
            else:
                self.midPoint = mid2
        else:
            mid1 = self.movePoint(middlePoint, angle_rad, 0.6)
            mid2 = self.movePoint(middlePoint, angle_rad + pi, 0.6)
            if self.pointDist(self.midPoint, mid1) < self.pointDist(self.midPoint, mid2):
                self.midPoint = mid1
            else:
                self.midPoint = mid2

        switchLinePoint1 = self.movePoint(self.midPoint, angle_rad + pi / 2, 0.3)
        switchLinePoint2 = self.movePoint(self.midPoint, angle_rad + pi + pi / 2, 0.3)

        if self.pointDist(switchLinePoint1, self.startPoint) > self.pointDist(switchLinePoint1, self.endPoint):
            x = switchLinePoint2
            switchLinePoint2 = switchLinePoint1
            switchLinePoint1 = x

        FeatureInserter(self.canvas, 'Point', self.pointLayerName, [self.midPoint], self.AngleBtw2Points2(self.startPoint,self.endPoint))

        if self.pointLayerName in [ 'mv_jumpr', 'lv_jumper' ]:
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [self.startPoint, switchLinePoint1, self.midPoint],None,-17)
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [self.midPoint, switchLinePoint2, self.endPoint],None,-17)
        elif self.pointLayerName in [ 'cut_out', 'sectionalizer', 'recloser', 'discnt_s' ]:
            mid1 = self.pointMiddle(self.startPoint, switchLinePoint1)
            mid2 = self.pointMiddle(switchLinePoint2, self.endPoint)
            # ang = (self.AngleBtw2Points2(self.startPoint, mid1) + 90) % 360
            ang = self.AngleBtw2Points2(self.startPoint, mid1)
            FeatureInserter(self.canvas, 'Point', 'mv_jumpr', [mid1], ang)
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [self.startPoint, mid1],None,-17)
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [mid1, switchLinePoint1, self.midPoint],None,-17)
            ang = self.AngleBtw2Points2(self.endPoint, mid2) % 360
            FeatureInserter(self.canvas, 'Point', 'mv_jumpr', [mid2], ang)
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [mid2, self.endPoint],None,-17)
            FeatureInserter(self.canvas, 'LineString', self.lineLayerName, [mid2, switchLinePoint2, self.midPoint],None,-17)
        else:
            pass

        self.reset()

    def isInside(self, circle_x, circle_y, rad, x, y):
        if ((x - circle_x) * (x - circle_x) +
            (y - circle_y) * (y - circle_y) <= rad * rad):
            return True
        else:
            return False

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, startPoint, endPoint, midPoint = None):
        self.rubberBand.reset(QgsWkbTypes.LineGeometry)
        # point1 = QgsPoint(startPoint.x(), startPoint.y())
        self.rubberBand.addPoint(startPoint)
        if midPoint:
            self.rubberBand.addPoint(midPoint)
        self.rubberBand.addPoint(endPoint)
        self.rubberBand.show()