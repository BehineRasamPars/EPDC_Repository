import functools
from qgis.PyQt.QtWidgets import QAction, QMenu, QFrame, QGridLayout, QPushButton, QDockWidget, QWidget , QLabel
from .rassam import *
from .mylib import *
from qgis.utils import iface
from .auto_draw import *
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from functools import partial
import json
from qgis.core import QgsFeature,QgsFeatureRequest, QgsVectorLayer, QgsRectangle, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes, QgsEditFormConfig
import math
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsMapTip, QgsAttributeDialog, QgsAttributeForm, QgsAttributeEditorContext



class QHLine(QFrame):
    def __init__(self):
        super(QHLine, self).__init__()
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Sunken)


class App:

    lastChosenDraw = None

    def __init__(self, dBConnection, ref):
        self.dBConnection = dBConnection
        self.ref = ref
        self.addPanel()
        self.addSignals()


    def addSignals(self):
        layer1 = get_layer_by_tablename('subscriber_cable')
        layer1.featureAdded.connect(self.subsAdded)
    def remSignals(self):
        layer1 = get_layer_by_tablename('subscriber_cable')
        layer1.featureAdded.disconnect()


    def subsAdded(self, featId):

        if self.lastChosenDraw == 'sub_with_cable':

            layer1 = get_layer_by_tablename('subscriber_cable')
            layer2 = get_layer_by_tablename('no_subscribers')

            feat = layer1.getFeature(featId)
            pointLen = len(feat.geometry().asPolyline())
            point2 = feat.geometry().vertexAt(pointLen-1)
            angle = feat.geometry().angleAtVertex(pointLen-1)
            layer1.updateFeature(feat)

            # ERROR
            fet = QgsFeature()
            fet.setFields(layer2.fields())
            fields = layer2.fields()
            fet.initAttributes(fields.count())   
            provider = layer2.dataProvider()              
            for i in range(fields.count()):
                fet.setAttribute(i, provider.defaultValue(i))
            fet.setGeometry(point2)
            fet['angle'] = (math.degrees(angle) + 90) % 360
            layer2.startEditing()
            layer2.addFeature(fet)
            layer2.reload()
            layer2.endEditCommand()
            layer2.updateExtents()


            # layer = layer2
            # feature = QgsFeature()
            # fields = layer2.fields()
            # feature.setGeometry(point2)
            # feature.initAttributes(fields.count())            
            # provider = layer.dataProvider()              
            # for i in range(fields.count()):
            #     print(feature[i])
            #     feature.setAttribute(i, provider.defaultValue(i))                
            # form = QgsAttributeDialog(layer, feature, False)
            # form.setMode(int(QgsAttributeForm.AddFeatureMode))
            # formSuppress = layer.editFormConfig().suppress()
            # if formSuppress == QgsEditFormConfig.SuppressDefault:
            #     if False: #this is calculated every time because user can switch options while using tool
            #     # if self.getSuppressOptions(): #this is calculated every time because user can switch options while using tool
            #         layer.addFeature(feature, True)
            #     else:
            #         if not form.exec_():
            #             feature.setAttributes(form.feature().attributes())
            # elif formSuppress == QgsEditFormConfig.SuppressOff:
            #     if not form.exec_():
            #         feature.setAttributes(form.feature().attributes())
            # else:
            #     layer.addFeature(feature, True)
            # layer.endEditCommand()
            # self.canvas.refresh()
            # self.initVariable()  



    def addPanel(self):
        self.dock = QDockWidget('ابزار ترسیم', iface.mainWindow())
        iface.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.dock)
        self.dock.setFloating(False)
        self.layout = QGridLayout()
        self.layout.setSpacing(2)
        multiWidget = QWidget()
        multiWidget.setLayout(self.layout)
        self.dock.setWidget(multiWidget)
        self.selected_btn_details_place()


    def selected_btn_details_place(self):
        icon_addr = getAppDir() + '/icons/question.png'
        self.q_btn = self.getPanelItem(icon_addr , '')
        self.layout.addWidget(self.q_btn, 0, 0)
        self.header_label = self.getHeaderLabel("عارضه ی انتخابی")
        self.layout.addWidget(self.header_label, 0, 1,1,3)
        self.panelNewLine()
        self.header_name = self.getHeaderLabel("هیچ عارضه ای انتخاب نشده است" , True)
        self.header_name.setAlignment(QtCore.Qt.AlignCenter)
        self.header_name.setWordWrap(True)
        self.header_name.setFixedHeight(40)
        self.layout.addWidget(self.header_name, 1, 0,1,4)
        self.addPanelLine()

    def getHeaderLabel(self, text , title=False):
        label = QLabel(text)
        if title:
            label.setStyleSheet("""
                QLabel {
                    font-family: B Nazanin;
                    text-align: center;
                    border : 1px solid #adadad;
                    padding:2px;
                    width : 100%;
                    font-size : 12px;
                    display: block;
                    background-color: white;
                }
                """)
        else :
            label.setStyleSheet("""
                QLabel {
                    font-family: B Nazanin;
                    text-align: right;
                    border : 1px solid #adadad;
                    padding : 2px;
                    width : 75%;
                    height : 25px;
                    max-height: 25px;
                    background-color: white;
                    font-weight: bold;
                    padding: 2px;
                    font-size : 16px;
                }
                """)
        return label

    def change_header_details(self , item_icon , item_text):
        self.header_name.setText(item_text)
        self.q_btn = self.getPanelItem(item_icon , item_text)
        self.layout.addWidget(self.q_btn, 0, 0)

    def removePanel(self):
        iface.removeDockWidget(self.dock)


    def addFeature(self, tableName, icon_addr,name = None):
        self.change_header_details(icon_addr,name)
        self.lastChosenDraw = name
        layer = get_layer_by_tablename(tableName)
        if layer:
            iface.setActiveLayer(layer)
            layer.startEditing()
            iface.actionAddFeature().trigger()


    def getPanelItem(self, icon, name):
        button = QPushButton()
        button.setStyleSheet("""
            QPushButton {
                border: 1px solid #adadad;
                background: white;
                width: 25;
                display: inline-block;
                padding: 2px;
                
            }
            QPushButton::hover {
                border: 2px solid #3d61ff;
            }
            """)
        button.setAutoFillBackground(True)
        button.setIcon(QIcon(icon))
        button.setIconSize(QtCore.QSize(25, 25))
        button.setToolTip(name)
        button.setFocusPolicy(QtCore.Qt.NoFocus)
        return button


    panelCurr = [2, 0]
    def addToPanel(self, item):
        self.layout.addWidget(item, self.panelCurr[0], self.panelCurr[1])
        if self.panelCurr[1] == 3:
            self.newPanelRow()
        else:
            self.panelCurr[1] += 1
    def newPanelRow(self):
        self.panelCurr[0] += 1
        self.panelCurr[1] = 0
    def addPanelLine(self):
        self.newPanelRow()
        self.layout.addWidget(QHLine(), self.panelCurr[0], self.panelCurr[1], 1,4)
        self.newPanelRow()
    def panelNewLine(self):
        if self.panelCurr[1] != 0:
            self.panelCurr[0] += 1
            self.panelCurr[1] = 0


    def check_panel_status(self, item):
        if len(item) > 3 :
            return item[3]
        return True
    def addToMenus(self, menu, data, level = 0):

        if not data:
            return
           
        for i, item1 in enumerate(data):
            
            if item1[0] == 'menu':

                if i != 0 and level == 0:
                    self.addPanelLine()

                if len(item1[1]) == 1:
                    menuName = self.dBConnection.translate2_table(item1[1][0])
                else:
                    menuName = item1[1][1]

                menu[item1[1][0]] = {}
                menu[item1[1][0]]['_'] = QMenu(menuName, menu['_'])

                icon = getAppDir() + '/icons/' + item1[1][0] + '.png'
                if os.path.exists(icon):
                    menu[item1[1][0]]['_'].setIcon(QIcon(icon))

                menu['_'].insertMenu(None, menu[item1[1][0]]['_'])

                self.addToMenus(menu[item1[1][0]], item1[2], level + 1)

                if level != 0:
                    button = self.getPanelItem(icon, menuName)
                    button.setMenu(menu[item1[1][0]]['_'])
                    self.addToPanel(button)

            if item1[0] == 'separator':
                menu['_'].addSeparator()

            if item1[0] == 'panel_newline':
                self.panelNewLine()

            if item1[0] == 'item':
                panel_status = self.check_panel_status(item1)
                if item1[1] in [ 'line', 'point', 'poly' ]:
                    self.addToMenuSimple(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'linepoint':
                    self.addMenuItem_linepoint(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'pp':
                    self.addMenuItem_pointpoint(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'pl':
                    self.addMenuItem_pl(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'pd':
                    self.addMenuItem_pd(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'shlt':
                    self.addMenuItem_shlt(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'auto':
                    self.addMenuItem_auto(menu['_'], item1[2], level == panel_status)
                elif item1[1] == 'sub_with_cable':
                    self.addMenuItem_subWithCable(menu['_'], level == panel_status)


    def addToMenuSimple(self, menu, item, addToPanel = True):

        trans = self.dBConnection.translate2_table(item)
        if trans:
            menuName = trans
        else:
            menuName = item
        icon = getAppDir() + '/icons/' + item + '.png'
        if not os.path.exists(icon):
            icon = None
        self.action = QAction(QIcon(icon), menuName, iface.mainWindow())
        self.action.triggered.connect(
            lambda val1,val2=item: self.addFeature(val2,icon,trans)
        )
        menu.addAction(self.action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, menuName)
            button.clicked.connect(
                lambda val1,val2=item: self.addFeature(val2,icon,trans)
            )
            self.addToPanel(button)


    def addMenuItem_auto(self, menu, item, addToPanel = True):

        icon = getAppDir() + '/icons/' + item[2] + '.png'
        action = QAction(QIcon(icon), item[3], iface.mainWindow())
        action.triggered.connect(functools.partial(self.ref.startDrawAuto, item[0], item[1] , icon , item[3]))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, item[3])
            button.clicked.connect(functools.partial(self.ref.startDrawAuto, item[0], item[1] , icon, item[3]))
            self.addToPanel(button)


    def addMenuItem_linepoint(self, menu, item, addToPanel = True):
        
        if len(item) >= 3 and item[2]:
            dispName = item[1]
        else:
            dispName = item[0]
        icon = getAppDir() + '/icons/' + dispName + '.png'
        main_icon = getAppDir() + '/icons/' + item[0] + '.png'
        menuName = self.dBConnection.translate2_table(dispName)
        action = QAction(QIcon(icon), menuName, iface.mainWindow())
        fpoint = self.dBConnection.translate2_table(item[1])
        fline = self.dBConnection.translate2_table(item[0])
        if len(item) == 4:
            action.triggered.connect(functools.partial(self.ref.createLinePointFeature, item[1], item[0] , main_icon ,fpoint,fline,item[3]))
        else:    
            action.triggered.connect(functools.partial(self.ref.createLinePointFeature, item[0], item[1], main_icon  ,fpoint,fline))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, menuName)
            if len(item) == 4:
                button.clicked.connect(functools.partial(self.ref.createLinePointFeature, item[1], item[0] ,main_icon,fpoint,fline, item[3]))
            else:
                button.clicked.connect(functools.partial(self.ref.createLinePointFeature, item[0], item[1],main_icon ,fpoint,fline))
            self.addToPanel(button)

    def addMenuItem_pointpoint(self, menu, item, addToPanel = True):
        dispName = '{} و {}'.format(item[0], item[1])
        icon = getAppDir() + '/icons/' + item[0] + '_' + item[1] + '.png'
        main_icon = getAppDir() + '/icons/' + item[0] + '_' + item[1] + '.png'
        menuName = self.getAllPointName(item)
        action = QAction(QIcon(icon), menuName, iface.mainWindow())
        fpoint1 = self.dBConnection.translate2_table(item[1])
        fpoint2 = self.dBConnection.translate2_table(item[0]) 
        action.triggered.connect(functools.partial(self.ref.createTwoPointFeature, item[0], item[1], main_icon  ,fpoint1,fpoint2))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, menuName)
            button.clicked.connect(functools.partial(self.ref.createTwoPointFeature, item[0], item[1],main_icon ,fpoint1,fpoint2))
            self.addToPanel(button)

    def addMenuItem_pl(self, menu, item, addToPanel = True):

        icon = getAppDir() + '/icons/pl_mdsub_wizard.png'
        action = QAction(QIcon(icon), item, iface.mainWindow())
        action.triggered.connect(functools.partial(lambda : self.ref.runPoleSubstationWizardDialog(icon , item)))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, item)
            button.clicked.connect(functools.partial(lambda : self.ref.runPoleSubstationWizardDialog(icon , item)))
            self.addToPanel(button)

    def addMenuItem_shlt(self, menu, item, addToPanel = True):

        icon = getAppDir() + '/icons/pd_mdsub_wizard.png'
        action = QAction(QIcon(icon), item, iface.mainWindow())
        action.triggered.connect(functools.partial(lambda : self.ref.runShulterSubstationWizardDialog(icon , item)))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, item)
            button.clicked.connect(functools.partial(lambda : self.ref.runShulterSubstationWizardDialog(icon , item)))
            self.addToPanel(button)


    def addMenuItem_pd(self, menu, item, addToPanel = True):

        icon = getAppDir() + '/icons/pd_mdsub_wizard.png'
        action = QAction(QIcon(icon), item, iface.mainWindow())
        action.triggered.connect(functools.partial(lambda : self.ref.runPadSubstationWizardDialog(icon , item)))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, item)
            button.clicked.connect(functools.partial(lambda : self.ref.runPadSubstationWizardDialog(icon , item)))
            self.addToPanel(button)


    def addMenuItem_subWithCable(self, menu, addToPanel = True):

        item = 'subscriber_cable'
        name = 'کابل سرویس و جعبه کنتور'

        icon = getAppDir() + '/icons/sub_with_cable.png'
        action = QAction(QIcon(icon), name, iface.mainWindow())
        action.triggered.connect(functools.partial(self.addFeature, item, icon,'sub_with_cable'))
        menu.addAction(action)

        if addToPanel and icon:
            button = self.getPanelItem(icon, name)
            button.clicked.connect(functools.partial(self.addFeature, item, icon,'sub_with_cable'))
            self.addToPanel(button)

    def getAllPointName(self, item):
        menuName = self.dBConnection.translate2_table(item[0])
        menuName += ' و {}'.format(self.dBConnection.translate2_table(item[1]))
        return menuName

class Auto_GUI(QtWidgets.QDialog):

    selectedTable = None
    fieldTypes = {}
    tables = []
    linearClass = None
    pointClassArray = None

    def __init__(self, app, linearClass, pointClassArray):
        super().__init__()
        self.app = app
        self.linearClass = linearClass
        self.pointClassArray = pointClassArray
        with open(getAppDir() + '/data/auto_fields.json') as json_file:
            self.auto_fields = json.load(json_file)
        self.tables = []
        self.isOnePoint = False
        if 'no_subscribers' in self.pointClassArray:
            self.isOnePoint = True
        self.initUI()


    def draw(self):
        self.saveUserVals()
        self.app.ref.drawAuto(self.linearClass, self.pointClassArray, self.tables)
        self.close()


    def initUI(self):
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.listTables()
        self.ui.layers.itemSelectionChanged.connect(self.listCols)
        self.ui.draw.clicked.connect(self.draw)
        self.ui.featureVals.cellChanged.connect(self.updateNames)
        self.show()


    def listTables(self):
        for table in [self.linearClass] + self.pointClassArray:
            self.fieldTypes[table] = self.app.dBConnection.getTableFieldTypes(table)
            
            name_fa = self.app.dBConnection.translate2_table(table)
            if table not in self.pointClassArray :
                self.addTable(table, name_fa, None)
            elif self.isOnePoint :
                self.addTable(table, name_fa + '', 1)
            else:
                self.addTable(table, name_fa + ' - میانی', 2)
                self.addTable(table, name_fa + ' - انتهایی', 1)


    def addTable(self, tableName, name_fa, note):
        layer = get_layer_by_tablename(tableName)
        field_names = [field.name() for field in layer.fields()]
        item = QtWidgets.QListWidgetItem(name_fa)
        self.ui.layers.addItem(item)
        ind = len(self.tables)
        self.tables.append([])
        self.tables[ind] = { 'name': tableName, 'vals': {}, 'note': note }
        for field in field_names:
            if self.app.dBConnection.translate2_field(tableName, field):
                if field in self.auto_fields['ALL']:
                    self.tables[ind]['vals'][field] = None
                elif tableName in self.auto_fields.keys() and field in self.auto_fields[tableName]:
                    self.tables[ind]['vals'][field] = None


    def saveUserVals(self):
        if not self.selectedTable is None:
            for row, field in enumerate(self.tables[self.selectedTable]['vals'].keys()):
                if self.fieldTypes[self.tables[self.selectedTable]['name']][field]['data_type'] == 'USER-DEFINED':
                    value = self.ui.featureVals.cellWidget(row, 1).currentText()
                else:
                    value = self.ui.featureVals.item(row, 1).text()
                self.tables[self.selectedTable]['vals'][field] = value

    def listCols(self):

        if self.ui.layers.selectedItems():
            self.saveUserVals()

            while self.ui.featureVals.rowCount() > 0:
                self.ui.featureVals.removeRow(0)

            self.selectedTable = self.ui.layers.currentRow()

            self.ui.featureVals.setRowCount(len(self.tables[self.selectedTable]['vals']))
            for i, field in enumerate(self.tables[self.selectedTable]['vals'].keys()):
                fieldName = self.app.dBConnection.translate2_field(self.tables[self.selectedTable]['name'], field)
                item = QtWidgets.QTableWidgetItem(fieldName)
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
                self.ui.featureVals.setItem(i, 0, item)
                value = self.tables[self.selectedTable]['vals'][field]
                if self.fieldTypes[self.tables[self.selectedTable]['name']][field]['data_type'] == 'USER-DEFINED':
                    colsCombo = QtWidgets.QComboBox(self)
                    colsCombo.addItem('')
                    colsCombo.addItems(strToList(self.fieldTypes[self.tables[self.selectedTable]['name']][field]['data_type_name']))
                    colsCombo.setCurrentText(str(value))
                    self.ui.featureVals.setCellWidget(i, 1, colsCombo)
                else:
                    item = QtWidgets.QTableWidgetItem(value)
                    self.ui.featureVals.setItem(i, 1, item)
            header = self.ui.featureVals.horizontalHeader()       
            header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
            header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)

            self.updateNames(True)


    def updateNames(self, force = False):

        self.ui.specific_name.setText('')
        if self.ui.featureVals.currentRow() == -1 and not (type(force) == bool and force is True):
            return
        self.saveUserVals()
        if 'specific_id' in self.tables[self.selectedTable]['vals']:
            specificName = self.app.dBConnection.getSpecificName(
                self.tables[self.selectedTable]['name'],
                self.tables[self.selectedTable]['vals']['specific_id'])
            if specificName:
                self.ui.specific_name.setText(str(specificName))
        elif 'spec_no' in self.tables[self.selectedTable]['vals']:
            specificName = self.app.dBConnection.getSpecificName(
                self.tables[self.selectedTable]['name'],
                self.tables[self.selectedTable]['vals']['spec_no'])
            if specificName:
                self.ui.specific_name.setText(str(specificName))

        self.ui.manufactor.setText('')
        if self.ui.featureVals.currentRow() == -1 and not (type(force) == bool and force is True):
            return
        self.saveUserVals()
        if 'mspec_no' in self.tables[self.selectedTable]['vals']:
            manufactor = self.app.dBConnection.getManufactor(
                self.tables[self.selectedTable]['vals']['mspec_no'])
            if manufactor:
                self.ui.manufactor.setText(str(manufactor))