<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="fa" sourcelanguage="en">
<context>
    <name>ElecDrawingToolbar</name>
    <message>
        <location filename="../elec_drawing_toolbar.py" line="198"/>
        <source>lv_isolator</source>
        <translation>مقره فشار ضعیف</translation>
    </message>
</context>
</TS>
