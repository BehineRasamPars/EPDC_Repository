import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor,QIcon,QCursor,QPixmap,QPainter,QImage
from qgis.PyQt.QtCore import Qt, QRectF, QSize, QPoint, QVariant

from qgis.core import QgsFeature,QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from qgis.core.additions.edit import  edit
from .feature_inserter import FeatureInserter
class DrawPoint(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas, layername):
        print("Starting DrawPoint...", layername)
        self.canvas = canvas
        self.layername = layername
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.snapIndicator = QgsSnapIndicator(canvas)
        self.snapper = self.canvas.snappingUtils()
        self.setRelevantCursor(layername)
        self.reset()
        self.isEmittingPoint = True

    def iconPath(self, aName):
        icon_path = ':/plugins/elec_drawing_toolbar/icons/' + aName + '.png'
        print("using svg : ",icon_path)
        return icon_path

    def setRelevantCursor(self,aName):
        iconPath = self.iconPath(aName)
        inputPng = QPixmap(iconPath, 'png', Qt.AutoColor)
        pixmap = QPixmap(inputPng.size())
        pixmap.fill(Qt.transparent)
        p = QPainter(pixmap)
        p.setOpacity(0.3);
        p.drawPixmap(0, 0, inputPng);
        p.end()
        self.cursor = QCursor(pixmap,-1,-1)
        self.setCursor(self.cursor)

    def reset(self):
        self.isEmittingPoint = False
        self.point = None
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        snapMatch = self.snapper.snapToMap(event.pos())
        self.snapIndicator.setMatch(snapMatch)
        self.snapPoint = snapMatch.point()
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(point)

    def canvasReleaseEvent(self, event):
        # Get the click
        point = QgsPointXY(self.snapPoint.x(),self.snapPoint.y())
        if self.snapPoint.x() == 0.0 and self.snapPoint.y() == 0.0:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.point = point
        self.isEmittingPoint = False
        self.insertFeature()

    def insertFeature(self):
        self.rubberBand.hide()
        FeatureInserter(self.canvas,'POINT',self.layername,[self.point])
        self.reset()

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self,apoint):
        self.rubberBand.reset(QgsWkbTypes.PointGeometry)
        self.rubberBand.addPoint(apoint)
        self.rubberBand.show()

#iface.mapCanvas().layers()[1].fields()[2].setAlias('شناسه')