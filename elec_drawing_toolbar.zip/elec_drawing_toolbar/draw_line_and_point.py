import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import QgsFeature, QgsPoint, QgsPointXY, QgsGeometry, QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from .feature_inserter import FeatureInserter
from math import atan2, degrees


class DrawLineAndPoint(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas, flineLayerName, pointLayerName, slineLayerName ,DRAWING_ORDER=None):
        print("Starting DrawTwoPointsLine...", flineLayerName)
        self.canvas = canvas
        self.DRAWING_ORDER = DRAWING_ORDER
        self.flineLayerName = flineLayerName
        self.slineLayerName = slineLayerName
        self.pointLayerName = pointLayerName
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubberBand.setColor(Qt.red)
        self.rubberBand.setWidth(3)
        self.snapIndicator = QgsSnapIndicator(canvas)
        self.snapper = self.canvas.snappingUtils()
        self.reset()
        self.setPointType()

    def reset(self):
        self.startPoint = self.endPoint = None
        self.isEmittingPoint = False
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        snapMatch = self.snapper.snapToMap(event.pos())
        self.snapIndicator.setMatch(snapMatch)
        self.snapPoint = snapMatch.point()
        if self.startPoint is None:
            return
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(self.startPoint, point)
        # self.rubberBand.setGeometry([self.startPoint,event])

    def canvasReleaseEvent(self, event):
        # Get the click
        point = QgsPointXY(self.snapPoint.x(), self.snapPoint.y())
        if self.snapPoint.x() == 0.0 and self.snapPoint.y() == 0.0:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        if self.startPoint is None:
            self.startPoint = point
            self.endPoint = self.startPoint
            self.isEmittingPoint = True
        else:
            self.endPoint = point
            self.isEmittingPoint = False
            self.showRubber(self.startPoint, self.endPoint)
            self.insertFeature()

    def AngleBtw2Points(self, pointA, pointB):
        changeInX = pointB.x() - pointA.x()
        changeInY = pointB.y() - pointA.y()
        return degrees(atan2(changeInY, changeInX))

    def insertFeature(self):
        self.showRubber(self.startPoint, self.endPoint)
        self.rubberBand.hide()
        middlePoint = QgsPoint((self.startPoint.x(
        )+self.endPoint.x())/2, (self.startPoint.y()+self.endPoint.y())/2)
        
        if self.pointLayerName in self.classTypes:
            if self.DRAWING_ORDER is None or self.DRAWING_ORDER == 'LINE-POINT-LINE':
                TheAngle = self.AngleBtw2Points(self.startPoint, self.endPoint)
                if TheAngle >= 0:
                    PointAngle = 360-TheAngle
                else:
                    PointAngle = 180-TheAngle
                FeatureInserter(self.canvas, 'LineString', self.flineLayerName, [
                                            self.startPoint, middlePoint] , class_type = self.classTypes[self.pointLayerName])
                FeatureInserter(self.canvas, 'Point', self.pointLayerName, [
                                middlePoint], PointAngle)
                FeatureInserter(self.canvas, 'LineString', self.slineLayerName, [
                                middlePoint, self.endPoint] , class_type = self.classTypes[self.pointLayerName])
            elif self.DRAWING_ORDER == 'LINE-POINT':
                FeatureInserter(self.canvas, 'LineString', self.flineLayerName, [
                                self.startPoint, self.endPoint] , class_type = self.classTypes[self.pointLayerName])
                FeatureInserter(self.canvas, 'Point',
                                self.pointLayerName, [self.endPoint]) 
        else:
            if self.DRAWING_ORDER is None or self.DRAWING_ORDER == 'LINE-POINT-LINE':
                TheAngle = self.AngleBtw2Points(self.startPoint, self.endPoint)
                if TheAngle >= 0:
                    PointAngle = 360-TheAngle
                else:
                    PointAngle = 180-TheAngle
                firstLineFI = FeatureInserter(self.canvas, 'LineString', self.flineLayerName, [
                                            self.startPoint, middlePoint])
                FeatureInserter(self.canvas, 'Point', self.pointLayerName, [
                                middlePoint], PointAngle)
                FeatureInserter(self.canvas, 'LineString', self.slineLayerName, [
                                middlePoint, self.endPoint])
            elif self.DRAWING_ORDER == 'LINE-POINT':
                FeatureInserter(self.canvas, 'LineString', self.flineLayerName, [
                                self.startPoint, self.endPoint])
                FeatureInserter(self.canvas, 'Point',
                                self.pointLayerName, [self.endPoint])

        self.reset()

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, startPoint, endPoint):
        self.rubberBand.reset(QgsWkbTypes.LineGeometry)
        # point1 = QgsPoint(startPoint.x(), startPoint.y())
        self.rubberBand.addPoint(startPoint)
        self.rubberBand.addPoint(endPoint)
        self.rubberBand.show()

    def setPointType(self):
        self.classTypes = {'recloser': -1, 'modem': -2, 'hv_switch': -3, 'sectionalizer': -4, 'pt': -5, 'arrow': -6, 'dist_tr': -7, 'contactor': -8,
                           'discnt_s': -9, 'circt_brk': -10, 'current_trans': -11, 'cutout_fuse': -12, 'auto_switch': -13, 'fuse_switch': -14, 'auto_boostr': -15, 'surg_arstr' : -16 , 'ug_lv_line':-19}