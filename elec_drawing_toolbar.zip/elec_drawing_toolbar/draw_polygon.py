import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor,QIcon,QCursor,QPixmap,QPainter,QImage
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgsMapToolPan
from qgis.core import QgsFeature,QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from qgis.core.additions.edit import  edit
from .feature_inserter import FeatureInserter
from .utils.BRPRect import BRPRect

class DrawPolygon(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas,layername):
        print("Start Drawing Polygon ...")
        self.canvas = canvas
        self.layername = layername
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.setRelevantCursor(self.layername)
        self.reset()
        self.isEmittingPoint = True

    def refreshRubberbandColor(self):
        """ Update the rubberbands color """
        stroke_color = QColor.fromRgb(240,190,200).darker(150)
        fill_color = QColor.fromRgb(240,190,200)#self.canvas.selectionColor()
        fill_color.setAlphaF(0.5)
        self.rubberBand.setColor(fill_color)
        self.rubberBand.setStrokeColor(stroke_color)
        self.rubberBand.setBrushStyle(Qt.SolidPattern)
        self.rubberBand.setFillColor(fill_color)
        self.rubberBand.setWidth(3)

    def iconPath(self, aName):
        icon_path = ':/plugins/elec_drawing_toolbar/icons/' + aName + '.png'
        print("using svg : ",icon_path)
        return icon_path

    def setRelevantCursor(self,aName):
        iconPath = self.iconPath(aName)
        inputPng = QPixmap(iconPath, 'png', Qt.AutoColor)
        pixmap = QPixmap(inputPng.size())
        pixmap.fill(Qt.transparent)
        p = QPainter(pixmap)
        p.setOpacity(0.3);
        p.drawPixmap(0, 0, inputPng);
        p.end()
        self.cursor = QCursor(pixmap,-1,-1)
        self.setCursor(self.cursor)

    def reset(self):
        self.isEmittingPoint = False
        self.endPoint = None
        self.startPoint = None
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        if self.startPoint is None:
            return
        if not self.isEmittingPoint:
            return
        self.refreshRubberbandColor()
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(self.startPoint, point)


    def canvasReleaseEvent(self, event):
        # Get the click
        point = QgsPointXY(event.pos().x(),event.pos().y())
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.point = point
        if self.startPoint is None:
            self.startPoint = point
            self.endPoint = self.startPoint
            self.isEmittingPoint = True
            self.refreshRubberbandColor()
        else:
            self.endPoint = point
            self.isEmittingPoint = False
            self.showRubber(self.startPoint, self.endPoint)
            self.insertFeatures()

    def insertFeatures(self):
        self.rubberBand.hide()
        #PoleSubstationInserter(self.canvas,self.bRect,self.nofeeders,self.nolights)
        pointsList = []
        k = 0
        for apoint in self.bRect.asQgsPointXYVector():
            k += 1
            if k == 1:
                firstPoint = apoint
            pointsList.append(apoint)
        pointsList.append(firstPoint)
        FeatureInserter(self.canvas,'Polygon',self.layername,pointsList)
        self.reset()
        panTool = QgsMapToolPan(self.canvas)
        self.canvas.setMapTool(panTool)


    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, start_p, end_p):
        self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
        self.refreshRubberbandColor()
        
        self.bRect = BRPRect().createWithPoints( start_p, end_p)

        for apoint in self.bRect.asQgsPointXYVector():
            self.rubberBand.addPoint(apoint)


        self.rubberBand.closePoints()

        self.rubberBand.show()