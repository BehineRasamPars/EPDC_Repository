import qgis
from qgis import utils
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
import pyplugin_installer
import subprocess
import sys, os, os.path
import configparser
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import psycopg2
from psycopg2 import sql
import psycopg2.extras
#===========================================================

class DBConnection:

    loginData = qgis.core.QgsDataSourceUri()
    conn = None

    def __init__(self, host, port, dbName):
        self.loginData.setConnection(host, port, dbName, None, None, 1)


    def getConnIfValid(self, username, password):
        try:
            conn = psycopg2.connect(user = username,
                                  password = password,
                                  host = self.loginData.host(),
                                  port = self.loginData.port(),
                                  dbname = self.loginData.database())
            conn.set_session(autocommit=True)
            return conn
        except Exception as e:
            print(e)
            return False

    # return connection if success; else None.
    def getConn(self):
        if (not self.conn):
            connInfo = self.loginData.connectionInfo()
            inUser = None
            inPass = None
            success = True
            while (success):
                (success, inUser, inPass) = qgis.core.QgsCredentials.instance().get(connInfo, inUser, inPass)
                conn = self.getConnIfValid(inUser, inPass)
                if (conn):
                    qgis.core.QgsCredentials.instance().put(connInfo, inUser, inPass)
                    self.validData = True
                    self.loginData.setUsername(inUser)
                    self.loginData.setPassword(inPass)
                    self.conn = conn
                    break
        return self.conn

    # return username if a valid one entered. None otherwise.
    def getUsername(self):
        return self.loginData.username()
        
    def getHost(self):
        return self.loginData.host()
        
    def getPass(self):
        return self.loginData.password()
        
    def closeConn(self):
        if (self.conn):
            self.conn.close()
            self.conn = None

    def getEngNameOfTable(self, perName):
        cursor = self.getConn().cursor()
        cursor.execute("""
                SELECT
                    smdatasetname
                FROM
                    public.smregister
                WHERE
                    smtablename = %s
            """, (perName,))
        data = cursor.fetchone()
        if data:
            smdatasetname = data[0]
        else:
            smdatasetname = None
        return smdatasetname

    def tableNameToCode(self, tableName):
        tableName = tableName.upper()
        if tableName == 'LV_FEEDER':
            return 'id'
        elif tableName == 'MV_FEEDER':
            return 'feeder_code'
        elif tableName == 'PL_MDSUB':
            return 'pl_mds_code'
        else:
            return 'ID'


    def getTableFieldTypes(self, tableName):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        query = """
            SELECT
                iss.column_name,
                iss.data_type,
                CASE
                    WHEN (data_type = 'USER-DEFINED') THEN (
                        SELECT substring(string_agg(pg_enum.enumlabel, ',' ORDER BY pg_enum.enumsortorder) FROM 2)
                        FROM pg_type
                        JOIN pg_enum ON pg_enum.enumtypid = pg_type.oid
                        WHERE pg_type.typname = iss.udt_name
                    )
                    ELSE NULL
                END AS data_type_name
            FROM
                information_schema.columns AS iss
            WHERE
                table_schema = 'public'
                AND table_name = %s"""
        try:
            cur.execute(query, (tableName,))
            rows = cur.fetchall()
            result = {}
            for row in rows:
                result[row['column_name']] = { 'data_type': row['data_type'], 'data_type_name': row['data_type_name'] }
            return result
        except Exception as e:
            # print(e)
            return False


    def getSpecificName(self, tableName, code):
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                SELECT get_specific_name(%s, %s)
                """)
            cur.execute(query, (tableName, code,))
            res = cur.fetchone()[0]
            return res
        except Exception as e:
            # print(e)            
            return False


    def getManufactor(self, id):
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                SELECT get_manufactor(%s)
                """)
            cur.execute(query, (id,))
            res = cur.fetchone()[0]
            return res
        except Exception as e:
            # print(e)            
            return False


    def translate(self, outLan, inValue):
        inLan = ''
        if outLan == 'fa':
            inLan = 'en'
        elif outLan == 'en':
            inLan = 'fa'
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                    SELECT DISTINCT ON (en)
                        {}
                    FROM (
                        SELECT smdatasetname AS en, smtablename AS fa FROM public.smregister
                        UNION
                        SELECT smfieldname AS en, smfieldcaption AS fa FROM public.smfieldinfo
                    ) t1
                    WHERE {} = %s
                    LIMIT 1
                """).format(sql.Identifier(outLan), sql.Identifier(inLan))
            cur.execute(query, (inValue,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            # print(e)
            return False

    def translate2_table(self, table_en):
        conn = self.getConn()
        cur = conn.cursor()
        try:
            query = sql.SQL("""
                    SELECT table_fa FROM translate_tables WHERE table_en = %s;
                """)
            cur.execute(query, (table_en,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            print(e)
            return False
        finally:
        # Close the connection
            if cur:
                cur.close()

    def translate2_field(self, table_en, field_en):
        conn = self.getConn()
        cur = conn.cursor()
        try:
            query = sql.SQL("""
                    SELECT field_fa FROM translate_table_fields WHERE table_en = %s AND field_en = %s;
                """)
            cur.execute(query, (table_en, field_en,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            print(e)
            return False


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


class UsePlugin:

    pluginName = None
    updateChecked = False
    projVals = {}
    isReady = False

    def __init__(self):
        dirName = os.path.basename(getAppDir())
        self.pluginName = dirName


    def update(self):
        if not self.updateChecked:
            pyplugin_installer.instance().fetchAvailablePlugins(False)
            pyplugin_installer.instance().upgradeAllUpgradeable()
            self.updateChecked = True
            mypluginInstance = utils.plugins[self.pluginName]
            # mypluginInstance.run()
            mypluginInstance.initComp()
            return True
        else:
            return False


    def projVariables(self):
        variables = {}
        project = qgis.core.QgsProject.instance()
        variables['host'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('host')
        variables['dbname'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('dbname')
        variables['port'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('port')        
        variables['version'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('version') 
        if None in variables.values():
            return False
        return variables


    def checkProjVariables(self):

        projVals = self.projVariables()
        self.projVals = projVals

        if not projVals:
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "متغیر های پروژه به درستی تنظیم نشده اند."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return False
        else:
            return projVals


    def isUserAllowed(self):
        dBConnection = DBConnection(self.getValue('db_host'), self.getValue('port'), self.getValue('dbname'))
        conn = dBConnection.getConn()
        if dBConnection.getUsername():
            if dBConnection.getUsername() in [ 'serveradmin', 'postgres', 'rassam' ]:
                return True
            cur = conn.cursor()
            cur.execute("""
                    SELECT
                        *
                    FROM
                        public.plugin_role
                    INNER JOIN (
                            SELECT
                                r.rolname as username, r1.rolname as "role"
                            FROM
                                pg_catalog.pg_roles r
                            LEFT JOIN pg_catalog.pg_auth_members m ON (m.member = r.oid)
                            LEFT JOIN pg_roles r1 ON (m.roleid = r1.oid)
                            WHERE
                                r1.rolname = %s OR r.rolname = %s
                        ) AS table1
                        ON (public.plugin_role.role = table1.role OR public.plugin_role.role = table1.username)
                    WHERE plugin = %s
                """, (dBConnection.getUsername(), dBConnection.getUsername(), self.pluginName))
            if cur.fetchall():
                dBConnection.closeConn()
                return True
        return False


    def checkUserAllowed(self):
        if not self.isUserAllowed():
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "شما اجازه دسترسی به این پلاگین را ندارید."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return False
        else:
            return True


    # Edit this according to your needs:
    def checkAll(self):
        
        # if self.update():
        #     return False
        
        if not self.checkProjVariables():
            return False
        
        # if not self.checkUserAllowed():
        #     return False

        if not self.isUserAllowed():
            return False
            
        self.isReady = True
        return True


    def getValue(self, name):
        if name == 'qgis_proj':
            return 'http://' + self.projVals['host'] + '/QGIS_Proj/'
        elif name == 'db_host':
            return self.projVals['host']
        elif name == 'dbname':
            return self.projVals['dbname']
        elif name == 'port':
            return self.projVals['port']
        elif name == 'version':
            return self.projVals['version']
        elif name == 'rep_addr':
            return 'http://' + self.projVals['host'] + '/plugins/'