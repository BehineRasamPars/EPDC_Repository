import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import QgsFeature,QgsVectorLayer,QgsPoint,QgsPointXY,QgsProject,QgsGeometry,QgsMapRendererJob,QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool,QgsMapCanvas,QgsVertexMarker,QgsMapCanvasItem,QgsRubberBand,QgsMapToolEmitPoint
from .feature_inserter import FeatureInserter

class DrawTwoPointsLine(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas, layername):
        print("Starting DrawTwoPointsLine...",layername)
        self.canvas = canvas
        self.layername = layername
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubberBand.setColor(Qt.red)
        self.rubberBand.setWidth(3)
        self.snapIndicator = QgsSnapIndicator(canvas)
        self.snapper = self.canvas.snappingUtils()
        self.reset()

    def reset(self):
        self.startPoint = self.endPoint = None
        self.isEmittingPoint = False
        self.rubberBand.reset(True)
        
    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        snapMatch = self.snapper.snapToMap(event.pos())
        self.snapIndicator.setMatch(snapMatch)
        self.snapPoint = snapMatch.point()
        if self.startPoint is None:
            return
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(self.startPoint, point)
        #self.rubberBand.setGeometry([self.startPoint,event])

    def canvasReleaseEvent(self, event):
        # Get the click
        point = QgsPointXY(self.snapPoint.x(),self.snapPoint.y())
        if self.snapPoint.x() == 0.0 and self.snapPoint.y() == 0.0:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        if self.startPoint is None:
            self.startPoint = point
            self.endPoint = self.startPoint
            self.isEmittingPoint = True
        else:
            self.endPoint = point
            self.isEmittingPoint = False
            self.showRubber(self.startPoint, self.endPoint)
            self.insertFeature()

    def insertFeature(self):
        self.showRubber(self.startPoint, self.endPoint)
        self.rubberBand.hide()
        FeatureInserter(self.canvas, 'LineString', self.layername, [self.startPoint,self.endPoint])
        self.reset()

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, startPoint, endPoint):
        self.rubberBand.reset(QgsWkbTypes.LineGeometry)
        #point1 = QgsPoint(startPoint.x(), startPoint.y())
        self.rubberBand.addPoint(startPoint)
        self.rubberBand.addPoint(endPoint)
        self.rubberBand.show()