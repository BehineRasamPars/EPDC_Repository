import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor,QIcon,QCursor,QPixmap,QPainter,QImage
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgsMapToolPan
from qgis.core import QgsFeature,QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes
from qgis.gui import QgsSnapIndicator, QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from qgis.core.additions.edit import  edit
from .feature_inserter import FeatureInserter
from .utils.BRPRect import BRPRect
import qgis
from .pole_substation_inserter import PoleSubstationInserter
class DrawPoleSubstation(QgsMapTool):
    """QGIS Plugin Implementation."""


    def is_number(self, n):
        if n is None:
            return False
        try:
            float(n)   # Type-casting the string to `float`.
                    # If string is not a valid `float`, 
                    # it'll raise `ValueError` exception
        except ValueError:
            return False
        return True


    def __init__(self, canvas,nofeeders,nolights,angle,isFeederExist=False , IsBrdEearthExist=False):
        print("Starting Pole Substation Wizard ...")
        self.canvas = canvas
        self.layername = 'pl_mdsub_wizard'
        self.nofeeders = nofeeders
        self.nolights = nolights
        self.angle = 0
        if self.is_number(angle):
            self.angle = int(angle)

        self.isFeederExist = isFeederExist
        self.IsBrdEearthExist = IsBrdEearthExist
        QgsMapTool.__init__(self, self.canvas)
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        #self.rubberBand = QRubberBand(QRubberBand.Rectangle, self.canvas)
        self.padSubDim = [4,self.nofeeders + self.nolights]

        self.setRelevantCursor(self.layername)
        self.reset()
        self.isEmittingPoint = True

    def refreshRubberbandColor(self):
        """ Update the rubberbands color """
        stroke_color = QColor.fromRgbF(240,190,200).darker(150)
        fill_color = QColor.fromRgbF(240,190,200)#self.canvas.selectionColor()
        fill_color.setAlphaF(0.5)
        self.rubberBand.setColor(fill_color)
        self.rubberBand.setStrokeColor(stroke_color)
        self.rubberBand.setBrushStyle(Qt.SolidPattern)
        self.rubberBand.setFillColor(fill_color)
        self.rubberBand.setWidth(3)

    def iconPath(self, aName):
        icon_path = ':/plugins/elec_drawing_toolbar/icons/' + aName + '.png'
        print("using svg : ",icon_path)
        return icon_path

    def setRelevantCursor(self,aName):
        iconPath = self.iconPath(aName)
        inputPng = QPixmap(iconPath, 'png', Qt.AutoColor)
        pixmap = QPixmap(inputPng.size())
        pixmap.fill(Qt.transparent)
        p = QPainter(pixmap)
        p.setOpacity(0.3);
        p.drawPixmap(0, 0, inputPng);
        p.end()
        self.cursor = QCursor(pixmap,-1,-1)
        self.setCursor(self.cursor)

    def reset(self):
        self.isEmittingPoint = False
        self.endPoint = None
        self.centerPoint = None
        self.startPoint = None
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        if not self.isEmittingPoint:
            return
        self.refreshRubberbandColor()
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.centerPoint = point
        self.showRubber(self.centerPoint)


    def canvasReleaseEvent(self, event):
        point = QgsPointXY(event.pos().x(),event.pos().y())
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.centerPoint = point
        self.isEmittingPoint = False
        self.showRubber(self.centerPoint)
        self.insertFeatures()


    def insertFeatures(self):
        self.rubberBand.hide()
        PoleSubstationInserter(self.canvas,self.bRect,self.nofeeders,self.nolights,self.angle,self.isFeederExist , self.IsBrdEearthExist)
        self.reset()
        panTool = QgsMapToolPan(self.canvas)
        self.canvas.setMapTool(panTool)



    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, aCenterPoint):
        self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
        self.refreshRubberbandColor()
        
        self.bRect = BRPRect().createFromCenter( aCenterPoint, self.padSubDim[1],self.padSubDim[0])

        # for apoint in self.bRect.asQgsPointXYVector():
            # self.rubberBand.addPoint(apoint)
            # pass

        rect = qgis.core.QgsRectangle(
            aCenterPoint.x() - self.padSubDim[1] / 2,
            aCenterPoint.y() - self.padSubDim[0] / 2,
            aCenterPoint.x() + self.padSubDim[1] / 2, 
            aCenterPoint.y() + self.padSubDim[0] / 2
        )
        geom = QgsGeometry().fromRect(rect) #QgsGeometry object
        # rotate geometry 30 degrees clockwise around centroid
        geom.rotate(-self.angle, geom.centroid().asPoint())
        # set rubber band to geometry
        self.rubberBand.setToGeometry(geom)

        self.rubberBand.closePoints()

        self.rubberBand.show()
        

            
#iface.mapCanvas().layers()[1].fields()[2].setAlias('شناسه')