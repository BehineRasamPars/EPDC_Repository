# General tools for my own use.

import sys, os, os.path
import time, datetime
import csv
import re
from qgis.core import QgsProject



def strToList(input, delimiter = ','):
    outList = []
    reader = csv.reader(input.split('\n'), delimiter=delimiter)
    for row in reader:
        outList = row
    outList = list(map(str.strip, outList))
    return outList


def listToStr(input, quoteWrap = False):
    if not quoteWrap:
        outStr = ','.join(input)
    else:
        outStr = ','.join(f"'{w}'" for w in input)
    return outStr

def createTransactionDict():
    return {'INSERT' : 'افزودن' , 'UPDATE':'به روز رسانی' , 'DELETE':'حذف'} 
    
# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


def is_number(n):
    if n is None:
        return False
    try:
        float(n)   # Type-casting the string to `float`.
                   # If string is not a valid `float`, 
                   # it'll raise `ValueError` exception
    except ValueError:
        return False
    return True


def get_layer_by_tablename(tablename):
    layers = QgsProject.instance().mapLayers().values()
    if len(layers) == 0:
        return None
    layer = None
    for cur_layer in layers:
        uri_table = get_layer_source_table_name(cur_layer)
        if uri_table is not None and uri_table == tablename:
            layer = cur_layer
            break
    return layer

def get_layer_source_table_name(layer):
    if layer is None:
        return None
    uri_table = None
    uri = layer.dataProvider().dataSourceUri().lower()
    pos_ini = uri.find('table=')
    pos_end_schema = uri.rfind('.')
    pos_fi = uri.find('" ')
    if pos_ini != -1 and pos_fi != -1:
        uri_table = uri[pos_end_schema+2:pos_fi]
    return uri_table


def password_check(password):
    """
    Verify the strength of 'password'
    Returns a dict indicating the wrong criteria
    A password is considered strong if:
        8 characters length or more
        1 digit or more
        1 symbol or more
        1 uppercase letter or more
        1 lowercase letter or more
    """

    # calculating the length
    length_error = len(password) < 8

    # searching for digits
    digit_error = re.search(r"\d", password) is None

    # searching for uppercase
    uppercase_error = re.search(r"[A-Z]", password) is None

    # searching for lowercase
    lowercase_error = re.search(r"[a-z]", password) is None

    # searching for symbols
    symbol_error = re.search(r"[ !#$%&'()*+,-./[\\\]^_`{|}~"+r'"]', password) is None

    # overall result
    password_ok = not ( length_error or digit_error or uppercase_error or lowercase_error or symbol_error )

    return {
        'password_ok' : password_ok,
        'length_error' : length_error,
        'digit_error' : digit_error,
        'uppercase_error' : uppercase_error,
        'lowercase_error' : lowercase_error,
        'symbol_error' : symbol_error,
    }


def customPassCheck(password):

    msg = ''
    ok = False

    fun_res = password_check(password)

    if fun_res['length_error']:
        msg = 'طول رمز عبور شما کوتاه است'
    elif fun_res['uppercase_error']:
        msg = 'لطفا در رمز عبور خود از حروف بزرگ هم استفاده کنید'
    elif fun_res['lowercase_error']:
        msg = 'لطفا در رمز عبور خود از حروف کوچک هم استفاده کنید'
    elif fun_res['digit_error']:
        msg = 'لطفا در رمز عبور خود از اعداد هم استفاده کنید'
    else:
        ok = True

    return {
        'ok': ok,
        'msg': msg
    }