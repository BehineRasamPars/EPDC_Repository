import sys
import os
import os.path
from .DataAccess import DataAccess
from .mylib import *
from .rassam import *
import xml.etree.ElementTree as ET
from .resources import *
from .gui import *
from PyQt5 import QtWidgets, QtGui, QtCore
from qgis.utils import iface, Qgis
import xlwt
from PyQt5.QtCore import Qt
from qgis.core import QgsProject, QgsRuleBasedRenderer, QgsSymbol
from qgis.PyQt.QtCore import QThread, pyqtSignal


class GUI(QtWidgets.QMainWindow):

    dataAccess = None
    usePlugin = None
    version = 0
    lineDistCalculated = False

    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        self.initUI()
        self.multiListFa = {}
        self.selectAllCHBLastStatus = Qt.Unchecked

    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        if not self.dataAccess.getConn():
            self.msgUser('fail', 'در ارتباط با پایگاه داده مشکلی به وجود آمد.')
            exit()

        self.usePlugin = UsePlugin()
        self.ui.featureType.currentTextChanged.connect(self.updateFeatureList)
        self.ui.featureTypeList.itemSelectionChanged.connect(self.changeSelection)
        self.ui.layersCMB.checkedItemsChanged.connect(self.getLayersList)
        self.ui.excelOut.clicked.connect(self.GetDataAndSendToExcel)
        # self.ui.selectAllFeaturesBTN.clicked.connect(self.selectAllItemOfList)
        # self.ui.clearBTN.clicked.connect(self.clearItemOfList)
        self.ui.excelOutInfo.clicked.connect(self.excelOutInfo)
        self.ui.tabWidget.currentChanged.connect(self.tabChangedMain)
        self.ui.tabWidget_2.currentChanged.connect(self.tabChanged)
        self.ui.filterChb.stateChanged.connect(self.toggle_layer_filter)

        menu = QtWidgets.QMenu()
        menu.addAction('نمایش و زوم', self.showFeaturesAndZoom)
        menu.addAction('نمایش', self.showFeatures)
        menu.addAction('انتخاب عوارض', self.selectFeatures)
        menu.addAction('عدم نمایش', self.hideFeatures)
        menu.setStyleSheet('font: 10pt "B Nazanin";')
        self.ui.showFeatures.setMenu(menu)


    def changeActivityOfGroupItems(self , groupName , is_active):
        group = QgsProject.instance().layerTreeRoot().findGroup(groupName)
        if is_active:
            self.msgUser('wait')
            for layer_name in self.all_filter_layers:
                try:
                    layer = get_layer_by_tablename(layer_name)
                    layer.setSubsetString('')
                    layer.triggerRepaint()
                except AttributeError as e :
                    print(layer_name, 'not exists \n' , e)
                    continue
            self.msgUser('None')
        else :
            self.msgUser('wait')
            if self.check_row_not_empty(self.ui.infoTable1 , 3):
                feeder_name = self.ui.infoTable1.item(3, 1).text()
                for layer_node in self.all_filter_layers:
                    try:
                        layer = get_layer_by_tablename(layer_node)
                        expression = f'feeder_name = \'{feeder_name}\''
                        layer.setSubsetString(expression)
                        layer.triggerRepaint()
                    except AttributeError as e :
                        print(layer_node, 'not exists \n' , e)
                        continue
            self.msgUser('None')

            

    def toggle_layer_filter(self, state):
            if state == Qt.Checked:
                # Apply the filter when the checkbox is checked
                self.changeActivityOfGroupItems('پایگاه داده تخصصی', False)
            else:
                self.changeActivityOfGroupItems('پایگاه داده تخصصی', True)


    def changeSelection(self):
        self.add2FeatureList()

    def msgUser(self, type, msg=None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet(
                'color: rgb(60, 60, 60) ; font: 10pt "B Nazanin";')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    smid = None
    tableNameEn = None

    def run2(self):

        iface.messageBar().pushMessage(
            "تحلیل", "در حال تحلیل شبکه...", level=Qgis.Info, duration=0)
        iface.mainWindow().repaint()
        if self.dataAccess.updatePaths():
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage(
                "نتیجه", "تحلیل با موفقیت انجام شد", level=Qgis.Success)
            iface.mapCanvas().refresh()
            self.refreshAnalysisLayers()
        else:
            iface.messageBar().clearWidgets()
            iface.messageBar().pushMessage("نتیجه", "خطا در تحلیل", level=Qgis.Warning)

    def refreshAnalysisLayers(self):
        root = QgsProject.instance().layerTreeRoot()
        group2 = root.findGroup('تحلیل')
        layers = group2.findLayers()
        for thisLayer in layers:
            thisLayer.layer().reload()
        


    featureTypeChosen = ''

    def run(self):

        self.initUI()

        self.clearAll()

        layer = self.getSelectedLayer()
        if layer:
            self.tableNameEn = layer['table_name']
            self.smid = layer['smid']
            self.show()
            self.updateFeatureInfo()



    def getSelectedLayer(self):

        layer_info = {'table_name': '', 'smid': 0}
        layer1 = iface.layerTreeView().currentLayer()
        layer = iface.activeLayer()
        if layer and layer.fields().indexFromName('smid') != -1:
            features = layer.selectedFeatures()
            if features:
                layer_info['table_name'] = get_layer_source_table_name(layer)
                layer_info['smid'] = features[0].attribute('smid')
                if self.dataAccess.featureExists(layer_info['table_name'], layer_info['smid']):
                    return layer_info

        if layer1 and layer1.fields().indexFromName('smid') != -1:
            features = layer1.selectedFeatures()
            if features:
                layer_info['table_name'] = get_layer_source_table_name(layer1)
                layer_info['smid'] = features[0].attribute('smid')
                if self.dataAccess.featureExists(layer_info['table_name'], layer_info['smid']):
                    return layer_info

        if layer == None or len(layer.selectedFeatures()) == 0:
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "عارضه ای انتخاب نشده است."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()

            return False


    def getEndNodes(self):
        layer = self.getSelectedLayer()
        if layer:
            self.tableNameEn = layer['table_name']
            self.smid = layer['smid']
            layer = QgsProject.instance().mapLayersByName('انتهای شبکه')[0]
            iface.messageBar().pushMessage(
                "تحلیل", "لطفا صبر کنید...", level=Qgis.Info, duration=0)
            iface.mainWindow().repaint()
            nodes = self.dataAccess.getLeafNodes(self.tableNameEn, self.smid)
            iface.messageBar().clearWidgets()
            if not nodes:
                nodes = [-1]
            nodes = [str(x) for x in nodes]
            layer.setSubsetString(
                "node_id IN ({}) AND node_type <> 'no_subscribers'".format(listToStr(nodes)))
            QgsProject.instance().layerTreeRoot().findLayer(
                layer.id()).setItemVisibilityChecked(True)

    def updateFeatureInfo(self):

        while self.ui.infoTable1.rowCount() > 0:
            self.ui.infoTable1.removeRow(0)
        while self.ui.infoTable2.rowCount() > 0:
            self.ui.infoTable2.removeRow(0)
        while self.ui.infoTable3.rowCount() > 0:
            self.ui.infoTable3.removeRow(0)
        while self.ui.infoTable4.rowCount() > 0:
            self.ui.infoTable4.removeRow(0)
        self.lineDistCalculated = False

        self.msgUser('wait')

        featureIDs = self.dataAccess.getFeatureIDs(self.tableNameEn, self.smid)
        featureInfo = self.dataAccess.getFeatureInfo(
            self.tableNameEn, self.smid)

        self.ui.infoTable1.setRowCount(10)
        self.ui.infoTable2.setRowCount(13)
        self.ui.infoTable3.setRowCount(3)
        self.ui.filterChb.setEnabled(True)
        self.all_filter_layers = self.dataAccess.getTableListItemForFilter()
        self.ui.infoTable1.setItem(
            0, 0, QtWidgets.QTableWidgetItem('نام عارضه'))
        self.ui.infoTable1.setItem(
            1, 0, QtWidgets.QTableWidgetItem('کد عارضه'))
        self.ui.infoTable1.setItem(
            2, 0, QtWidgets.QTableWidgetItem('کد پست فوق توزیع'))
        self.ui.infoTable1.setItem(
            3, 0, QtWidgets.QTableWidgetItem('نام فیدر فشار متوسط'))
        self.ui.infoTable1.setItem(
            4, 0, QtWidgets.QTableWidgetItem('کد فیدر فشار متوسط'))
        self.ui.infoTable1.setItem(
            5, 0, QtWidgets.QTableWidgetItem('کد پست توزیع'))
        self.ui.infoTable1.setItem(
            6, 0, QtWidgets.QTableWidgetItem('نام محلی پست توزیع'))
        self.ui.infoTable1.setItem(
            7, 0, QtWidgets.QTableWidgetItem('کد محلی پست توزیع'))
        self.ui.infoTable1.setItem(
            8, 0, QtWidgets.QTableWidgetItem('کد ترانسفورماتور توزیع'))
        self.ui.infoTable1.setItem(
            9, 0, QtWidgets.QTableWidgetItem('کد فیدر فشار ضعیف'))
        if featureIDs:
            self.ui.infoTable1.setItem(
                0, 1, QtWidgets.QTableWidgetItem(featureIDs['fa_name']))
            self.ui.infoTable1.setItem(
                1, 1, QtWidgets.QTableWidgetItem(featureIDs['curr_feature']))
            self.ui.infoTable1.setItem(
                2, 1, QtWidgets.QTableWidgetItem(featureIDs['hv_substat']))
            self.ui.infoTable1.setItem(
                3, 1, QtWidgets.QTableWidgetItem(featureIDs['mv_feeder']))
            self.ui.infoTable1.setItem(
                4, 1, QtWidgets.QTableWidgetItem(featureIDs['feeder_code']))
            self.ui.infoTable1.setItem(
                5, 1, QtWidgets.QTableWidgetItem(featureIDs['mdsub']))
            self.ui.infoTable1.setItem(
                6, 1, QtWidgets.QTableWidgetItem(featureIDs['local_mdsub_name']))
            self.ui.infoTable1.setItem(
                7, 1, QtWidgets.QTableWidgetItem(featureIDs['local_mdsub_code']))
            self.ui.infoTable1.setItem(
                8, 1, QtWidgets.QTableWidgetItem(featureIDs['dist_tr']))
            self.ui.infoTable1.setItem(
                9, 1, QtWidgets.QTableWidgetItem(featureIDs['lv_feeder']))

        self.ui.infoTable2.horizontalHeader().hide()
        self.ui.infoTable2.setItem(0, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار متوسط زمینی (متر)'))
        self.ui.infoTable2.setItem(1, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار متوسط هوایی (متر)'))
        self.ui.infoTable2.setItem(2, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار متوسط خودنگهدار (متر)'))
        self.ui.infoTable2.setItem(3, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار متوسط (متر)'))
        self.ui.infoTable2.setItem(4, 0, QtWidgets.QTableWidgetItem(''))
        self.ui.infoTable2.setItem(5, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار ضعیف زمینی (متر)'))
        self.ui.infoTable2.setItem(6, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار ضغیف هوایی (متر)'))
        self.ui.infoTable2.setItem(7, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار ضعیف خودنگهدار (متر)'))
        self.ui.infoTable2.setItem(8, 0, QtWidgets.QTableWidgetItem(
            'مجموع طول شبکه فشار ضغیف (متر)'))
        self.ui.infoTable2.setItem(9, 0, QtWidgets.QTableWidgetItem(''))
        self.ui.infoTable2.setItem(
            10, 0, QtWidgets.QTableWidgetItem('مجموع طول شبکه روشنایی (متر)'))
        self.ui.infoTable2.setItem(11, 0, QtWidgets.QTableWidgetItem(''))
        self.ui.infoTable2.setItem(
            12, 0, QtWidgets.QTableWidgetItem('مجموع طول شبکه (متر)'))
        self.ui.infoTable3.setItem(0, 0, QtWidgets.QTableWidgetItem(
            'مجموع ظرفیت ترانسفورماتورهای توزیع هوایی (KVA)'))
        self.ui.infoTable3.setItem(1, 0, QtWidgets.QTableWidgetItem(
            'مجموع ظرفیت ترانسفورماتورهای توزیع زمینی (KVA)'))
        self.ui.infoTable3.setItem(2, 0, QtWidgets.QTableWidgetItem(
            'مجموع ظرفیت ترانسفورماتورهای توزیع (KVA)'))
        if featureInfo:
            self.ui.infoTable2.setItem(0, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_ug_mv'])) + ''))
            self.ui.infoTable2.setItem(1, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_oh_mv'])) + ''))
            self.ui.infoTable2.setItem(2, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_sp_mv'])) + ''))
            self.ui.infoTable2.setItem(3, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_mv'])) + ''))
            self.ui.infoTable2.setItem(4, 0, QtWidgets.QTableWidgetItem(''))
            self.ui.infoTable2.setItem(5, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_ug_lv'])) + ''))
            self.ui.infoTable2.setItem(6, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_oh_lv'])) + ''))
            self.ui.infoTable2.setItem(7, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_sp_lv'])) + ''))
            self.ui.infoTable2.setItem(8, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_lv'])) + ''))
            self.ui.infoTable2.setItem(9, 0, QtWidgets.QTableWidgetItem(''))
            self.ui.infoTable2.setItem(10, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_light'])) + ''))
            self.ui.infoTable2.setItem(11, 0, QtWidgets.QTableWidgetItem(''))
            self.ui.infoTable2.setItem(12, 1, QtWidgets.QTableWidgetItem(
                str(round(featureInfo['len_total'])) + ''))
            self.ui.infoTable3.setItem(0, 1, QtWidgets.QTableWidgetItem(
                str(featureInfo['pw_dist_tr_oh'])))
            self.ui.infoTable3.setItem(1, 1, QtWidgets.QTableWidgetItem(
                str(featureInfo['pw_dist_tr_ug'])))
            self.ui.infoTable3.setItem(
                2, 1, QtWidgets.QTableWidgetItem(str(featureInfo['pw_dist_tr'])))

        header = self.ui.infoTable1.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        header = self.ui.infoTable2.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        header = self.ui.infoTable3.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)

        self.msgUser('none')


    def layerLevelSetting(self):
        layer_level = self.dataAccess.getLevelOfTable(self.tableNameEn)
        self.changeDropdownBehavior(layer_level)

    def changeDropdownBehavior(self, level):
        if level == '{medium}':
            iface.messageBar().pushMessage("تحلیل", "برای انتخاب فیدر روشنایی/ضعیف و پست توزیع یک عارضه فشار ضعیف انتخاب کنید .", level=Qgis.Warning, duration=10)
            self.ui.featureType.model().item(7).setEnabled(False)
            self.ui.featureType.model().item(8).setEnabled(False)


    def updateFeatureList(self):
        self.msgUser('wait')
        self.ui.featureTypeList.setColumnHidden(2, True)
        self.ui.featureTypeList.clear()
        self.ui.featureList.clear()
        self.ui.excelOut.setEnabled(False)
        self.ui.featureList.setRowCount(0)
        self.ui.chosenLayerType.setText('-')
        self.featureTypeListCurr = []
        self.featureTypeChosen = ''
        self.ui.showFeatures.setEnabled(False)
        self.ui.layersCMB.setEnabled(True)
        if self.ui.featureType.currentText() == 'کل فیدر':
            self.featureTypeChosen = 'feeder'
        elif self.ui.featureType.currentText() == 'بالا دستی':
            self.featureTypeChosen = 'upper'
        elif self.ui.featureType.currentText() == 'پایین دستی':
            self.featureTypeChosen = 'lower'
        elif self.ui.featureType.currentText() == 'شبکه فشار متوسط':
            self.featureTypeChosen = 'med'
        elif self.ui.featureType.currentText() == 'شبکه فشار ضعیف':
            self.featureTypeChosen = 'low'
        elif self.ui.featureType.currentText() == 'پست توزیع':
            self.featureTypeChosen = 'dist_tr'
        elif self.ui.featureType.currentText() == 'فیدر فشار ضعیف/روشنایی':
            self.featureTypeChosen = 'lv_feeder'
        elif self.ui.featureType.currentText() == 'مسیر اصلی':
            self.featureTypeChosen = 'main_path'

        if self.featureTypeChosen:
            self.featureTypeListCurr = self.dataAccess.getFeaturesTypes(
                self.tableNameEn, self.smid, self.featureTypeChosen)
            self.ui.showFeatures.setEnabled(True)
            # self.ui.filterChb.setEnabled(True)
            self.ui.layersCMB.setEnabled(True)
        self.add2FeatureTypeList()
        self.add2ComboBoxTypeList()
        self.msgUser('none')

    def add2ComboBoxTypeList(self):
        self.selectedObjectLayer = []
        self.ui.layersCMB.clear()
        index_number = 0
        self.ui.layersCMB.insertItem(index_number,'انتخاب همه عوارض')
        for eachLayer in self.featureTypeListCurr:
            index_number += 1
            self.ui.layersCMB.insertItem(index_number , str(eachLayer['table_name_fa']))
        self.lenCheckAbleComboBox = index_number + 1
        
    def add2FeatureTypeList(self):
        self.ui.featureTypeList.clear()
        self.ui.featureTypeList.setRowCount(len(self.featureTypeListCurr))
        i = 0
        for item in self.featureTypeListCurr:
            self.ui.featureTypeList.setItem(
                i, 0, QtWidgets.QTableWidgetItem(str(item['table_name_fa'])))
            self.ui.featureTypeList.setItem(
                i, 1, QtWidgets.QTableWidgetItem(str(item['count'])))
            i = i + 1
        self.ui.featureTypeList.setHorizontalHeaderItem(
            0, QtWidgets.QTableWidgetItem('نوع عارضه'))
        self.ui.featureTypeList.setHorizontalHeaderItem(
            1, QtWidgets.QTableWidgetItem('تعداد'))
        header = self.ui.featureTypeList.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)


    def add2FeatureList(self):

        self.msgUser('wait')

        self.ui.featureList.clear()

        if self.featureTypeListCurr:

            ind = self.ui.featureTypeList.currentRow()
            table_name = self.featureTypeListCurr[ind]['table_name']
            self.ui.chosenLayerType.setText(
                self.featureTypeListCurr[ind]['table_name_fa'])

            list = self.dataAccess.getFeederFeaturesList(
                self.tableNameEn, self.smid, table_name, self.featureTypeChosen)
            allNames = self.dataAccess.getAllFaCols(table_name)
            colNamesFa = {}
            self.listFa = []
            for key in list[0].keys():
                if key in allNames:
                    colNamesFa[key] = allNames[key]
                else:
                    colNamesFa[key] = None
            listInd = 0
            for aList in list:
                aListInd = 0
                self.listFa.append({})
                for key in aList.keys():
                    if colNamesFa[key]:
                        if aList[key]:
                            self.listFa[listInd][colNamesFa[key]] = str(
                                aList[key])
                        else:
                            self.listFa[listInd][colNamesFa[key]] = None
                    aListInd = aListInd + 1
                listInd = listInd + 1
            self.ui.featureList.setRowCount(len(list))
            listInd = 0
            for aList in self.listFa:
                aListInd = 0
                for key in aList.keys():
                    if listInd == 0:
                        self.ui.featureList.setColumnCount(len(aList))
                        self.ui.featureList.setHorizontalHeaderItem(aListInd,
                                                                    QtWidgets.QTableWidgetItem(key))
                    self.ui.featureList.setItem(
                        listInd, aListInd, QtWidgets.QTableWidgetItem(aList[key]))
                    aListInd = aListInd + 1
                listInd = listInd + 1

            self.ui.featureList.resizeColumnsToContents()

        self.msgUser('none')
        
    def getLayersList(self):
        self.checkAllCMBPressed()
        self.stripLayersList()

    
    def checkAllCMBPressed(self):
        if self.ui.layersCMB.itemCheckState(0) != self.selectAllCHBLastStatus:
            for allItem in range(self.lenCheckAbleComboBox):
                self.ui.layersCMB.setItemCheckState(allItem , self.ui.layersCMB.itemCheckState(0))
            self.selectAllCHBLastStatus = self.ui.layersCMB.itemCheckState(0)
            
    def stripLayersList(self):
        self.selecteditem = []
        items = self.ui.layersCMB.currentText()
        if items or items != '' or self.ui.featureTypeList.rowCount() == 0:
            self.ui.excelOut.setEnabled(True)
            for eachitem in self.ui.layersCMB.checkedItems():
                self.selecteditem.append(eachitem.strip())
        else:
            self.ui.excelOut.setEnabled(False)

    def getDataFromCMBBox(self):
        self.msgUser('wait')
        if self.featureTypeListCurr:
            self.multiListFa.clear()
            for table_name_fa in self.selecteditem:
                table_name = self.dataAccess.getEngNameOfTable(table_name_fa)
                if not table_name:
                    continue
                list = self.dataAccess.getFeederFeaturesList(
                    self.tableNameEn, self.smid, table_name, self.featureTypeChosen)
                allNames = self.dataAccess.getAllFaCols(table_name)
                colNamesFa = {}
                self.outlistFa = []
                for key in list[0].keys():
                    if key in allNames:
                        colNamesFa[key] = allNames[key]
                    else:
                        colNamesFa[key] = None
                listInd = 0
                for aList in list:
                    aListInd = 0
                    self.outlistFa.append({})
                    for key in aList.keys():
                        if colNamesFa[key]:
                            if aList[key]:
                                self.outlistFa[listInd][colNamesFa[key]] = str(aList[key])
                            else:
                                self.outlistFa[listInd][colNamesFa[key]] = None
                        aListInd = aListInd + 1
                    listInd = listInd + 1
                listInd = 0
                self.multiListFa[table_name_fa] = self.outlistFa
            self.msgUser('none')
            self.ui.excelOut.setEnabled(True)

    def selectFeatureInGIS(self, table_name, itemlist):
        layer = QgsProject.instance().mapLayersByName(table_name)
        if layer:
            layer[0].selectByIds(itemlist)

    def selectAllFeature(self):

        self.msgUser('wait')
        if self.featureTypeListCurr:
            for row in range(self.ui.featureTypeList.rowCount()):
                itemlist = []
                finalItemList = []
                # existTableName.append(self.ui.featureTypeList.item(row, 2))
                table_name = self.featureTypeListCurr[row]['table_name']
                table_name_fa = self.featureTypeListCurr[row]['table_name_fa']
                # self.ui.chosenLayerType.setText(self.featureTypeListCurr[ind]['table_name_fa'])

                itemlist = self.dataAccess.getFeederSmidList(
                    self.tableNameEn, self.smid, table_name, self.featureTypeChosen)

                for itemId in itemlist:
                    finalItemList.append(itemId['smid'])
                self.selectFeatureInGIS(table_name_fa, finalItemList)
        self.msgUser('none')

    def clearAll(self):
        self.ui.featureType.setCurrentIndex(0)
        self.ui.featureTypeList.clear()
        self.ui.featureList.clear()
        self.ui.excelOut.setEnabled(False)

    def selectAllItemOfList(self):
        self.ui.featureTypeList.selectAll()

    def clearItemOfList(self):
        self.ui.featureTypeList.selectionModel().clear()
        self.ui.featureList.clear()
        self.ui.featureList.setRowCount(0)
        self.ui.featureList.setColumnCount(0)
        # self.ui.clearBTN.setEnabled(False)
        self.ui.excelOut.setEnabled(False)
        self.ui.chosenLayerType.setText('')

    def GetDataAndSendToExcel(self):
        self.getDataFromCMBBox()
        self.excelOutFun()
        
    def excelOutFun(self):
        filePath = QtWidgets.QFileDialog.getSaveFileName(
            self, 'Save File', '', 'Excel (*.xls)')[0]

        self.msgUser('wait')

        xl = xlwt.Workbook()
        for eachSheetName in self.multiListFa.keys():
            xl_sheet = xl.add_sheet(eachSheetName, cell_overwrite_ok=True)
            xl_sheet.cols_right_to_left = True

            ind = 0
            for key in self.multiListFa[eachSheetName][0].keys():
                xl_sheet.write(0, ind, key)
                ind += 1

            listInd = 1
            for aList in self.multiListFa[eachSheetName]:
                aListInd = 0
                for key in aList.keys():
                    xl_sheet.write(listInd, aListInd, aList[key])
                    aListInd = aListInd + 1
                listInd = listInd + 1

        xl.save(filePath)

        self.msgUser('success', 'خروجی اکسل ذخیره گردید')

    def check_row_not_empty(self ,obeject_name, row_number):
        if (obeject_name.item(row_number, 0) is None) or (obeject_name.item(row_number, 1) is None):
            return False
        return True

    def excelOutInfo(self):

        filePath = QtWidgets.QFileDialog.getSaveFileName(
            self, 'Save File', '', 'Excel (*.xls)')[0]

        self.msgUser('wait')
        xl = xlwt.Workbook()
        xl_sheet = xl.add_sheet("مسیر تغذیه", cell_overwrite_ok=True)
        xl_sheet.cols_right_to_left = True
        xl_sheet.write(0, 0, 'نام')
        xl_sheet.write(0, 1, 'مقدار')
        for row in range(self.ui.infoTable1.rowCount()):
            if self.check_row_not_empty(self.ui.infoTable1 , row):
                xl_sheet.write(row + 1, 0, self.ui.infoTable1.item(row, 0).text())
                xl_sheet.write(row + 1, 1, self.ui.infoTable1.item(row, 1).text())

        xl_sheet2 = xl.add_sheet("طول فیدر", cell_overwrite_ok=True)
        xl_sheet2.cols_right_to_left = True
        xl_sheet2.write(0, 0, 'نام')
        xl_sheet2.write(0, 1, 'مقدار')
        for row in range(self.ui.infoTable2.rowCount()):
            if self.check_row_not_empty(self.ui.infoTable2 , row):
                xl_sheet2.write(row + 1, 0, self.ui.infoTable2.item(row, 0).text())
                xl_sheet2.write(row + 1, 1, self.ui.infoTable2.item(row, 1).text())

        xl_sheet3 = xl.add_sheet("ترانس ها", cell_overwrite_ok=True)
        xl_sheet3.cols_right_to_left = True
        xl_sheet3.write(0, 0, 'نام')
        xl_sheet3.write(0, 1, 'مقدار')
        for row in range(self.ui.infoTable3.rowCount()):
            if self.check_row_not_empty(self.ui.infoTable3 , row):
                xl_sheet3.write(row + 1, 0, self.ui.infoTable3.item(row, 0).text())
                xl_sheet3.write(row + 1, 1, self.ui.infoTable3.item(row, 1).text())

        xl_sheet4 = xl.add_sheet("فواصل اصلی", cell_overwrite_ok=True)
        xl_sheet4.cols_right_to_left = True
        xl_sheet4.write(0, 0, 'نام')
        xl_sheet4.write(0, 1, 'مقدار')
        for row in range(self.ui.infoTable4.rowCount()):
            if self.check_row_not_empty(self.ui.infoTable4 , row):
                xl_sheet4.write(row + 1, 0, self.ui.infoTable4.item(row, 0).text())
                xl_sheet4.write(row + 1, 1, self.ui.infoTable4.item(row, 1).text())

        xl.save(filePath)

        self.msgUser('success', 'خروجی اکسل ذخیره گردید')


    def showFeatures(self):
        self.msgUser('wait')
        nodes = self.dataAccess.getFeatureNodes(
            self.tableNameEn, self.smid, self.featureTypeChosen)
        nodes = [str(x) for x in nodes]
        QgsProject.instance().layerTreeRoot().findGroup(
            'عوارض تحلیل').setItemVisibilityChecked(True)
        layers = get_layers_by_tablename('analysis_show_features2')
        filter = ""
        for layer in layers:
            is_medium = None
            if layer.name() == 'متوسط':
                is_medium = True
                filter = "'medium' = ANY(line_category)"
            elif layer.name() == 'ضعیف':
                is_medium = False
                filter = "'low' = ANY(line_category)"
            filter += ' AND node_id1 IN ({})'.format(listToStr(nodes))
            layer.setSubsetString(filter)
            self.setArrowLayerVisibility(layer,is_medium)

        self.refreshAnalysisLayers()
        self.msgUser('none')


    def setArrowLayerVisibility(self, layer, is_medium):
        if self.featureTypeChosen in ['upper','lower','med','main_path']:
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(is_medium)
        if self.featureTypeChosen in ['low','dist_tr','lv_feeder']:
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(not is_medium)
        if self.featureTypeChosen in ['feeder']:
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(True)


    def selectFeatures(self):
        self.msgUser('wait')
        QgsProject.instance().layerTreeRoot().findGroup(
            'عوارض تحلیل').setItemVisibilityChecked(True)
        self.selectAllFeature()
        self.refreshAnalysisLayers()
        self.msgUser('none')

    def showLatestFeatures(self):
        self.msgUser('wait')
        QgsProject.instance().layerTreeRoot().findGroup(
            'عوارض تحلیل').setItemVisibilityChecked(True)
        nodes = self.dataAccess.getFeatureNodes(
            self.tableNameEn, self.smid, self.featureTypeChosen)
        nodes = [str(x) for x in nodes]
        layers = get_layers_by_tablename('analysis_show_features2')
        filter = ""
        for layer in layers:
            if layer.name() == 'متوسط':
                filter = "'medium' = ANY(line_category)"
            elif layer.name() == 'ضعیف':
                filter = "'low' = ANY(line_category)"
            filter += ' AND node_id1 IN ({})'.format(listToStr(nodes))
            layer.setSubsetString(filter)
            QgsProject.instance().layerTreeRoot().findLayer(
                layer.id()).setItemVisibilityChecked(True)
        self.refreshAnalysisLayers()
        self.msgUser('none')

    def showFeaturesAndZoom(self):
        self.showFeatures()
        self.zoomToGroup("عوارض تحلیل")


    def zoomToGroup(self, groupName):
        extent = qgis.core.QgsRectangle()
        extent.setMinimal()
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(groupName)
        for child in group.children():
            if isinstance(child, qgis.core.QgsLayerTreeLayer):
                extent.combineExtentWith(child.layer().extent())
        iface.mapCanvas().setExtent(extent)
        iface.mapCanvas().refresh()


    def closeEvent(self, event):
        self.hideFeatures()
        self.ui.filterChb.setChecked(False)
        # self.changeActivityOfGroupItems('پایگاه داده تخصصی', True)


    def hideFeatures(self):
        self.msgUser('wait')
        layers = get_layers_by_tablename('analysis_show_features2')
        for layer in layers:
            QgsProject.instance().layerTreeRoot().findLayer(
                layer.id()).setItemVisibilityChecked(False)
            if layer.name() == 'متوسط':
                layer.setSubsetString("'medium' = ANY(line_category)")
            elif layer.name() == 'ضعیف':
                layer.setSubsetString("'low' = ANY(line_category)")
        self.refreshAnalysisLayers()
        self.msgUser('none')


    def tabChangedMain(self, ind):
        if ind == 1:
            self.layerLevelSetting()

    def tabChanged(self, ind):
        if ind == 3 and not self.lineDistCalculated:
            self.lineDistCalculated = True

            self.msgUser('wait')

            lineDist = self.dataAccess.getLineDist(self.tableNameEn, self.smid)

            if lineDist['to_trans']:
                self.ui.infoTable4.setRowCount(3)
            else:
                self.ui.infoTable4.setRowCount(2)

            self.ui.infoTable4.setItem(0, 0, QtWidgets.QTableWidgetItem(
                'مجموع طول تا فیدر فشار متوسط (متر)'))
            self.ui.infoTable4.setItem(1, 0, QtWidgets.QTableWidgetItem(
                'مجموع طول تا انتهای شبکه (متر)'))
            self.ui.infoTable4.setItem(0, 1, QtWidgets.QTableWidgetItem(
                str(round(lineDist['to_feeder'])) + ''))
            self.ui.infoTable4.setItem(1, 1, QtWidgets.QTableWidgetItem(
                str(round(lineDist['to_end'])) + ''))
            if lineDist['to_trans']:
                self.ui.infoTable4.setItem(
                    2, 0, QtWidgets.QTableWidgetItem('مجموع طول تا پست توزیع (متر)'))
                self.ui.infoTable4.setItem(2, 1, QtWidgets.QTableWidgetItem(
                    str(round(lineDist['to_trans'])) + ''))

            header = self.ui.infoTable4.horizontalHeader()
            header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
            header.setSectionResizeMode(
                1, QtWidgets.QHeaderView.ResizeToContents)

            self.msgUser('none')


# ========================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    ex = GUI()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
