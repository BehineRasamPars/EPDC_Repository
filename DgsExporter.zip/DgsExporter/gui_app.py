# import logging
import sys, os, os.path
# import datetime, time
from DataAccess import DataAccess
import mylib
# import argparse
# import subprocess
import resources, gui
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import cli



class DgsExporter_GUI(QtWidgets.QMainWindow):


    dataAccess = None


    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        self.initUI()


    def initUI(self):

        self.ui = gui.Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app.png'));

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)
        self.ui.feederList.setColumnHidden(0, True)
        self.ui.postList.setColumnHidden(0, True)

        if not self.dataAccess.conn:
            self.msgUser('fail', 'در ارتباط با پایگاه داده مشکلی به وجود آمد.')
            exit()

        self.ui.submit_feeder.clicked.connect(self.submit_feeder)
        self.ui.submit_post.clicked.connect(self.submit_post)
        
        self.updateWindow()
        self.show()


    def updateWindow(self):

        feederList = self.dataAccess.getFeederList()
        postList = self.dataAccess.getPostList()

        # Remove old data:
        while self.ui.feederList.rowCount() > 0:
            self.ui.feederList.removeRow(0)
        while self.ui.postList.rowCount() > 0:
            self.ui.postList.removeRow(0)

        self.ui.feederList.setRowCount(len(feederList))
        self.ui.postList.setRowCount(len(postList))

        for row, tableRow in enumerate(feederList):

            item = QtWidgets.QTableWidgetItem(str(tableRow['smid']))
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.feederList.setItem(row, 0, item)

            item = QtWidgets.QTableWidgetItem(tableRow['name'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.feederList.setItem(row, 1, item)

            item = QtWidgets.QTableWidgetItem(tableRow['feeder_code'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.feederList.setItem(row, 2, item)
            
            ids = self.dataAccess.getFeatureIDs('mv_feeder', tableRow['smid'])
            if ids['hv_substat']:
                hv_substat = ids['hv_substat']
            else:
                hv_substat = ''
            item = QtWidgets.QTableWidgetItem(hv_substat)
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.feederList.setItem(row, 3, item)

            item = QtWidgets.QTableWidgetItem()
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            item.setCheckState(QtCore.Qt.Unchecked)
            self.ui.feederList.setItem(row, 4, item)

        for row, tableRow in enumerate(postList):

            item = QtWidgets.QTableWidgetItem(str(tableRow['smid']))
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.postList.setItem(row, 0, item)

            item = QtWidgets.QTableWidgetItem(tableRow['su_name'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.postList.setItem(row, 1, item)

            item = QtWidgets.QTableWidgetItem(tableRow['ID'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.postList.setItem(row, 2, item)

            item = QtWidgets.QTableWidgetItem()
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            item.setCheckState(QtCore.Qt.Unchecked)
            self.ui.postList.setItem(row, 3, item)

        self.ui.feederList.resizeColumnsToContents()
        self.ui.postList.resizeColumnsToContents()


    # Send a message to the user.
    def msgUser(self, type, msg = None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    def submit_feeder(self):
        self.msgUser('wait')
        resAll = { 'success': [], 'fail': [] }
        path = self.selectPath()
        if path:
            for row in range(self.ui.feederList.rowCount()):
                if self.ui.feederList.item(row, 4).checkState() == 2:
                    smid = int(self.ui.feederList.item(row, 0).text())
                    # thisPath = "{}/mv_feeder_{}".format(path, smid)
                    # os.makedirs(thisPath)
                    thisPath = "{}/mv_feeder_{}.dgs".format(path, smid)
                    dgsExporter = cli.DgsExporter(thisPath)
                    res = dgsExporter.exportAll([smid])
                    if not res['fail']:
                        resAll['success'].append(self.ui.feederList.item(row, 1).text())
                        dgsExporter.saveDGS()
                    else:
                        resAll['fail'].append(self.ui.feederList.item(row, 1).text())
        self.msgUser('success',
            'Success: {} \n Fail: {}'
            .format(resAll['success'], resAll['fail'])
        )


    def submit_post(self):
        self.msgUser('wait')
        resAll = { 'success': [], 'fail': [] }
        path = self.selectPath()
        if path:
            for row in range(self.ui.postList.rowCount()):
                if self.ui.postList.item(row, 3).checkState() == 2:
                    smid = self.ui.postList.item(row, 0).text()
                    thisPath = "{}/hv_substat_{}.dgs".format(path, smid)
                    dgsExporter = cli.DgsExporter(thisPath)
                    res = dgsExporter.exportAll(self.dataAccess.getFeedersOfPost(smid))
                    if not res['fail']:
                        resAll['success'].append(self.ui.postList.item(row, 1).text())
                        dgsExporter.saveDGS()
                    else:
                        resAll['fail'].append(self.ui.postList.item(row, 1).text())
        self.msgUser('success',
            'Success: {} \n Fail: {}'
            .format(resAll['success'], resAll['fail'])
        )


    def selectPath(self):
        dir = QtWidgets.QFileDialog.getExistingDirectory()
        # file = QtWidgets.QFileDialog.getSaveFileName(self, 'Save File', '', 'DGS (*.dgs)')
        if (dir):
            return dir



#========================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    ex = DgsExporter_GUI()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()