# import logging
import time
from .rassam import getAppDir
from .mylib import *
import pandas as pd
import argparse
import json


class DgsExporter:

    tables = {}
    outPath = ''
    refIDs = {}
    lastID = 0
    lastTypeID = 0
    baseCoord = [0, 0]
    processedNodeIds = []
    processedFeederNodes = []
    feederList = []
    ter_coord = None
    specific_post_check = {'busbar_node_id': None, 'circt_brk_node_id': None, 'discnt_s_node_id': None}

    def __init__(self, outPath, query_method):

        self.initTable()
        self.addInitialRows()
        self.dataAccess = query_method
        self.outPath = outPath

    def getNewID(self):
        self.lastID += 1
        return str(self.lastID)

    def initTable(self):
        self.tables['General'] = pd.DataFrame()
        self.tables['ElmNet'] = pd.DataFrame()
        self.tables['IntGrfnet'] = pd.DataFrame()
        self.tables['ElmXnet'] = pd.DataFrame()
        self.tables['IntGrf'] = pd.DataFrame()
        self.tables['IntGrfcon'] = pd.DataFrame()
        self.tables['ElmTerm'] = pd.DataFrame()
        self.tables['ElmLne'] = pd.DataFrame()
        self.tables['StaCubic'] = pd.DataFrame()
        self.tables['ElmCoup'] = pd.DataFrame()
        self.tables['ElmShnt'] = pd.DataFrame()
        self.tables['ElmTr2'] = pd.DataFrame()
        # hossein insert begin
        self.tables['ElmLod'] = pd.DataFrame()
        self.tables['TypTr2'] = pd.DataFrame()
        self.tables['TypLne'] = pd.DataFrame()
        self.tables['IntFolder'] = pd.DataFrame()
        # hossein insert end

    def initial_type_row(self):
        json_dir = '{}/type_json/type_detail.json'.format(getAppDir())
        with open(json_dir, 'r') as file:
            data = json.load(file)
        for each_key, list_value in data.items():
            for each_row in list_value:
                type_row_update = {'ID(a:40)': self.getNewID(), 'fold_id(p)': self.refIDs['Types'], 'chr_name(a:20)': 1}
                each_row.update(type_row_update)
                self.tables[each_key] = self.tables[each_key].append(each_row, ignore_index=True)
            # print(self.tables[each_key])

    def addInitialRows(self):

        row = {
            'ID(a:40)': self.getNewID(),
            'Descr(a:40)': 'Version',
            'Val(a:40)': '5'
        }
        self.tables['General'] = self.tables['General'].append(
            row, ignore_index=True)

        self.refIDs['Net'] = self.getNewID()
        row = {
            'ID(a:40)': self.refIDs['Net'],
            'loc_name(a:40)': 'Net',
            'fold_id(p)': '',
            'frnom(r)': '50'
        }
        self.tables['ElmNet'] = self.tables['ElmNet'].append(
            row, ignore_index=True)

        self.refIDs['Graph'] = self.getNewID()
        row = {
            'ID(a:40)': self.refIDs['Graph'],
            'loc_name(a:40)': 'Graph',
            'fold_id(p)': '',
            'snap_on(i)': '0',
            'grid_on(i)': '1',
            'ortho_on(i)': '0',
            'pDataFolder(p)': '2',
        }
        self.tables['IntGrfnet'] = self.tables['IntGrfnet'].append(
            row, ignore_index=True)
        self.refIDs['Types'] = self.getNewID()
        # self.refIDs['TrTyp'] = self.getNewID()
        row = {
            'ID(a:40)': self.refIDs['Types'],
            'loc_name(a:40)': 'Types',
            'fold_id(p)': '',
            'iopt_typ': '1',
        }
        self.tables['IntFolder'] = self.tables['IntFolder'].append(
            row, ignore_index=True)
        self.initial_type_row()

    def saveDGS(self):

        # Replace nan values:
        for name in self.tables.keys():
            [self.tables[name][col].fillna('', inplace=True)
             for col in self.tables[name].columns]

        # IntGrfcon column order:
        index = ['ID(a:40)', 'loc_name(a:40)', 'fold_id(p)',
                 'rX:SIZEROW(i)', 'rY:SIZEROW(i)']
        currInd = 0
        while True:
            colName = 'rX:{}(r)'.format(currInd)
            if colName in self.tables['IntGrfcon']:
                index.append(colName)
                currInd += 1
            else:
                break
        currInd = 0
        while True:
            colName = 'rY:{}(r)'.format(currInd)
            if colName in self.tables['IntGrfcon']:
                index.append(colName)
                currInd += 1
            else:
                break
        self.tables['IntGrfcon'] = self.tables['IntGrfcon'].reindex(
            index, axis=1)

        # self.saveFileDGS(self.outFolder + '/file.dgs')
        # self.saveFileExcel(self.outFolder + '/file.xlsx')
        self.saveFileDGS(self.outPath)

    def saveFileExcel(self, filePath):
        # .xlsx
        writer = pd.ExcelWriter(filePath, engine='xlsxwriter')
        frames = {}
        for table in self.tables.keys():
            if not len(self.tables[table].index):
                continue
            frames[table] = self.tables[table]
            df = frames[table]
            df.to_excel(writer, sheet_name=table, index=False)
            for column in df:
                column_length = max(df[column].astype(
                    str).map(len).max(), len(column))
                col_idx = df.columns.get_loc(column)
                writer.sheets[table].set_column(
                    col_idx, col_idx, column_length)
        writer.save()

    def saveFileDGS(self, filePath):
        res = ''
        for table in self.tables.keys():
            if not len(self.tables[table].index):
                continue
            res += '$${}'.format(table)
            for col in self.tables[table].columns:
                res += ';{}'.format(col)
            res += '\n'
            for index, row in self.tables[table].iterrows():
                res += '  '
                for item in row.keys():
                    res += '{};'.format(row[item])
                res = res[0: -1]
                res += '\n'
            res += '\n'
        with open(filePath, "w") as file1:
            file1.write(res)

    def getCoord(self, input):
        output = [0.0] * 2
        output[0] = (input[0] - self.baseCoord[0]) + 100
        output[1] = (input[1] - self.baseCoord[1]) + 100
        output = [i * 3 for i in output]
        return output

    def exportAll(self, mvFeederSmidList):
        for smid in mvFeederSmidList:
            self.feederList.append(
                self.dataAccess.smid2nodeid('mv_feeder', smid))
        result = {
            'success': [],
            'fail': []
        }
        for count, smid in enumerate(mvFeederSmidList):
            if self.export(smid, count):
                result['success'].append(smid)
            else:
                result['fail'].append(smid)
        self.processedFeederNodes.clear()
        self.processedNodeIds.clear()
        return result

    def export(self, mv_feeder_smid, count=1):

        feederNode = self.dataAccess.smid2nodeid('mv_feeder', mv_feeder_smid)

        if not feederNode:
            return False

        if feederNode in self.processedFeederNodes:
            return True
        self.processedFeederNodes.append(feederNode)

        # if self.dataAccess.ringExists(feederNode):
        #     return False

        nodeInfo = self.dataAccess.getNodeInfo(feederNode)
        # #print(nodeInfo)
        self.baseCoord = self.dataAccess.getMinArea(feederNode)
        self.baseCoord[0] += (count - 1) * 50

        ElmXnetId = self.getNewID()
        row = {
            'ID(a:40)': ElmXnetId,
            'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
            'fold_id(p)': self.refIDs['Net']
        }
        self.tables['ElmXnet'] = self.tables['ElmXnet'].append(
            row, ignore_index=True)

        ElmTermId = self.getNewID()
        row = {
            'ID(a:40)': ElmTermId,
            'loc_name(a:40)': 'Terminal_{}_{}'.format(nodeInfo['node_type'], nodeInfo['smid']),
            'fold_id(p)': self.refIDs['Net'],
            'typ_id(p)': '',
            'iUsage(i)': '1',
            'uknom(r)': '20',
            'outserv(i)': '0'
        }
        self.tables['ElmTerm'] = self.tables['ElmTerm'].append(
            row, ignore_index=True)

        IntGrfId = self.getNewID()
        row = {
            'ID(a:40)': IntGrfId,
            'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
            'fold_id(p)': self.refIDs['Graph'],
            'iCol(i)': '1',
            'iVis(i)': '1',
            'iLevel(i)': '1',
            'rCenterX(r)': self.getCoord(nodeInfo['point'])[0],
            'rCenterY(r)': self.getCoord(nodeInfo['point'])[1] - 10,
            'sSymNam(a:40)': 'd_net',
            'pDataObj(p)': ElmXnetId,
            'iRot(i)': '0',
            'rSizeX(r)': '1',
            'rSizeY(r)': '1',
            'sAttr:SIZEROW(i)': '0',
            'sAttr:SIZECOL(i)': '0'
        }
        self.tables['IntGrf'] = self.tables['IntGrf'].append(
            row, ignore_index=True)

        row = {
            'ID(a:40)': self.getNewID(),
            'loc_name(a:40)': 'Terminal_{}_{}'.format(nodeInfo['node_type'],nodeInfo['smid']),
            'fold_id(p)': self.refIDs['Graph'],
            'iCol(i)': '1',
            'iVis(i)': '1',
            'iLevel(i)': '1',
            'rCenterX(r)': self.getCoord(nodeInfo['point'])[0],
            'rCenterY(r)': self.getCoord(nodeInfo['point'])[1],
            'sSymNam(a:40)': 'PointTerm',
            'pDataObj(p)': ElmTermId,
            'iRot(i)': '0',
            'rSizeX(r)': '1',
            'rSizeY(r)': '1',
            'sAttr:SIZEROW(i)': '0',
            'sAttr:SIZECOL(i)': '0'
        }
        self.tables['IntGrf'] = self.tables['IntGrf'].append(
            row, ignore_index=True)

        row = {
            'ID(a:40)': self.getNewID(),
            'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
            'fold_id(p)': ElmTermId,
            'obj_bus(i)': '0',
            'obj_id(p)': ElmXnetId
        }
        self.tables['StaCubic'] = self.tables['StaCubic'].append(
            row, ignore_index=True)

        row = {
            'ID(a:40)': self.getNewID(),
            'loc_name(a:40)': 'GCO_1',
            'fold_id(p)': IntGrfId,
            'rX:SIZEROW(i)': '2',
            'rX:0(r)': self.getCoord(nodeInfo['point'])[0],
            'rX:1(r)': self.getCoord(nodeInfo['point'])[0],
            'rY:SIZEROW(i)': '2',
            'rY:0(r)': self.getCoord(nodeInfo['point'])[1] - 10,
            'rY:1(r)': self.getCoord(nodeInfo['point'])[1]
        }
        self.tables['IntGrfcon'] = self.tables['IntGrfcon'].append(
            row, ignore_index=True)

        connNodes = self.dataAccess.getConnNodes(feederNode)
        connNodes2 = []
        for node in connNodes:
            dict = {}
            dict['node_id'] = node
            dict['conn_type'] = 'ug_mv_line'
            dict['is_connect'] = True
            dict['middle_node'] = None
            connNodes2.append(dict)

        self.queue.append([connNodes2, feederNode, ElmTermId])
        self.runAddRelatedOnes()

        return True

    queue = []

    def runAddRelatedOnes(self):
        while (self.queue):
            # #print(self.queue[0][1])
            self.addRelatedOnes(
                self.queue[0][0], self.queue[0][1], self.queue[0][2])
            self.queue.pop(0)

    def addRelatedOnes(self, connNodes, nodeIdIn, ElmTermIdIn):
        ElmLod_id = 0
        if nodeIdIn in self.processedNodeIds:
            return
        self.processedNodeIds.append(nodeIdIn)

        for thisConn in connNodes:

            lineInfo = self.dataAccess.getLineInfo(
                nodeIdIn, thisConn['node_id'], thisConn['middle_node'])
            nodeInfo = self.dataAccess.getNodeInfo(thisConn['node_id'])
            if not nodeInfo or not lineInfo:
                # print(f'{nodeIdIn} , {thisConn} , {nodeInfo}')
                continue

            if nodeInfo['node_type'] == 'mv_feeder':

                ElmXnetId = self.getNewID()
                row = {
                    'ID(a:40)': ElmXnetId,
                    'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
                    'fold_id(p)': self.refIDs['Net']
                }
                self.tables['ElmXnet'] = self.tables['ElmXnet'].append(
                    row, ignore_index=True)
                self.processedFeederNodes.append(thisConn['node_id'])

                IntGrfId = self.getNewID()
                row = {
                    'ID(a:40)': IntGrfId,
                    'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
                    'fold_id(p)': self.refIDs['Graph'],
                    'iCol(i)': '1',
                    'iVis(i)': '1',
                    'iLevel(i)': '1',
                    'rCenterX(r)': self.getCoord(nodeInfo['point'])[0],
                    'rCenterY(r)': self.getCoord(nodeInfo['point'])[1] - 10,
                    'sSymNam(a:40)': 'd_load',
                    'pDataObj(p)': ElmXnetId,
                    'iRot(i)': '0',
                    'rSizeX(r)': '1',
                    'rSizeY(r)': '1',
                    'sAttr:SIZEROW(i)': '0',
                    'sAttr:SIZECOL(i)': '0'
                }
                self.tables['IntGrf'] = self.tables['IntGrf'].append(
                    row, ignore_index=True)

                # row = {
                #     'ID(a:40)': self.getNewID(),
                #     'loc_name(a:40)': 'GCO_1',
                #     'fold_id(p)': IntGrfId,
                #     'rX:SIZEROW(i)': '2',
                #     'rX:0(r)': self.getCoord(nodeInfo['point'])[0],
                #     'rX:1(r)': self.getCoord(nodeInfo['point'])[0],
                #     'rY:SIZEROW(i)': '2',
                #     'rY:0(r)': self.getCoord(nodeInfo['point'])[1] - 10,
                #     'rY:1(r)': self.getCoord(nodeInfo['point'])[1]
                # }
                self.connect_low_point_to_terminal(IntGrfId)

            lines = [
                'ug_mv_line',
                'oh_mv_line',
                'sp_mv_cable'
            ]
            switches = [
                'auto_switch',
                'circt_brk',
                'cut_out',
                'discnt_s',
                'hv_switch',
                'recloser',
                'sectionalizer',
                'fuse_switch'
            ]
            trans = [
                'dist_tr'
            ]
            specific_post = [
                'busbar',
                'circt_brk',
                'no_subscriber'
            ]
            if not lineInfo:
                continue
            if lineInfo['line_type'] in (lines + switches + trans):

                ElmTermId = self.getNewID()
                if nodeInfo['node_type'] == 'mv_cpaci':
                    row = {
                        'ID(a:40)': ElmTermId,
                        'loc_name(a:40)': 'Terminal_{}_{}'.format(nodeInfo['node_type'], nodeInfo['smid']),
                        'fold_id(p)': self.refIDs['Net'],
                        'outserv(i)': '0'
                    }
                    self.tables['ElmShnt'] = self.tables['ElmShnt'].append(
                        row, ignore_index=True)
                else:
                    if nodeInfo['node_type'] == 'mv_jumpr' and not nodeInfo['is_connect']:
                        outserv = '1'
                    else:
                        outserv = '0'
                    uknom = self.check_mv_lv_uknom(nodeInfo['node_type'],nodeInfo['smid'])
                    self.set_terminal_detail_global(uknom, nodeInfo)
                    row = {
                        'ID(a:40)': ElmTermId,
                        'loc_name(a:40)': 'Terminal_{}_{}'.format(nodeInfo['node_type'],nodeInfo['smid']),
                        'fold_id(p)': self.refIDs['Net'],
                        'typ_id(p)': '',
                        'iUsage(i)': '1',
                        'uknom(r)': uknom,
                        'outserv(i)': outserv
                    }
                    self.tables['ElmTerm'] = self.tables['ElmTerm'].append(
                        row, ignore_index=True)

                    if nodeInfo['node_type'] == 'mv_feeder':
                        row = {
                            'ID(a:40)': self.getNewID(),
                            'loc_name(a:40)': 'ExtGrid_' + ElmXnetId,
                            'fold_id(p)': ElmTermId,
                            'obj_bus(i)': '0',
                            'obj_id(p)': ElmXnetId
                        }
                        self.tables['StaCubic'] = self.tables['StaCubic'].append(
                            row, ignore_index=True)
                self.check_for_init_special_pd(nodeInfo, lineInfo)
                if lineInfo['line_type'] in lines:
                    search_type_name = self.dataAccess.get_line_type_name(lineInfo['line_type'], lineInfo['type_smid'])
                    type_id = self.checktype('TypLne', 'loc_name(a:40)', search_type_name, lineInfo['line_type'])
                    ElmLneId = self.create_elmlne_row(lineInfo, type_id)

                elif lineInfo['line_type'] in trans:
                    search_type_name = self.dataAccess.get_trans_type_name(lineInfo['type_smid'])
                    # search_type_name = self.dataAccess.get_trans_type_name(nodeInfo['smid'])
                    type_id = self.checktype('TypTr2', 'loc_name(a:40)', search_type_name)
                    ElmLneId = self.create_elmtr2_row(lineInfo, type_id)
                    trans_capacity = self.dataAccess.getTransCapacity(
                        lineInfo['line_type'], lineInfo['type_smid'])

                    load_loc_name = 'loadTr_{}_{}'.format(lineInfo['type_smid'], trans_capacity)
                    ElmLod_id = self.create_elmlod_row(nodeInfo, load_loc_name, trans_capacity)
                    self.create_intgrf_row(lineInfo['line_type'], lineInfo['type_smid'],nodeInfo['point'], ElmLod_id, True)

                else:
                    if thisConn['is_connect']:
                        on_off = '1'
                    else:
                        on_off = '0'

                    is_switch = self.dataAccess.is_node_switch(nodeInfo['node_type'])
                    if is_switch:
                        locname = '{}_{}'.format(nodeInfo['node_type'], nodeInfo['smid'])
                    else:
                        locname = '{}_{}'.format(lineInfo['line_type'], lineInfo['type_smid'])

                    ElmLneId = self.create_elmcoup_row(locname, on_off)

                if nodeInfo['node_type'] == 'mv_cpaci':
                    sSymNam = 'd_shunt'
                elif nodeInfo['node_type'] == 'busbar':
                    sSymNam = 'TermStrip'
                else:
                    sSymNam = 'PointTerm'
                IntGrfPointId = self.getNewID()
                row = {
                    'ID(a:40)': IntGrfPointId,
                    'loc_name(a:40)': 'Terminal_{}_{}'.format(nodeInfo['node_type'], nodeInfo['smid']),
                    'fold_id(p)': self.refIDs['Graph'],
                    'iCol(i)': '1',
                    'iVis(i)': '1',
                    'iLevel(i)': '1',
                    'rCenterX(r)': self.getCoord(nodeInfo['point'])[0],
                    'rCenterY(r)': self.getCoord(nodeInfo['point'])[1],
                    'sSymNam(a:40)': sSymNam,
                    'pDataObj(p)': ElmTermId,
                    'iRot(i)': '0',
                    'rSizeX(r)': '1',
                    'rSizeY(r)': '1',
                    'sAttr:SIZEROW(i)': '0',
                    'sAttr:SIZECOL(i)': '0'
                }
                self.tables['IntGrf'] = self.tables['IntGrf'].append(
                    row, ignore_index=True)

                if lineInfo['line_type'] in lines:
                    sSymNam = 'd_lin'
                elif lineInfo['line_type'] in trans:
                    sSymNam = 'd_tr2'
                else:
                    sSymNam = 'd_couple'
                IntGrfLineId = self.getNewID()
                row = {
                    'ID(a:40)': IntGrfLineId,
                    'loc_name(a:40)': '{}_{}'.format(lineInfo['line_type'], ElmLneId),
                    'fold_id(p)': self.refIDs['Graph'],
                    'iCol(i)': '1',
                    'iVis(i)': '1',
                    'iLevel(i)': '1',
                    'rCenterX(r)': self.getCoord(lineInfo['center'])[0],
                    'rCenterY(r)': self.getCoord(lineInfo['center'])[1],
                    'sSymNam(a:40)': sSymNam,
                    'pDataObj(p)': ElmLneId,
                    'iRot(i)': '0',
                    'rSizeX(r)': '1',
                    'rSizeY(r)': '1',
                    'sAttr:SIZEROW(i)': '0',
                    'sAttr:SIZECOL(i)': '0'
                }
                self.tables['IntGrf'] = self.tables['IntGrf'].append(
                    row, ignore_index=True)

                row = {
                    'ID(a:40)': self.getNewID(),
                    'loc_name(a:40)': '{}_{}_1'.format(lineInfo['line_type'], lineInfo['type_smid']) , #nodeInfo['node_id']),
                    'fold_id(p)': ElmTermIdIn,
                    'obj_bus(i)': '0',
                    'obj_id(p)': ElmLneId
                }
                self.tables['StaCubic'] = self.tables['StaCubic'].append(
                    row, ignore_index=True)
                if nodeInfo['node_type'] != 'mv_cpaci':
                    thisId = self.getNewID()
                    row = {
                        'ID(a:40)': thisId,
                        'loc_name(a:40)': '{}_{}_2'.format(lineInfo['line_type'], thisId),
                        'fold_id(p)': ElmTermId,
                        'obj_bus(i)': '1',
                        'obj_id(p)': ElmLneId
                    }
                    self.tables['StaCubic'] = self.tables['StaCubic'].append(
                        row, ignore_index=True)
                    if ElmLod_id:
                        thisId = self.getNewID()
                        row = {
                            'ID(a:40)': thisId,
                            'loc_name(a:40)': 'Load_{}_2'.format(lineInfo['line_type'], thisId),
                            'fold_id(p)': ElmTermId,
                            'obj_bus(i)': '0',
                            'obj_id(p)': ElmLod_id
                        }
                        self.tables['StaCubic'] = self.tables['StaCubic'].append(
                            row, ignore_index=True)
                        ElmLod_id = 0

                row = {
                    'ID(a:40)': self.getNewID(),
                    'loc_name(a:40)': 'GCO_1',
                    'fold_id(p)': IntGrfLineId
                }
                row['rX:SIZEROW(i)'] = str(len(lineInfo['half_points_1']))
                row['rY:SIZEROW(i)'] = str(len(lineInfo['half_points_1']))
                for i, point in enumerate(reversed((lineInfo['half_points_1']))):
                    row['rX:{}(r)'.format(i)] = self.getCoord(point)[0]
                    row['rY:{}(r)'.format(i)] = self.getCoord(point)[1]
                self.tables['IntGrfcon'] = self.tables['IntGrfcon'].append(
                    row, ignore_index=True)
                row = {
                    'ID(a:40)': self.getNewID(),
                    'loc_name(a:40)': 'GCO_2',
                    'fold_id(p)': IntGrfLineId
                }
                row['rX:SIZEROW(i)'] = str(len(lineInfo['half_points_2']))
                row['rY:SIZEROW(i)'] = str(len(lineInfo['half_points_2']))
                for i, point in enumerate(lineInfo['half_points_2']):
                    row['rX:{}(r)'.format(i)] = self.getCoord(point)[0]
                    row['rY:{}(r)'.format(i)] = self.getCoord(point)[1]
                self.tables['IntGrfcon'] = self.tables['IntGrfcon'].append(
                    row, ignore_index=True)

                if thisConn['middle_node']:
                    prevNode = thisConn['middle_node']
                else:
                    prevNode = nodeIdIn
                connNodes = self.dataAccess.getNextNodes(
                    thisConn['node_id'], prevNode, self.feederList)
                self.queue.append([connNodes, thisConn['node_id'], ElmTermId])
            
            elif nodeInfo['node_type'] == 'no_subscribers' and nodeIdIn == self.specific_post_check['circt_brk_node_id']:
                self.specific_mdsub_load_handling(nodeInfo)

    def specific_mdsub_load_handling(self, nodeInfo):
        loc_name = 'loadNo_subscribers_{}'.format(nodeInfo['smid'])
        capacity = self.dataAccess.getNoSubscriberCapacity(nodeInfo['smid'])
        ElmLod_id = self.create_elmlod_row(nodeInfo, loc_name, capacity)
        self.create_intgrf_row(nodeInfo['node_type'], nodeInfo['smid'], nodeInfo['point'],  ElmLod_id, True)
        self.specific_post_check.fromkeys(self.specific_post_check, None)

    def check_for_init_special_pd(self, nodeInfo, lineInfo): 
        if nodeInfo['node_type'] == 'busbar':
            self.specific_post_check['busbar_node_id'] = nodeInfo['node_id']
            self.specific_post_check['circt_brk_node_id'] = None
            self.specific_post_check['discnt_s_node_id'] = None
        elif lineInfo['line_type'] == 'discnt_s' and self.specific_post_check['busbar_node_id']:
            self.specific_post_check['discnt_s_node_id'] = nodeInfo['node_id']
        elif lineInfo['line_type'] == 'circt_brk' and self.specific_post_check['busbar_node_id']:
            self.specific_post_check['circt_brk_node_id'] = nodeInfo['node_id']

    def check_mv_lv_uknom(self, table_name, smid):
        result = self.dataAccess.get_mv_or_lv(table_name)
        if ('{medium,low}' in result):
            connected_feaure = self.dataAccess.get_connected_feauter(table_name,smid)
            # print(connected_feaure['table_name'],connected_feaure['smid'])
            return self.check_mv_lv_uknom(connected_feaure['table_name'],connected_feaure['smid'])
        elif ('{low}' in result):
            return '0.4'
        else:
            return '20'

    def create_elmtr2_row(self, lineInfo, type_id):
        ElmTr2Id = self.getNewID()
        row = {
            'ID(a:40)': ElmTr2Id,
            'loc_name(a:40)': 'dist_tr_{}'.format(lineInfo['type_smid']),
            'fold_id(p)': self.refIDs['Net'],
            'outserv(i)': '0',
            'typ_id(p)': type_id
        }
        self.tables['ElmTr2'] = self.tables['ElmTr2'].append(
            row, ignore_index=True)
        return ElmTr2Id

    def create_elmlne_row(self, lineInfo, type_id):
        ElmLneId = self.getNewID()
        row = {
            'ID(a:40)': ElmLneId,
            'loc_name(a:40)': '{}_{}'.format(lineInfo['line_type'], lineInfo['type_smid']),
            'fold_id(p)': self.refIDs['Net'],
            'dline(r)': lineInfo['length'] / 1000,
            'typ_id(p)': type_id
        }
        self.tables['ElmLne'] = self.tables['ElmLne'].append(
            row, ignore_index=True)
        return ElmLneId

    def create_elmlod_row(self, nodeInfo, loc_name, load_capacity):
        ElmLod_id = self.getNewID()
        row = {
            'ID(a:40)': ElmLod_id,
            'loc_name(a:40)': loc_name,
            'fold_id(p)': self.refIDs['Net'],
            'typ_id(p)': '',
            'chr_name(a:20)': 'LOD_{}'.format(nodeInfo['smid']),
            'outserv(i)': 0,
            'phtech(a)': '3PH-\'YN\'',
            'plini(r)': int(load_capacity)/1000,
            'coslini(r)': 0.9,
            'scale0(r)': 1
            # 'mode_inp(i)':'PC'
        }
        self.tables['ElmLod'] = self.tables['ElmLod'].append(
            row, ignore_index=True)
        return ElmLod_id

    def create_intgrf_row(self, table_name, smid , point, pDataObj_id, has_grf_con):
        IntGrfId = self.getNewID()
        row = {
            'ID(a:40)': IntGrfId,
            'loc_name(a:40)': '{}_{}'.format(table_name, smid),
            'fold_id(p)': self.refIDs['Graph'],
            'iCol(i)': '1',
            'iVis(i)': '1',
            'iLevel(i)': '1',
            'rCenterX(r)': self.getCoord(point)[0],
            'rCenterY(r)': self.getCoord(point)[1] - 10,
            'sSymNam(a:40)': 'd_load',
            'pDataObj(p)': pDataObj_id,
            'iRot(i)': '0',
            'rSizeX(r)': '1',
            'rSizeY(r)': '1',
            'sAttr:SIZEROW(i)': '0',
            'sAttr:SIZECOL(i)': '0'
        }
        self.tables['IntGrf'] = self.tables['IntGrf'].append(
            row, ignore_index=True)
        if has_grf_con:
            self.connect_low_point_to_terminal(IntGrfId)

    def create_elmcoup_row(self, locname ,on_off):
        ElmCoupId = self.getNewID()
        row = {
                'ID(a:40)': ElmCoupId,
                'loc_name(a:40)': locname,
                'fold_id(p)': self.refIDs['Net'],
                'typ_id(p)': '',
                'on_off(i)': on_off,
                'aUsage(a:4)': 'dct'
            }
        self.tables['ElmCoup'] = self.tables['ElmCoup'].append(
                row, ignore_index=True)
        return ElmCoupId

    def connect_low_point_to_terminal(self, IntGrfId):
        if self.ter_coord:
            row = {
                'ID(a:40)': self.getNewID(),
                'loc_name(a:40)': 'GCO_1',
                'fold_id(p)': IntGrfId,
                'rX:SIZEROW(i)': '2',
                'rX:0(r)': self.ter_coord[0],
                'rX:1(r)': self.ter_coord[0],
                'rY:SIZEROW(i)': '2',
                'rY:0(r)': self.ter_coord[1] - 10,
                'rY:1(r)': self.ter_coord[1]
            }
            self.tables['IntGrfcon'] = self.tables['IntGrfcon'].append(
                row, ignore_index=True)
            self.ter_coord = None

    def set_terminal_detail_global(self, t_ukown, t_node_info):
        if t_ukown == '0.4':
            self.ter_coord = self.getCoord(t_node_info['point'])

    def checktype(self, object_type, search_key, search_value, line_name=None):
        check_value = self.tables[object_type][search_key] == search_value
        if not check_value.any():
            default_search_value = self.get_default_object_type_value(object_type, line_name)
            check_value = self.tables[object_type][search_key] == default_search_value
        type_id_value = self.tables[object_type].loc[check_value, 'ID(a:40)'].values[0]
        return type_id_value

    def get_default_object_type_value(self, object_type, line_name=None):
        if object_type == 'TypTr2':
            return 'TRF-Normal-20/0.4 kV-200 kVA'
        elif object_type == 'TypLne':
            if line_name == 'sp_mv_cable':
                return 'ABC120'
            elif line_name == 'oh_mv_line':
                return 'DOG'
            elif line_name == 'ug_mv_line':
                return 'NA2XSY 1x95/16 (12/20kV)'

def main():

    # Parse arguments:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_path", type=str, required=True)
    parser.add_argument("--mv_feeder_smid", type=str, required=True)
    parser.add_argument("--print", action='store_true')
    args = parser.parse_args()

    begTime = time.time()
    dgsExporter = DgsExporter(args.out_path)
    res = dgsExporter.exportAll(strToList(args.mv_feeder_smid))
    dgsExporter.saveDGS()
    elpTime = time.time() - begTime
    if args.print:
        print(res)
        print('Time: {:.2f} sec'.format(elpTime))
    return res


if __name__ == '__main__':
    main()
