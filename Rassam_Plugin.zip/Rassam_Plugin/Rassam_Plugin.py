# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu
import  os, os.path
import configparser
import qgis
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import pyplugin_installer
from qgis import utils
# Initialize Qt resources from file resources.py
from .resources import *
from .rassam import *
from .DataAccess import *
from .gui_app import Rassam_Plugin_GUI
from .search import *
from .catalog import *


# Store new conf.
def storeConf(values):

    confFilePath = getAppDir() + '/main.conf'

    confFile = configparser.ConfigParser()
    confFile.read(confFilePath)

    confFile['Main']['file_logging'] = 'true'
    confFile['DB']['main_db'] = values['main_db']
    confFile['DB']['host'] = values['host']
    confFile['DB']['port'] = values['port']
    confFile['DB']['user'] = values['user']
    confFile['DB']['pass'] = values['pass']

    with open(getAppDir() + '/main.conf', 'w') as newConf:
        confFile.write(newConf)


class Rassam_Plugin:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Rassam_Plugin_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'پلاگین رسام')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

        iface.initializationCompleted.connect(self.initComp)


    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('Rassam_Plugin', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        # icon_path = ':gui/icons/app2.png'
        # self.add_action(
        #     icon_path,
        #     text=self.tr(u'پلاگین رسام'),
        #     callback=self.run,
        #     parent=self.iface.mainWindow())

        # will be set False in run()
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        # for action in self.actions:
        #     self.iface.removePluginMenu(
        #         self.tr(u'پلاگین رسام'),
        #         action)
        #     self.iface.removeToolBarIcon(action)
        try:
            self.menuDraw.deleteLater()
        except:
            pass

    #=======================================================================
    dBConnection = DataAccess()
    guii = None
    initialized = False

    def run(self):
        msgBox = QtWidgets.QMessageBox()
        if not self.initialized:
            if not self.initComp():
                return
        if self.dBConnection.usePlugin.isReady:
            self.guii.showUI()


    def initComp(self):

        # if not self.dBConnection.usePlugin.checkProjVariables():
        #     return False
        #self.dBConnection.usePlugin.canExport()
        self.dBConnection.usePlugin.isReady = True

        self.guii = Rassam_Plugin_GUI()
        self.guii.checkVersion()
        self.guii.UserLoginLog()
        
        self.menuDraw = QMenu('ابزارها', self.iface.mainWindow().menuBar())
        actions = self.iface.mainWindow().menuBar().actions()
        lastAction = actions[-1]
        self.iface.mainWindow().menuBar().insertMenu(lastAction, self.menuDraw)

        icon = getAppDir() + '/gui/icons/app.png'
        self.action = QAction(QIcon(icon), 'رسام', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.menuDraw.addAction(self.action)

        self.menuDraw.addSeparator()

        icon = getAppDir() + '/gui/icons/search.png'
        self.action = QAction(QIcon(icon), 'جستجوی مشترکین', self.iface.mainWindow())
        self.action.triggered.connect(self.searchSub)
        self.menuDraw.addAction(self.action)

        icon = getAppDir() + '/gui/icons/catalog.png'
        self.action = QAction(QIcon(icon), 'کاتالوگ ها', self.iface.mainWindow())
        self.action.triggered.connect(self.catalogFun)
        self.menuDraw.addAction(self.action)

        self.initialized = True
        return True


    def searchSub(self):
        self.search = Search()


    def catalogFun(self):
        self.catalog = Catalog()