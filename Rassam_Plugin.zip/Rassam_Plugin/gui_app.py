from ipaddress import ip_address
import sys, os, os.path
import datetime
from .DataAccess import *
from .mylib import *
from .rassam import *
import requests
import xml.etree.ElementTree as ET
from .resources import *
from .gui import *
from PyQt5 import QtWidgets, QtGui, QtCore
from qgis.core import QgsProject , QgsExpressionContextUtils 
from datetime import datetime
from uuid import uuid4
from qgis.utils import iface
import socket


class Rassam_Plugin_GUI(QtWidgets.QMainWindow):


    dataAccess = None
    dbConn = None
    version = 0

    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        self.initUI()


    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        if not self.dataAccess.getConn():
            self.msgUser('fail', 'در ارتباط با پایگاه داده مشکلی به وجود آمد.')
            exit()

        self.show_project_details()
        
        self.ui.pluginUpdate.clicked.connect(self.updatePlugins)
        self.ui.getNewProj.clicked.connect(self.getNewProj)


    def updatePlugins(self):
        self.dataAccess.usePlugin.update(True)


    def show_project_details(self):
        self.currUser = self.dataAccess.dbConn.getUsername()
        self.currGroups = self.dataAccess.getUserGroups(self.currUser)
        self.ui.username.setText(self.currUser)
        if self.currGroups:
            self.ui.groupNames.setText(listToStr(self.currGroups))

        self.version = self.getAvailableProjVer()
        if self.version:
            self.ui.projVer.setText(self.version)

    def updatePluginList(self):

        self.msgUser('wait')

        # Remove old data:
        while self.ui.pluginList.rowCount() > 0:
            self.ui.pluginList.removeRow(0)

        self.plugins = self.getPluginNames()
        username = self.ui.username.text()
        thisUserPlugins = self.dataAccess.getRolePlugins(username)

        self.ui.pluginList.setRowCount(len(self.plugins))
        for i, plugin in enumerate(self.plugins):

            item = QtWidgets.QTableWidgetItem(plugin['name_dis'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.pluginList.setItem(i, 0, item)

            item = QtWidgets.QTableWidgetItem()
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable & ~QtCore.Qt.ItemIsUserCheckable)
            if plugin['name'] in thisUserPlugins or username in [ 'serveradmin', 'postgres', 'rassam' ]:
                item.setCheckState(QtCore.Qt.Checked)
            else:
                item.setCheckState(QtCore.Qt.Unchecked)
            self.ui.pluginList.setItem(i, 1, item)

            item = QtWidgets.QTableWidgetItem()
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable & ~QtCore.Qt.ItemIsUserCheckable)
            if plugin['name'] in qgis.utils.available_plugins:
                item.setCheckState(QtCore.Qt.Checked)
            else:
                item.setCheckState(QtCore.Qt.Unchecked)
            self.ui.pluginList.setItem(i, 2, item)

        self.ui.pluginList.resizeColumnsToContents()

        self.msgUser('none')


    def showUI(self):
        self.show()
        self.updatePluginList()


    def checkVersion(self):
        if self.version and self.dataAccess.usePlugin.getValue('version') < self.version:
            msgbox = QtWidgets.QMessageBox()
            msgbox.setWindowTitle("توضیحات")
            msgbox.setText('نسخه ای جدیدتر از نسخه پروژه شما وجود دارد. آیا مایل به دریافت آن هستید؟')
            # msgbox.addButton(QtWidgets.QMessageBox.Ok)
            yes_button = msgbox.addButton('بله', QtWidgets.QMessageBox.YesRole)
            no_button = msgbox.addButton('خیر', QtWidgets.QMessageBox.YesRole)
            yes_button.clicked.connect(self.getNewProj)
            bttn = msgbox.exec_()

    def UserLoginLog(self):
        ProjectInstance = QgsProject.instance()
        sessionId = str(uuid4())
        currentTime = datetime.now()
        ip_addr = self.getUserIP()
        username = self.ui.username.text()
        QgsExpressionContextUtils.setProjectVariable(ProjectInstance, 'session_Id',sessionId)
        msg = username
        self.dataAccess.insertUserLoginDataToDb(username , sessionId , currentTime , ip_addr)

    def getAvailableProjVer(self):
        try:
            response = requests.get(self.dataAccess.usePlugin.getValue('qgis_proj') + 'version')
            if response.status_code !=  200:
                raise 'Not 200'
            data = response.text
            return data
        except Exception as e:
            self.msgUser('fail', 'در ارتباط به سرور مشکلی به وجود آمد')
            self.msgUser('fail',e)
            return False

    # def getProjectIcon(self):
    #     try:
    #         icon_address = self.dataAccess.usePlugin.getValue('qgis_proj') + self.dbConn.conf['icon_name']
    #         icon = QtGui.QIcon(icon_address)
    #         iface.mainWindow().setWindowIcon(icon)
    #         iface.mainWindow().setWindowTitle('Rassam GeoPower')
    #     except Exception as e :
    #         print(e)

            

    # Send a message to the user.
    def msgUser(self, type, msg = None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    def getUserIP(self):
        try:
            user_details = socket.gethostname()   
            ip_addr = socket.gethostbyname(user_details)
            return ip_addr
        except Exception as e:
            print(f"ip Error : {e}")
            return None


    # Get list of available plugins from the repository.
    def getPluginNames(self):
        try:
            response = requests.get(self.dataAccess.usePlugin.getValue('rep_addr'))
            if response.status_code !=  200:
                raise 'Not 200'
            root = ET.fromstring(response.text)
            plugins = root.findall("./pyqgis_plugin")
        except Exception as e:
            self.msgUser('fail', 'در دریافت لیست پلاگین ها مشکلی به وجود آمد.')
            return []
        pluginNames = []
        for plugin in plugins:
            name = {}
            name['name'] = os.path.splitext(plugin.find('file_name').text)[0]
            name['name_dis'] = plugin.attrib['name']
            pluginNames.append(name)
        return pluginNames


    def urlExists(self, path):
        r = requests.head(path , allow_redirects=True)
        return r.status_code == requests.codes.ok


    def download(self, url, localPath):
        file = requests.get(url).content
        with open(localPath, 'wb') as handler:
            handler.write(file)


    def getNewProj(self):
        if self.urlExists(self.dataAccess.usePlugin.getValue('qgis_proj') + 'file.qgs'):
            file = QtWidgets.QFileDialog.getSaveFileName(self, 'Save File', '', 'QGS (*.qgs)')[0]
            if file:
                self.download(self.dataAccess.usePlugin.getValue('qgis_proj') + 'file.qgs', file)
                self.msgUser('success')
        elif self.urlExists(self.dataAccess.usePlugin.getValue('qgis_proj') + 'file.qgz'):
            file = QtWidgets.QFileDialog.getSaveFileName(self, 'Save File', '', 'QGZ (*.qgz)')[0]
            if file:
                self.download(self.dataAccess.usePlugin.getValue('qgis_proj') + 'file.qgz', file)
                self.msgUser('success')


    def searchFeature(self):
        pass



#========================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    ex = Rassam_Plugin_GUI()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()