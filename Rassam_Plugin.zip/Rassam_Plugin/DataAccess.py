import sys, os, os.path
import datetime, time
import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
from PyQt5 import QtWidgets
from .rassam import *
#========================================================


class DataAccess:

    dbConn = None
    dBConnection = None
    usePlugin = UsePlugin()
    _instance = None

    def __init__(self):
        self.usePlugin.checkProjVariables()
        self.dbConn = DBConnection(self.usePlugin.getValue('db_host'), self.usePlugin.getValue('port'), self.usePlugin.getValue('dbname'))

    def __call__(cls):
        if cls._instance is None:
            cls._instance = cls.__new__(cls)
        return cls._instance

    # Get a connection to the database.
    def getConnctions(self):
        try:
            conn = self.dbConn.getConn()
            conn.autocommit = True
            return conn
        except Exception as e:
            logging.error(e)
            return False


    def getConn(self):
        return self.getConnctions()

    # ---------------------------------

    def getEngNameOfTable(self, perName):
        cursor = self.getConn().cursor()
        cursor.execute("""
                SELECT
                    smdatasetname
                FROM
                    public.smregister
                WHERE
                    smtablename = %s
            """, (perName,))
        data = cursor.fetchone()
        if data:
            smdatasetname = data[0]
        else:
            smdatasetname = None
        return smdatasetname


    def tableNameToCode(self, tableName):
        tableName = tableName.upper()
        if tableName == 'LV_FEEDER':
            return 'id'
        elif tableName == 'MV_FEEDER':
            return 'feeder_code'
        elif tableName == 'PL_MDSUB':
            return 'pl_mds_code'
        else:
            return 'ID'


    def translate(self, outLan, inValue):
        inLan = ''
        if outLan == 'fa':
            inLan = 'en'
        elif outLan == 'en':
            inLan = 'fa'

        cur = self.getConn().cursor()
        query = sql.SQL("""
                SELECT DISTINCT ON (en)
                    {}
                FROM (
                    SELECT smdatasetname AS en, smtablename AS fa FROM public.smregister
                    UNION
                    SELECT smfieldname AS en, smfieldcaption AS fa FROM public.smfieldinfo
                ) t1
                WHERE {} = %s
                LIMIT 1
            """).format(sql.Identifier(outLan), sql.Identifier(inLan))
        cur.execute(query, (inValue,))
        data = cur.fetchone()
        if data:
            data = data[0]
        else:
            data = None
        return data


    def translate2(self):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        query = sql.SQL("""
                SELECT DISTINCT ON (smfieldname) * FROM smfieldinfo;
            """)
        cur.execute(query)
        result = {}
        rows = cur.fetchall()
        for row in rows:
            result[row['smfieldname']] = row['smfieldcaption']
        return result


    def translate_table(self, table_en):
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                    SELECT table_fa FROM translate_tables WHERE table_en = %s;
                """)
            cur.execute(query, (table_en,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            print(e)
            return False

    def translate_field(self, table_en, field_en):
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                    SELECT field_fa FROM translate_table_fields WHERE table_en = %s AND field_en = %s;
                """)
            cur.execute(query, (table_en, field_en,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            print(e)
            return False

    def insertUserLoginDataToDb(self , userName , sessionId , currentTime , ip_addr):
        cur = self.getConn().cursor()
        query = 'INSERT INTO logs.brp_log_users(username, arrival_time, session_id , ip_address) VALUES (\'{}\',\'{}\',\'{}\',\'{}\');'.format(userName , currentTime , sessionId , ip_addr)
        cur.execute(query)

    def getUserAccess(self, username):
        cur = self.getConn().cursor()
        cur.execute("""
            SELECT DISTINCT
                code
            FROM
                app_role
            INNER JOIN
                app_access ON (app_role.app_access_id = app_access.access_id)
            WHERE
                "role" = %s
                OR "role" IN ( 
                    SELECT
                        rolname
                    FROM
                        pg_user
                    JOIN pg_auth_members ON
                        (pg_user.usesysid = pg_auth_members.member)
                    JOIN pg_roles ON
                        (pg_roles.oid = pg_auth_members.roleid)
                    WHERE
                        pg_user.usename = %s
                )
            """, (username, username,))
        rows = [r[0] for r in cur.fetchall()]
        return rows
            

    # Get list of plugins that a role (user/group) can access to.
    def getRolePlugins(self, roleName):
        cur = self.getConn().cursor()
        cur.execute("""
                SELECT
                    plugin
                FROM
                    public.plugin_role
                WHERE role = %s
            """, (roleName,))
        rows = [r[0] for r in cur.fetchall()]
        return rows


    def getUserGroups(self, userName):
        cur = self.getConn().cursor()
        cur.execute("""
            SELECT
                rolname
            FROM
                pg_user
            JOIN pg_auth_members ON
                (pg_user.usesysid = pg_auth_members.member)
            JOIN pg_roles ON
                (pg_roles.oid = pg_auth_members.roleid)
            WHERE
                pg_user.usename = %s;
            """, (userName,))
        rows = [r[0] for r in cur.fetchall()]
        return rows

    
    def getTableFieldTypes(self, tableName):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        query = """
            SELECT
                iss.column_name,
                iss.data_type,
                CASE
                    WHEN (data_type = 'USER-DEFINED') THEN (
                        SELECT substring(string_agg(pg_enum.enumlabel, ',' ORDER BY pg_enum.enumsortorder) FROM 2)
                        FROM pg_type
                        JOIN pg_enum ON pg_enum.enumtypid = pg_type.oid
                        WHERE pg_type.typname = iss.udt_name
                    )
                    ELSE NULL
                END AS data_type_name
            FROM
                information_schema.columns AS iss
            WHERE
                table_schema = 'public'
                AND table_name = %s"""
        cur.execute(query, (tableName,))
        rows = cur.fetchall()
        result = {}
        for row in rows:
            result[row['column_name']] = { 'data_type': row['data_type'], 'data_type_name': row['data_type_name'] }
        return result


    def getNoSub(self, sub_fields):
        try:
            if not sub_fields:
                return []
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = sql.SQL("""
                SELECT * FROM no_subscribers
                WHERE "ID" IN (
                    SELECT counter_box_code FROM subscriber
                    WHERE
                        {}
                );
            """).format(sql.SQL(' AND ').join(
                sql.Composed([sql.Identifier(k), sql.SQL(" = "), sql.Placeholder(k)]) for k in sub_fields.keys()
            ))
            print(query)
            cur.execute(query, sub_fields)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            return []


    def getAllFaCols(self, tableName):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute("""
            SELECT * FROM translate_table_fields WHERE table_en = %s ORDER BY table_en
            """, (tableName,))
        rows = cur.fetchall()
        names = {}
        for row in rows:
            names[row['field_en']] = row['field_fa']
        return names


    def getRows(self, tableName):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        query = sql.SQL("""
            SELECT
                *
            FROM {}
        """).format(sql.Identifier(tableName))
        cur.execute(query)
        rows = cur.fetchall()
        return rows
        

    def getCatalogs(self):
        cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute("""
            SELECT DISTINCT ON (table_name_ref)
                table_name_ref AS en,
                tablename_en2fa(table_name_ref) AS fa
            FROM
                table_specific;
        """)
        rows = cur.fetchall()
        return rows


    def roleInPluginAccess(self, userName, pluginName):
        cur = self.getConn().cursor()
        cur.execute("""
                SELECT
                    *
                FROM
                    public.plugin_role
                INNER JOIN (
                        SELECT
                            r.rolname as username, r1.rolname as "role"
                        FROM
                            pg_catalog.pg_roles r
                        LEFT JOIN pg_catalog.pg_auth_members m ON (m.member = r.oid)
                        LEFT JOIN pg_roles r1 ON (m.roleid = r1.oid)
                        WHERE
                            r1.rolname = %s OR r.rolname = %s
                    ) AS table1
                    ON (public.plugin_role.role = table1.role OR public.plugin_role.role = table1.username)
                WHERE plugin = %s
            """, (userName, userName, pluginName))
        if cur.fetchall():
            return True
        return False