import sys, os, os.path
from .DataAccess import *
from .mylib import *
from .rassam import *
import xml.etree.ElementTree as ET
from .resources import *
from .search_gui import *
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import xlwt
from qgis.utils import iface

class Search(QtWidgets.QMainWindow):

    dataAccess = None
    dbConn = None
    fields = []
    result = []
    tableFieldTypes = {}
    translate = {}


    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        self.initUI()


    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(getAppDir() + '/gui/icons/search.png'))

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        self.ui.search.clicked.connect(self.search)
        self.ui.showInMap.clicked.connect(self.showInMap)
        self.ui.excelOut.clicked.connect(self.excelOut)
        self.ui.newSearch.clicked.connect(self.newSearch)

        self.show()
        self.listFields()


    # Send a message to the user.
    def msgUser(self, type, msg = None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    def listFields(self):

        self.msgUser('wait')

        if not self.tableFieldTypes:
            self.tableFieldTypes = self.dataAccess.getTableFieldTypes('subscriber')
            self.translate = self.dataAccess.getAllFaCols('subscriber')


        self.fields = []
        for col in self.tableFieldTypes.keys():
            colFa = self.translate.get(col)
            if colFa:
                field = {
                    'name': col,
                    'name_fa': colFa,
                    'type': self.tableFieldTypes[col]['data_type'],
                    'enum': self.tableFieldTypes[col]['data_type_name']
                }
                self.fields.append(field)

        self.ui.fields.setRowCount(len(self.fields))

        for row, field in enumerate(self.fields):
            item = QtWidgets.QTableWidgetItem(field['name_fa'])
            item.setFlags(item.flags() & ~QtCore.Qt.ItemIsSelectable & ~QtCore.Qt.ItemIsEditable)
            self.ui.fields.setItem(row, 0, item)
            if field['type'] == 'USER-DEFINED':
                colsCombo = QtWidgets.QComboBox(self)
                colsCombo.addItem('')
                colsCombo.addItems(strToList(field['enum']))
                colsCombo.setCurrentText(str(''))
                self.ui.fields.setCellWidget(row, 1, colsCombo)
            else:
                item = QtWidgets.QTableWidgetItem('')
                self.ui.fields.setItem(row, 1, item)
        header = self.ui.fields.horizontalHeader()       
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        self.msgUser('done')


    def getSearchFields(self):
        searchFields = {}
        for row, field in enumerate(self.fields):
            if field['type'] == 'USER-DEFINED':
                value = self.ui.fields.cellWidget(row, 1).currentText()
            else:
                value = self.ui.fields.item(row, 1).text()
            if value:
                searchFields[field['name']] = value
        return searchFields


    def search(self):

        self.msgUser('wait')

        self.emptySearch()

        searchFields = self.getSearchFields()
        if not searchFields:
            self.msgUser('fail', 'فیلتری انتخاب نشده است')
            return

        self.result = self.dataAccess.getNoSub(searchFields)
        if not self.result:
            self.msgUser('fail', 'مشترکی یافت نشد')
            return

        list = self.result
        allNames = self.dataAccess.getAllFaCols('no_subscribers')
        colNamesFa = {}
        self.listFa = []
        for key in list[0].keys():
            if key in allNames:
                colNamesFa[key] = allNames[key]
            else:
                colNamesFa[key] = None
        listInd = 0
        for aList in list:
            aListInd = 0
            self.listFa.append({})
            for key in aList.keys():
                if colNamesFa[key]:
                    if aList[key]:
                        self.listFa[listInd][colNamesFa[key]] = str(aList[key])
                    else:
                        self.listFa[listInd][colNamesFa[key]] = None
                aListInd = aListInd + 1
            listInd = listInd + 1 
        self.ui.result.setRowCount(len(list))
        listInd = 0
        for aList in self.listFa:
            aListInd = 0
            for key in aList.keys():
                if listInd == 0:
                    self.ui.result.setColumnCount(len(aList))
                    self.ui.result.setHorizontalHeaderItem(aListInd,
                        QtWidgets.QTableWidgetItem(key))
                item = QtWidgets.QTableWidgetItem(aList[key])
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)
                self.ui.result.setItem(listInd, aListInd, item)
                aListInd = aListInd + 1
            listInd = listInd + 1

        self.ui.result.resizeColumnsToContents()

        self.msgUser('none')


    def showInMap(self):
        if self.ui.result.currentRow() is None:
            return
        layer = get_layer_by_tablename('no_subscribers')
        if layer:
            layer.selectByExpression('"smid"={}'.format(self.result[self.ui.result.currentRow()]['smid']))
            iface.setActiveLayer(layer)
            iface.actionZoomToSelected().trigger()


    def excelOut(self):

        filePath = QtWidgets.QFileDialog.getSaveFileName(self, 'Save File', '', 'Excel (*.xls)')[0]

        self.msgUser('wait')

        xl = xlwt.Workbook()
        xl_sheet = xl.add_sheet("Sheet1", cell_overwrite_ok=True)
        xl_sheet.cols_right_to_left = True

        ind = 0
        for key in self.listFa[0].keys():
            xl_sheet.write(0, ind, key)
            ind += 1

        listInd = 1
        for aList in self.listFa:
            aListInd = 0
            for key in aList.keys():
                xl_sheet.write(listInd, aListInd, aList[key])
                aListInd = aListInd + 1
            listInd = listInd + 1

        xl.save(filePath)

        self.msgUser('success', 'خروجی اکسل ذخیره گردید')


    def emptySearch(self):
        while self.ui.result.rowCount() > 0:
            self.ui.result.removeRow(0)
        self.ui.result.clear()


    def newSearch(self):
        self.listFields()
        self.emptySearch()