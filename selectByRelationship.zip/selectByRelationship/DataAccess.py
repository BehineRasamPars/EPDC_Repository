import sys
import os
import os.path
import logging
import configparser
import psycopg2
import psycopg2.extras
from psycopg2 import sql
# from .mylib import *
from .rassam import *
from qgis.core import QgsProject

# ========================================================


class DataAccess:

    conf = {}

    def __init__(self , dBConnection, use_plugin):
        self.dbConn = dBConnection
        self.usePlugin = use_plugin
        self.updateConf()

    # Get a connection to the database.

    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')
        self.conf['DB_host'] = confFile['DB']['host']
        self.conf['DB_port'] = confFile['DB']['port']
        self.conf['DB_user'] = confFile['DB']['user']
        self.conf['DB_pass'] = confFile['DB']['pass']

    def updateConf(self):

        self.setConf()

        # File logging:
        if self.conf['fileLogging']:
            logging.basicConfig(filename=self.conf['logPath'],
                                format='%(asctime)s | %(levelname)s | %(message)s', level=logging.INFO)
        else:
            logging.disable()

    def findLayer(self, schema_name, layer_name):
        layers = QgsProject.instance().mapLayers()
        for layer_id, layer in layers.items():
            if '"'+schema_name+'"."'+layer_name+'"' in layer.source():
                return layer

    def Select_conjuction_points(self, layer_en_name, feature_id):
        cur = self.dbConn.cursor()
        query = """select class_name,class_fld, self_id from db_joins where par_class = '{active_layer_name}' """.format(active_layer_name=layer_en_name)
        cur.execute(query)
        child_table = cur.fetchall()
        for a_table in child_table:
            class_name = a_table[0]
            class_fld = a_table[1]
            self_id = a_table[2]

            query = """SELECT smid FROM  {classname} WHERE {classfld} = '{tableid}' """.format(
                selfid=self_id, classname=class_name, classfld=class_fld, tableid=feature_id)
            ids_list = []
            cur.execute(query)
            table_ids_res = cur.fetchall()
            for id in table_ids_res:
                ids_list.append(id[0])
            if cur.rowcount >= 0:
                lay = self.findLayer('public', class_name)
                if lay:
                    lay.select(ids_list)

    def Select_conjuction_points_for_multi_child(self, layer_en_name, feature_id):
        cur = self.dbConn.cursor()
        query = """select class_name,class_fld, self_id from db_joins where par_class = '{active_layer_name}' """.format(active_layer_name=layer_en_name)
        cur.execute(query)
        child_table = cur.fetchall()
        if cur.rowcount > 0:
            for a_table in child_table:
                
                class_name = a_table[0]
                class_fld = a_table[1]
                self_id = a_table[2]
                query = """SELECT smid,{selfid} FROM  {classname} WHERE {classfld} = '{tableid}' """.format(
                    selfid=self_id, classname=class_name, classfld=class_fld, tableid=feature_id)
                ids_list = []
                cur.execute(query)
                table_ids_res = cur.fetchall()
                if cur.rowcount > 0:
                    for id in table_ids_res:
                        ids_list.insert(1, id[0])
                        lay = self.findLayer('public', class_name)
                        if lay:
                            lay.select(ids_list)
                            self.Select_conjuction_points_for_multi_child(class_name, id[1])

    def Select_features_id(self, feature_name):
        try:
            cur = self.dbConn.cursor()
            query = """
                    select self_id from db_joins where class_name = '{featurename}'
                """.format(featurename=feature_name)
            cur.execute(query)
            rows = cur.fetchall()
            featurename_list = []
            for id in rows:
                featurename_list.append(id[0])

            return featurename_list[0]
        except Exception as e:
            logging.error(e)
            return False

    def Persain_name_of_table(self, persian_name_of_table):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """
                    select smdatasetname from smregister WHERE smtablename = '{english_name}'
                """.format(english_name=persian_name_of_table)
            cur.execute(query)
            rows = cur.fetchall()
            print(rows)
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def Child_class(self, english_name_of_table):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """
                    select class_name from {db_joins} WHERE where par_class = '{english_name}'
                """.format(db_joins=[], english_name=english_name_of_table)
            cur.execute(query)
            rows = cur.fetchall()
            print(rows)
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getTableList(self):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT table_name AS name_en, smtablename AS name_fa FROM table_list tl
                    LEFT JOIN smregister s ON (tl.table_name = s.smdatasetname)
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getPostList(self):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT * FROM (
                    SELECT DISTINCT ON (subst_code)
                        subf_name, subst_code, COALESCE(substat.conv_ratio, tank.conv_fatio) AS conv_ratio, substat.smid
                        FROM substat
                    LEFT JOIN
                        pow_tran USING (subst_code)
                    LEFT JOIN
                        tank ON (pow_tran.ptran_id = tank.tra_rac_id)
                ) t1  ORDER BY subf_name;    
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getCircuitList(self):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT cir_name, circt_id, nomi_vol, smid FROM circuit ORDER BY cir_name
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getTableIds(self, main_table, con_table, con_idvalue):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT * FROM UNNEST(get_ids(%s, %s, %s))
                """, (main_table, con_table, con_idvalue,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getRelatedTables(self, main_table, con_idvalue):
        try:
            cur = self.dbConn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM UNNEST(get_related_tables(%s, %s))
                """, (main_table, con_idvalue,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def translate(self, outLan, inValue):
        inLan = ''
        if outLan == 'fa':
            inLan = 'en'
        elif outLan == 'en':
            inLan = 'fa'
        try:
            cur = self.dbConn.cursor()
            query = sql.SQL("""
                    SELECT DISTINCT ON (en)
                        {}
                    FROM (
                        SELECT smdatasetname AS en, smtablename AS fa FROM public.smregister
                        UNION
                        SELECT smfieldname AS en, smfieldcaption AS fa FROM public.smfieldinfo
                    ) t1
                    WHERE {} = %s
                    LIMIT 1
                """).format(sql.Identifier(outLan), sql.Identifier(inLan))
            cur.execute(query, (inValue,))
            data = cur.fetchone()
            if data:
                data = data[0]
            else:
                data = None
            return data
        except Exception as e:
            print(e)
            logging.error(e)
            return False

    def isTableGeo(self, tableName):
        try:
            cur = self.dbConn.cursor()
            query = sql.SQL("""
                    SELECT is_table_geo(%s)
                """)
            cur.execute(query, (tableName,))
            data = cur.fetchone()[0]
            return data
        except Exception as e:
            logging.error(e)
            return False
