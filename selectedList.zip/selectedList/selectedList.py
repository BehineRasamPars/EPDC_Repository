import os
import os.path
from PyQt5 import QtWidgets, QtCore, QtGui
from .resources import *
from qgis.PyQt.QtWidgets import QMenu, QTableWidgetItem
# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .selectedList_dialog import selectedListDialog
from qgis import utils, core, gui
from geographiclib.geodesic import Geodesic
from .rassam import *
from .inputData_dialog import inputDataDialog
from .mylib import *


class MapTool(gui.QgsMapTool):
    def __init__(self, iface, canvas):
        super(MapTool, self).__init__(canvas)
        self._x_point = None
        self._y_point = None

    @property
    def x_point(self):
        return self._x_point

    @x_point.setter
    def x_point(self, value):
        if self._x_point != value:
            self._x_point = value
            # Call the callback function when the value changes
            if self._value_change_callback:
                self._value_change_callback()

    @property
    def y_point(self):
        return self._y_point

    @y_point.setter
    def y_point(self, value):
        if self._y_point != value:
            self._y_point = value
            # Call the callback function when the value changes
            if self._value_change_callback:
                self._value_change_callback()

    def set_value_change_callback(self, callback):
        self._value_change_callback = callback

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.x_point = point.x()
        self.y_point = point.y()


class SelectedList_GUI(QtWidgets.QMainWindow):
    def __init__(self, usePlugin):
        super().__init__()
        self.epsg4326 = core.QgsCoordinateReferenceSystem("EPSG:4326")
        self.geod = Geodesic.WGS84
        self.usePlugin = usePlugin
        self.plugin_dir = os.path.dirname(__file__)
        self.project = core.QgsProject.instance()
        self.initUI()

    def initUI(self):
        self.dlg = selectedListDialog()
        self.input_data = inputDataDialog()
        self.mainwindow = utils.iface.mainWindow()
        # self.changeDialogToMid()
        self.trigger_functions()
        self.run()

    def getConn(self):
        return self.usePlugin.dBConnection.getConn()

    def trigger_functions(self):
        self.dlg.layersList.itemSelectionChanged.connect(self.fillItemsOfLayer)

    def initial_prep(self):
        self.initial_msgBox()
        self.conn = self.getConn()
        self.Help_Menu()
        self.DeleteMenu()
        return True

    def initial_msgBox(self):
        self.msgBox = QtWidgets.QMessageBox()
        self.msgBox.addButton(QtWidgets.QPushButton("باشد"),
                              QtWidgets.QMessageBox.YesRole)

    def msgUser(self, type, msg=None):  # Send a message to the user.
        if type == 'success':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("موفقیت")
        elif type == 'fail':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("شکست")
        result = self.msgBox.exec_()
        # QtWidgets.qApp.processEvents()

    def run(self):
        """Run method that performs all the real work"""
        prep = self.initial_prep()
        self.fillSelectedLayer()
        if prep:
            self.dlg.show()
            result = self.dlg.exec_()
            if result:
                pass

    def setObjectFont(self, object):
        object.setStyleSheet("font-size: 14px; font-family: B Nazanin")

    def DeleteMenu(self):
        btn = self.dlg.ToolsBtn
        btn.setIcon(QIcon(os.path.dirname(__file__) + '/icons/spanner.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        self.delete_all = menu.addAction("حذف همه عوارض", self.delete_all_func)
        self.delete_all.setIcon(
            QIcon(os.path.dirname(__file__) + '/icons/delete_all.png'))
        self.rotate_all = menu.addAction("چرخش همه عوارض", self.rotateAll)
        self.rotate_all.setIcon(
            QIcon(os.path.dirname(__file__) + '/icons/rotation.png'))
        # self.changeToolsBtnActivity(False)
        self.dlg.ToolsBtn.setMenu(menu)

    def deselect_all(self):
        """ Deselect every feature """
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, core.QgsVectorLayer):
                layer.removeSelection()

    # def delete_layers(self):
    #     current_table_name = self.currentLayersListItem()
    #     layer = self.project.mapLayersByName(current_table_name)[0]
    #     reply = self.YesNoMessage('آیا از حذف عارضه های لایه ی انتخاب شده مطمئن هستید؟')
    #     if isinstance(layer, core.QgsVectorLayer):
    #         features = layer.selectedFeatures()
    #         features_id = [feature.id() for feature in features]
    #         if reply == QtWidgets.QMessageBox.Yes and features:
    #             layer.startEditing()
    #             layer.deleteFeatures(features_id)
    #             layer.triggerRepaint()
    #         self.deselect_all()

    def rotate_layers_selected_point_func(self):
        self.winInput_data.close()
        x_value, y_value, angle = self.get_rotate_data()
        if x_value and y_value and angle:
            for layer in self.all_layers:
                geom_to_4326, to_sink_crs = self.transformDetails(layer)
                layer.startEditing()
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    self.rotateLayersFeature(
                        x_value, y_value, angle, layer, geom_to_4326, to_sink_crs, features)
                layer.updateExtents()
                utils.iface.mapCanvas().refresh()

    def rotateLayersFeature(self, x_value, y_value, rotation_angle, layer, geom_to_4326, to_sink_crs, features):
        for feature in features:
            geometry = feature.geometry()
            feature = self.changeAngleIfExists(feature, rotation_angle, layer)
            layer.updateFeature(feature)
            centroid = geom_to_4326.transform(float(x_value), float(y_value))
            self.moveVerticesOfFeatures(
                geom_to_4326, to_sink_crs, geometry, rotation_angle, centroid)
            layer.changeGeometry(feature.id(), geometry)

    def changeAngleIfExists(self, feature, rotation_angle, layer):
        is_exists = self.checkAngleExist(layer)
        if is_exists:
            new_angle = rotation_angle + feature['angle']
            new_angle = new_angle if new_angle < 360 else new_angle - 360
            feature.setAttribute('angle', new_angle)
        return feature

    def checkAngleExist(self, layer):
        attribute_keys = [field.name() for field in layer.fields()]
        return 'angle' in attribute_keys

    def moveVerticesOfFeatures(self, geom_to_4326, to_sink_crs, geometry, rotation_angle, centroid):
        cy = centroid.y()
        cx = centroid.x()
        vertices = geometry.vertices()
        for vcnt, vertex in enumerate(vertices):
            v = geom_to_4326.transform(vertex.x(), vertex.y())
            gline = self.geod.Inverse(cy, cx, v.y(), v.x())
            vdist = gline['s12']
            vazi = gline['azi1']
            vazi -= rotation_angle
            g = self.geod.Direct(cy, cx, vazi, vdist,
                                 Geodesic.LATITUDE | Geodesic.LONGITUDE)
            new_vertex = to_sink_crs.transform(g['lon2'], g['lat2'])
            geometry.moveVertex(new_vertex.x(), new_vertex.y(), vcnt)

    def transformDetails(self, layer):
        src_crs = layer.sourceCrs()
        geom_to_4326 = core.QgsCoordinateTransform(
            src_crs, self.epsg4326, QgsProject.instance())
        to_sink_crs = core.QgsCoordinateTransform(
            self.epsg4326, src_crs, QgsProject.instance())
        return geom_to_4326, to_sink_crs

    def get_rotate_data(self):
        x_value = self.input_data.x_input.text()
        y_value = self.input_data.y_input.text()
        angle = self.input_data.angle_input.value()
        self.input_data.accept()
        return x_value, y_value, angle

    def initialRotateDataWindow(self):
        self.dlg.showMinimized()
        self.winInput_data = QtWidgets.QDialog()
        self.input_data.setupUi(self.winInput_data)

    def rotateAll(self):
        is_feature_selected = self.checkIsAnyLayer()
        if is_feature_selected:
            self.initialRotateDataWindow()
            self.winInput_data.show()
            self.input_data.rotate_btn.clicked.connect(
                self.rotate_layers_selected_point_func)
            tool = MapTool(utils.iface, utils.iface.mapCanvas())
            tool.set_value_change_callback(lambda: self.fill_coord_data(tool))
            utils.iface.mapCanvas().setMapTool(tool)

    def fill_coord_data(self, tool):
        if tool.x_point and tool.y_point:
            self.input_data.x_input.setText(str(tool.x_point))
            self.input_data.y_input.setText(str(tool.y_point))

    def YesNoMessage(self, message):
        messageBox = QtWidgets.QMessageBox()
        reply = messageBox.question(utils.iface.mainWindow(), 'اخطار',
                                    message, QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No)
        return reply

    def delete_all_func(self):
        is_feature_selected = self.checkIsAnyLayer()
        if is_feature_selected:
            reply = self.YesNoMessage(
                'آیا از حذف عارضه های لایه های انتخاب شده مطمئن هستید؟')
            for layer in self.all_layers:
                features_id = []
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    features_id = [feature.id() for feature in features]
                    if reply == QtWidgets.QMessageBox.Yes and features:
                        layer.startEditing()
                        layer.deleteFeatures(features_id)
                layer.triggerRepaint()
            self.deselect_all()

    def checkIsAnyLayer(self):
        for layer in self.all_layers:
            if isinstance(layer, core.QgsVectorLayer):
                features = layer.selectedFeatures()
                if features:
                    return True
        self.msgUser('fail', 'لایه یا عارضه ای انتخاب نشده است')
        return False

    def Help_Menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(os.path.dirname(__file__) + '/icons/help.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        i = menu.addAction("PDF", self.Action1)
        i.setIcon(QIcon(os.path.dirname(__file__) + '/icons/pdfhelp.png'))
        z = menu.addAction("ویدیو", self.Action2)
        z.setIcon(QIcon(os.path.dirname(__file__) + '/icons/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def Action1(self):
        self.Help_Btn()

    def Action2(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def Help_Btn(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def fillSelectedLayer(self):
        self.clearList(self.dlg.layersList)
        self.setHeaderSizePolicy()
        self.all_layers = []
        for layer_id, layer in self.project.mapLayers().items():
            if isinstance(layer, core.QgsVectorLayer):
                # Get the selected features from the layer
                selected = layer.selectedFeatures()
                if selected:
                    self.all_layers.append(layer)
                    row_count = self.configRowCount(self.dlg.layersList)

                    layer_name = layer.name()
                    layer_count = str(len(selected))

                    name_item = QTableWidgetItem(layer_name)
                    count_item = QTableWidgetItem(layer_count)

                    self.fillLayersListItem(row_count, name_item, count_item)

    def setHeaderSizePolicy(self):
        header = self.dlg.layersList.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)

    def fillLayersListItem(self, row_count, name_item, count_item):
        self.setAlignment(name_item)
        self.dlg.layersList.setItem(row_count, 1, name_item)
        self.setAlignment(count_item)
        self.dlg.layersList.setItem(row_count, 0, count_item)

    def fillItemsOfLayer(self):
        # self.changeToolsBtnActivity(True)
        current_table_name = self.currentLayersListItem()
        layer = self.project.mapLayersByName(current_table_name)[0]
        if layer:
            self.setHorizontalLabel(layer)
            for feature in layer.selectedFeatures():
                row_count = self.configRowCount(self.dlg.itemsOfLayer)
                attributes = feature.attributes()
                for col, each_attr in enumerate(attributes):
                    item = QTableWidgetItem(str(each_attr))
                    self.setAlignment(item)
                    self.dlg.itemsOfLayer.setItem(row_count, col, item)

    def changeToolsBtnActivity(self, is_active):
        self.delete_all.setEnabled(is_active)
        self.rotate_all.setEnabled(is_active)

    def setAlignment(self, item):
        item.setTextAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignHCenter)

    def currentLayersListItem(self):
        current_row = self.dlg.layersList.currentRow()
        current_table_name = self.dlg.layersList.item(current_row, 1)
        return current_table_name.text()

    def setHorizontalLabel(self, layer):
        field_names = [field.displayName() for field in layer.fields()]
        self.clearList(self.dlg.itemsOfLayer)
        self.dlg.itemsOfLayer.setColumnCount(len(field_names))
        self.dlg.itemsOfLayer.setHorizontalHeaderLabels(field_names)

    def configRowCount(self, table_name):
        row_count = table_name.rowCount()
        table_name.setRowCount(row_count+1)
        return row_count

    def clearList(self, layer_name):
        layer_name.clearContents()  # Clear the table contents
        layer_name.setRowCount(0)

    def buildLayerToGroupMapping(self, node, current_group=None):
        if node.nodeType() == 0:  # 0 indicates a layer node
            layer_name = node.name()
            if layer_name not in self.layer_to_group:
                self.layer_to_group[layer_name] = current_group
        elif node.nodeType() == 1:  # 1 indicates a group node
            current_group = node
        for child_node in node.children():
            self.buildLayerToGroupMapping(child_node, current_group)
