import os
import os.path
from PyQt5 import QtWidgets, QtCore, QtGui
from .resources import *
from qgis.PyQt.QtWidgets import QMenu, QTableWidgetItem
# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .selectedList_dialog import selectedListDialog
from qgis import utils, core, gui
from geographiclib.geodesic import Geodesic
from .rassam import *
from .inputData_dialog import inputDataDialog
from .mylib import *


class MapTool(gui.QgsMapTool):
    def __init__(self, iface, canvas):
        super(MapTool, self).__init__(canvas)
        self._x_point = None
        self._y_point = None

    @property
    def x_point(self):
        return self._x_point

    @x_point.setter
    def x_point(self, value):
        if self._x_point != value:
            self._x_point = value
            # Call the callback function when the value changes
            if self._value_change_callback:
                self._value_change_callback()

    @property
    def y_point(self):
        return self._y_point

    @y_point.setter
    def y_point(self, value):
        if self._y_point != value:
            self._y_point = value
            # Call the callback function when the value changes
            if self._value_change_callback:
                self._value_change_callback()

    def set_value_change_callback(self, callback):
        self._value_change_callback = callback

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.x_point = point.x()
        self.y_point = point.y()


class SelectedList_GUI(QtWidgets.QMainWindow):
    unique_fields = ['"ID"', 'pl_mds_cod', 'feeder_code']
    none_ignore_fields = ['smid', 'op_status','connection_status','cnctn_sit','con_statuse']
    def __init__(self, usePlugin):
        super().__init__()
        self.epsg4326 = core.QgsCoordinateReferenceSystem("EPSG:4326")
        self.geod = Geodesic.WGS84
        self.usePlugin = usePlugin
        self.plugin_dir = os.path.dirname(__file__)
        self.project = core.QgsProject.instance()
        self.initUI()

    def initUI(self):
        self.dlg = selectedListDialog()
        self.input_data = inputDataDialog()
        self.source_coord = inputDataDialog()
        self.mainwindow = utils.iface.mainWindow()
        # self.changeDialogToMid()
        self.trigger_functions()
        self.run()

    def getConn(self):
        return self.usePlugin.dBConnection.getConn()

    def trigger_functions(self):
        self.dlg.layersList.itemSelectionChanged.connect(self.fillItemsOfLayer)

    def initial_prep(self):
        self.initial_msgBox()
        self.conn = self.getConn()
        self.Help_Menu()
        self.DeleteMenu()
        return True

    def initial_msgBox(self):
        self.msgBox = QtWidgets.QMessageBox()
        self.msgBox.addButton(QtWidgets.QPushButton("باشد"),
                              QtWidgets.QMessageBox.YesRole)

    def msgUser(self, type, msg=None):  # Send a message to the user.
        if type == 'success':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("موفقیت")
        elif type == 'fail':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("شکست")
        result = self.msgBox.exec_()
        # QtWidgets.qApp.processEvents()

    def run(self):
        """Run method that performs all the real work"""
        prep = self.initial_prep()
        self.fillSelectedLayer()
        self.initialRotateDataWindow()
        if prep:
            self.dlg.show()
            result = self.dlg.exec_()
            if result:
                pass

    def setObjectFont(self, object):
        object.setStyleSheet("font-size: 14px; font-family: B Nazanin")

    def DeleteMenu(self):
        btn = self.dlg.ToolsBtn
        btn.setIcon(QIcon(os.path.dirname(__file__) + '/icons/spanner.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        self.delete_all = menu.addAction("حذف همه عوارض", self.delete_all_func)
        self.delete_all.setIcon(
            QIcon(os.path.dirname(__file__) + '/icons/delete_all.png'))
        self.rotate_all = menu.addAction("چرخش همه عوارض", self.rotateAll)
        self.rotate_all.setIcon(
            QIcon(os.path.dirname(__file__) + '/icons/rotation.png'))
        self.copy_all = menu.addAction("کپی همه عوارض", self.copyAll)
        self.copy_all.setIcon(
            QIcon(os.path.dirname(__file__) + '/icons/copy_all.png'))
        # self.changeToolsBtnActivity(False)
        self.dlg.ToolsBtn.setMenu(menu)

    def deselect_all(self):
        """ Deselect every feature """
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, core.QgsVectorLayer):
                layer.removeSelection()

    def show_message(self,header, message, level,duration=7):
        utils.iface.messageBar().clearWidgets()
        utils.iface.messageBar().pushMessage(header, message, level,duration=duration)
        
    def rotate_layers_selected_point_func(self):
        x_value, y_value, angle = self.get_rotate_data()
        if x_value and y_value and angle:
            self.show_message('نتیجه','در حال چرخش همه عوارض',utils.Qgis.Warning,10)
            for layer in self.all_layers:
                geom_to_4326, to_sink_crs = self.transformDetails(layer)
                layer.startEditing()
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    self.rotateLayersFeature(
                        x_value, y_value, angle, layer, geom_to_4326, to_sink_crs, features)
                layer.updateExtents()
                utils.iface.mapCanvas().refresh()
            self.clear_close_geom_angle_dialog()
            self.show_message('نتیجه','چرخش عوارض با موفقیت انجام شد',utils.Qgis.Success,10)
            self.dlg.close()

    def copy_layers_selected_point_func(self):

        x_value, y_value, angle = self.get_destination_geometry_data()
        if x_value and y_value:
            self.show_message('نتیجه','در حال کپی همه عوارض',utils.Qgis.Warning,10)
            base_coord_detial = self.get_coord_details()
            for layer in self.all_layers:
                geom_to_4326, to_sink_crs = self.transformDetails(layer)
                layer.startEditing()
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    self.copyLayersFeature(
                        x_value, y_value, angle, layer, geom_to_4326, to_sink_crs, features, base_coord_detial)
                # layer.commitChanges()
                utils.iface.mapCanvas().refresh()
            self.clear_close_geom_angle_dialog()
            self.show_message('نتیجه','کپی عوارض با موفقیت انجام شد',utils.Qgis.Success,10)
            self.dlg.close()

    def get_coord_details(self):
        x_value = self.source_coord.x_input.text()
        y_value = self.source_coord.y_input.text()
        return {'x': x_value, 'y':y_value}
    
    def clear_close_geom_angle_dialog(self):
        self.input_data.x_input.clear()
        self.input_data.y_input.clear()
        self.input_data.angle_input.setValue(0)
        self.winInput_data.close()

    def rotateLayersFeature(self, x_value, y_value, rotation_angle, layer, geom_to_4326, to_sink_crs, features):
        for feature in features:
            geometry = feature.geometry()
            feature = self.changeAngleIfExists(feature, rotation_angle, layer)
            layer.updateFeature(feature)
            centroid = geom_to_4326.transform(float(x_value), float(y_value))
            self.moveVerticesOfFeatures(
                geom_to_4326, to_sink_crs, geometry, rotation_angle, centroid)
            layer.changeGeometry(feature.id(), geometry)

    def copyLayersFeature(self, x_value, y_value, rotation_angle, layer, geom_to_4326, to_sink_crs, features, base_coord_detail):
        field_names = layer.fields()
        for feature in features:
            geometry = self.create_new_geometry(feature.geometry(),base_coord_detail,x_value,y_value)
            new_feat = core.QgsFeature()
            new_feat.setGeometry(geometry)
            new_feat.setFields(field_names)
            for field_index, field_name in enumerate(field_names):
                has_cons = layer.fieldConstraintsAndStrength(field_index)
                if has_cons and field_name.name() not in self.none_ignore_fields : continue
                attribute_value = feature.attribute(field_name.name())
                new_feat.setAttribute(field_name.name(), attribute_value)
            new_feat = self.changeAngleIfExists(new_feat, rotation_angle, layer)
            layer.addFeature(new_feat)
            if rotation_angle != 0:
                centroid = geom_to_4326.transform(float(x_value), float(y_value))
                self.moveVerticesOfFeatures(
                    geom_to_4326, to_sink_crs, geometry, rotation_angle, centroid)
            layer.changeGeometry(new_feat.id(), geometry)

    def create_new_geometry(self, feature_geometry,base_coord_detail,x_value,y_value):
        if feature_geometry.wkbType() == core.QgsWkbTypes.Point:
            feature_x = feature_geometry.asPoint().x()
            feature_y = feature_geometry.asPoint().y()
            geometry = core.QgsGeometry.fromPointXY(core.QgsPointXY(
                float(x_value) -  (float(base_coord_detail['x']) - feature_geometry.asPoint().x()),
                float(y_value) -  (float(base_coord_detail['y']) - feature_geometry.asPoint().y())
            ))
        elif feature_geometry.wkbType() == core.QgsWkbTypes.LineString:
            geom_list = []
            line_geometry = feature_geometry.asPolyline()
            for each_point in line_geometry:
                feature_x = each_point.x()
                feature_y = each_point.y()
                each_geometry = core.QgsGeometry.fromPointXY(core.QgsPointXY(
                    float(x_value) -  (float(base_coord_detail['x']) - feature_x),
                    float(y_value) -  (float(base_coord_detail['y']) - feature_y)
                ))
                geom_list.append(each_geometry.asPoint())
                geometry = core.QgsGeometry.fromPolyline(geom_list)

        elif feature_geometry.wkbType() == core.QgsWkbTypes.MultiLineString:
            geom_list = []
            multiline_geometry = feature_geometry.asMultiPolyline()
            for each_line in multiline_geometry[0]:
                feature_x = each_line.x()
                feature_y = each_line.y()
                each_geometry = core.QgsGeometry.fromPointXY(core.QgsPointXY(
                    float(x_value) -  (float(base_coord_detail['x']) - feature_x),
                    float(y_value) -  (float(base_coord_detail['y']) - feature_y)
                ))
                geom_list.append(each_geometry.asPoint())
                geometry = core.QgsGeometry.fromMultiPolylineXY([geom_list])

        elif feature_geometry.wkbType() == core.QgsWkbTypes.Polygon:
            geom_list = []
            polygon_geometry = feature_geometry.asPolygon()
            for each_pol in polygon_geometry[0]:
                feature_x = each_pol.x()
                feature_y = each_pol.y()
                each_geometry = core.QgsGeometry.fromPointXY(core.QgsPointXY(
                    float(x_value) -  (float(base_coord_detail['x']) - feature_x),
                    float(y_value) - (float(base_coord_detail['y']) - feature_y)
                ))
                geom_list.append(each_geometry.asPoint())
                geometry = core.QgsGeometry.fromPolygonXY([geom_list])

        return geometry

    def changeAngleIfExists(self, feature, rotation_angle, layer):
        is_exists = self.checkAngleExist(layer)
        if is_exists:
            # prev_angle = prev_feat['angle'] if prev_feat else feature['angle']
            new_angle = feature['angle'] - rotation_angle
            new_angle = new_angle if new_angle < 360 else new_angle - 360
            feature.setAttribute('angle', new_angle)
        return feature

    def checkAngleExist(self, layer):
        attribute_keys = [field.name() for field in layer.fields()]
        return 'angle' in attribute_keys

    def moveVerticesOfFeatures(self, geom_to_4326, to_sink_crs, geometry, rotation_angle, centroid):
        cy = centroid.y()
        cx = centroid.x()
        vertices = geometry.vertices()
        for vcnt, vertex in enumerate(vertices):
            v = geom_to_4326.transform(vertex.x(), vertex.y())
            gline = self.geod.Inverse(cy, cx, v.y(), v.x())
            vdist = gline['s12']
            vazi = gline['azi1']
            vazi -= rotation_angle
            g = self.geod.Direct(cy, cx, vazi, vdist,
                                 Geodesic.LATITUDE | Geodesic.LONGITUDE)
            new_vertex = to_sink_crs.transform(g['lon2'], g['lat2'])
            geometry.moveVertex(new_vertex.x(), new_vertex.y(), vcnt)

    def transformDetails(self, layer):
        src_crs = layer.sourceCrs()
        geom_to_4326 = core.QgsCoordinateTransform(
            src_crs, self.epsg4326, QgsProject.instance())
        to_sink_crs = core.QgsCoordinateTransform(
            self.epsg4326, src_crs, QgsProject.instance())
        return geom_to_4326, to_sink_crs

    def get_rotate_data(self):
        x_value = self.input_data.x_input.text()
        y_value = self.input_data.y_input.text()
        angle = self.input_data.angle_input.value()
        self.input_data.accept()
        return x_value, y_value, angle
    
    def get_destination_geometry_data(self):
        return self.get_rotate_data()

    def initialRotateDataWindow(self):
        # self.dlg.showMinimized()
        self.winInput_data = QtWidgets.QDialog()
        self.winInput_data.setWindowFlags(self.winInput_data.windowFlags() | QtCore.Qt.CustomizeWindowHint)
        self.winInput_data.setWindowFlags(self.winInput_data.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        self.winInput_data.setWindowFlags(self.winInput_data.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.input_data.setupUi(self.winInput_data)

    def rotateAll(self):
        is_feature_selected = self.checkIsAnyLayer()
        self.change_text_with_sender(self.sender().text())
        if is_feature_selected:
            self.winInput_data.show()
            self.input_data.rotate_btn.clicked.connect(
                self.rotate_layers_selected_point_func)
            tool = MapTool(utils.iface, utils.iface.mapCanvas())
            tool.set_value_change_callback(lambda: self.fill_coord_data(tool,self.input_data))
            utils.iface.mapCanvas().setMapTool(tool)


    def copyAll(self):
        is_feature_selected = self.checkIsAnyLayer()
        self.change_text_with_sender(self.sender().text())
        if is_feature_selected:
            self.create_source_coord_dialog()
            self.source_coord_dialog.show()
            self.source_coord.rotate_btn.clicked.connect(lambda: self.copyWithBaseCoord(tool))
            tool = MapTool(utils.iface, utils.iface.mapCanvas())
            tool.set_value_change_callback(lambda: self.fill_coord_data(tool,self.source_coord))
            utils.iface.mapCanvas().setMapTool(tool)

    def change_text_with_sender(self,sender_object_text):
        if sender_object_text == 'کپی همه عوارض':
            label_text = 'لطفا نقطه مقصد مورد نظر را را از روی نقشه انتخاب کنید! '
            button_text = 'کپی'
        else :
            label_text ='یک نقطه را به عنوان مبدا از روی نقشه انتخاب کنید'
            button_text = 'چرخش'
        self.input_data.label.setText(label_text)
        self.input_data.rotate_btn.setText(button_text)

    def copyWithBaseCoord(self, tool):
        self.source_coord_dialog.close()
        self.winInput_data.show()
        self.input_data.rotate_btn.clicked.connect(
                self.copy_layers_selected_point_func)
        tool.set_value_change_callback(lambda: self.fill_coord_data(tool,self.input_data))
        utils.iface.mapCanvas().setMapTool(tool)

        

    def fill_coord_data(self, tool, object_data):
        if tool.x_point and tool.y_point:
            object_data.x_input.setText(str(tool.x_point))
            object_data.y_input.setText(str(tool.y_point))

    def create_source_coord_dialog(self):
        self.source_coord_dialog = QtWidgets.QDialog()
        self.source_coord_dialog.setWindowFlags(self.source_coord_dialog.windowFlags() | QtCore.Qt.CustomizeWindowHint)
        self.source_coord_dialog.setWindowFlags(self.source_coord_dialog.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        self.source_coord_dialog.setWindowFlags(self.source_coord_dialog.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.source_coord.setupUi(self.source_coord_dialog)
        self.source_coord.angle_input.hide()
        self.source_coord.rotate_btn.setText('انتخاب')

    def YesNoMessage(self, message):
        messageBox = QtWidgets.QMessageBox()
        reply = messageBox.question(utils.iface.mainWindow(), 'اخطار',
                                    message, QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No)
        return reply

    def delete_all_func(self):
        is_feature_selected = self.checkIsAnyLayer()
        if is_feature_selected:
            reply = self.YesNoMessage(
                'آیا از حذف عارضه های لایه های انتخاب شده مطمئن هستید؟')
            for layer in self.all_layers:
                features_id = []
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    features_id = [feature.id() for feature in features]
                    if reply == QtWidgets.QMessageBox.Yes and features:
                        layer.startEditing()
                        layer.deleteFeatures(features_id)
                layer.triggerRepaint()
            self.deselect_all()
        self.show_message('نتیجه','حذف همه عوارض با موفقیت انجام شد',utils.Qgis.Success,10)
        self.dlg.close()

    def checkIsAnyLayer(self):
        for layer in self.all_layers:
            if isinstance(layer, core.QgsVectorLayer):
                features = layer.selectedFeatures()
                if features:
                    return True
        self.msgUser('fail', 'لایه یا عارضه ای انتخاب نشده است')
        return False

    def Help_Menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(os.path.dirname(__file__) + '/icons/help.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        i = menu.addAction("PDF", self.Action1)
        i.setIcon(QIcon(os.path.dirname(__file__) + '/icons/pdfhelp.png'))
        z = menu.addAction("ویدیو", self.Action2)
        z.setIcon(QIcon(os.path.dirname(__file__) + '/icons/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def Action1(self):
        self.Help_Btn()

    def Action2(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def Help_Btn(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def fillSelectedLayer(self):
        self.clearList(self.dlg.layersList)
        self.setHeaderSizePolicy()
        self.all_layers = []
        for layer_id, layer in self.project.mapLayers().items():
            if isinstance(layer, core.QgsVectorLayer):
                # Get the selected features from the layer
                selected = layer.selectedFeatures()
                if selected:
                    self.all_layers.append(layer)
                    row_count = self.configRowCount(self.dlg.layersList)

                    layer_name = layer.name()
                    layer_count = str(len(selected))

                    name_item = QTableWidgetItem(layer_name)
                    count_item = QTableWidgetItem(layer_count)

                    self.fillLayersListItem(row_count, name_item, count_item)

    def setHeaderSizePolicy(self):
        header = self.dlg.layersList.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)

    def fillLayersListItem(self, row_count, name_item, count_item):
        self.setAlignment(name_item)
        self.dlg.layersList.setItem(row_count, 1, name_item)
        self.setAlignment(count_item)
        self.dlg.layersList.setItem(row_count, 0, count_item)

    def fillItemsOfLayer(self):
        # self.changeToolsBtnActivity(True)
        current_table_name = self.currentLayersListItem()
        layer = self.project.mapLayersByName(current_table_name)[0]
        if layer:
            self.setHorizontalLabel(layer)
            for feature in layer.selectedFeatures():
                row_count = self.configRowCount(self.dlg.itemsOfLayer)
                attributes = feature.attributes()
                for col, each_attr in enumerate(attributes):
                    item = QTableWidgetItem(str(each_attr))
                    self.setAlignment(item)
                    self.dlg.itemsOfLayer.setItem(row_count, col, item)

    def changeToolsBtnActivity(self, is_active):
        self.delete_all.setEnabled(is_active)
        self.rotate_all.setEnabled(is_active)

    def setAlignment(self, item):
        item.setTextAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignHCenter)

    def currentLayersListItem(self):
        current_row = self.dlg.layersList.currentRow()
        current_table_name = self.dlg.layersList.item(current_row, 1)
        return current_table_name.text()

    def setHorizontalLabel(self, layer):
        field_names = [field.displayName() for field in layer.fields()]
        self.clearList(self.dlg.itemsOfLayer)
        self.dlg.itemsOfLayer.setColumnCount(len(field_names))
        self.dlg.itemsOfLayer.setHorizontalHeaderLabels(field_names)

    def configRowCount(self, table_name):
        row_count = table_name.rowCount()
        table_name.setRowCount(row_count+1)
        return row_count

    def clearList(self, layer_name):
        layer_name.clearContents()  # Clear the table contents
        layer_name.setRowCount(0)

    def buildLayerToGroupMapping(self, node, current_group=None):
        if node.nodeType() == 0:  # 0 indicates a layer node
            layer_name = node.name()
            if layer_name not in self.layer_to_group:
                self.layer_to_group[layer_name] = current_group
        elif node.nodeType() == 1:  # 1 indicates a group node
            current_group = node
        for child_node in node.children():
            self.buildLayerToGroupMapping(child_node, current_group)
