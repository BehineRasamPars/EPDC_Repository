import os
import os.path
from PyQt5 import QtWidgets , QtCore 
from .resources import *
from qgis.PyQt.QtWidgets import QMenu , QTableWidgetItem
# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .selectedList_dialog import selectedListDialog
from qgis import utils , core , gui
from .rassam import *
from .mylib import *


class SelectedList_GUI(QtWidgets.QMainWindow):
    # layer_to_group = {}
    def __init__(self, usePlugin):
        super().__init__()
        self.usePlugin = usePlugin
        self.plugin_dir = os.path.dirname(__file__)
        self.project = core.QgsProject.instance()
        self.initUI()

    def initUI(self):
        self.dlg = selectedListDialog()
        self.mainwindow = utils.iface.mainWindow()
        self.triger_functions()
        self.run()

    def getConn(self):
        return self.usePlugin.dBConnection.getConn()

    def triger_functions(self):
        self.dlg.layersList.itemSelectionChanged.connect(self.fillItemsOfLayer)

    def initial_prep(self):
        self.initial_msgBox()
        self.all_layers = []
        self.conn = self.getConn()
        self.Help_Menu()
        self.DeleteMenu()
        return True

        
    def initial_msgBox(self):
        self.msgBox = QtWidgets.QMessageBox()
        self.msgBox.addButton(QtWidgets.QPushButton("باشد"),
                              QtWidgets.QMessageBox.YesRole)

    def msgUser(self, type, msg=None):  # Send a message to the user.
        if type == 'success':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("موفقیت")
        elif type == 'fail':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("شکست")
        result = self.msgBox.exec_()
        # QtWidgets.qApp.processEvents()

    def run(self):
        """Run method that performs all the real work"""
        prep = self.initial_prep()
        self.fillSelectedLayer()
        if prep:
            self.dlg.show()
            result = self.dlg.exec_()
            if result:
                pass    

    def setObjectFont(self , object):
        object.setStyleSheet("font-size: 14px; font-family: B Nazanin")

    def DeleteMenu(self):
        btn = self.dlg.DeleteBtn
        btn.setIcon(QIcon(os.path.dirname(__file__) + '/main_delete.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        self.delete_all = menu.addAction("حذف همه عوارض", self.delete_all_func)
        self.delete_all.setIcon(QIcon(os.path.dirname(__file__) + '/delete_all.png'))
        # self.layer_delete = menu.addAction("حذف عوارض لایه ی انتخاب شده", self.delete_layers_func)
        # self.layer_delete.setIcon(QIcon(os.path.dirname(__file__) + '/delete.png'))
        self.changeDeleteBtnActivity(False)
        self.dlg.DeleteBtn.setMenu(menu)

    def deselect_all(self):
        """ Deselect every feature """
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, core.QgsVectorLayer):
                layer.removeSelection()

    def delete_layers_func(self):
        current_table_name = self.currentLayersListItem()
        layer = self.project.mapLayersByName(current_table_name)[0]
        reply = self.YesNoMessage('آیا از حذف عارضه های لایه ی انتخاب شده مطمئن هستید؟')
        if isinstance(layer, core.QgsVectorLayer):
            features = layer.selectedFeatures()
            features_id = [feature.id() for feature in features]
            if reply == QtWidgets.QMessageBox.Yes and features:
                layer.startEditing()
                layer.deleteFeatures(features_id)
                layer.triggerRepaint()
            self.deselect_all() 

    def YesNoMessage(self , message):
        messageBox = QtWidgets.QMessageBox()
        reply = messageBox.question(utils.iface.mainWindow(), 'اخطار', 
                message, QtWidgets.QMessageBox.Yes, QtWidgets.QMessageBox.No)
        return reply

    def delete_all_func(self):
        is_feature_selected = self.checkIsAnyLayer()
        if is_feature_selected:
            reply = self.YesNoMessage('آیا از حذف عارضه های لایه های انتخاب شده مطمئن هستید؟')
            for layer in self.all_layers:
                features_id = []
                if isinstance(layer, core.QgsVectorLayer):
                    features = layer.selectedFeatures()
                    features_id = [feature.id() for feature in features]
                    if reply == QtWidgets.QMessageBox.Yes and features:
                        layer.startEditing()
                        layer.deleteFeatures(features_id)
                layer.triggerRepaint()
            self.deselect_all() 

    def checkIsAnyLayer(self):
        for layer in self.all_layers:
            if isinstance(layer, core.QgsVectorLayer):
                features = layer.selectedFeatures()
                if features:
                    return True 
        self.msgBox('fail','عارضه ای انتخاب نشده است')
        return False

    def Help_Menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(os.path.dirname(__file__) + '/help.png'))
        menu = QMenu()
        self.setObjectFont(menu)
        i = menu.addAction("PDF", self.Action1)
        i.setIcon(QIcon(os.path.dirname(__file__) + '/pdfhelp.png'))
        z = menu.addAction("ویدیو", self.Action2)
        z.setIcon(QIcon(os.path.dirname(__file__) + '/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def Action1(self):
        self.Help_Btn()

    def Action2(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def Help_Btn(self):
        save_path = os.path.dirname(__file__) + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def fillSelectedLayer(self):
        self.clearList(self.dlg.layersList)
        self.setHeaderSizePolicy()
        for layer_id, layer in self.project.mapLayers().items():
            if isinstance(layer, core.QgsVectorLayer):
                # Get the selected features from the layer
                selected = layer.selectedFeatures()
                if selected:
                    self.all_layers.append(layer)
                    row_count = self.configRowCount(self.dlg.layersList)

                    layer_name = layer.name()
                    layer_count = str(len(selected))

                    name_item = QTableWidgetItem(layer_name)
                    count_item = QTableWidgetItem(layer_count)
                    
                    self.fillLayersListItem(row_count, name_item, count_item)

    def setHeaderSizePolicy(self):
        header = self.dlg.layersList.horizontalHeader()
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)

    def fillLayersListItem(self, row_count, name_item, count_item):
        self.setAlignment(name_item)
        self.dlg.layersList.setItem(row_count, 1, name_item)
        self.setAlignment(count_item)
        self.dlg.layersList.setItem(row_count, 0, count_item)


    def fillItemsOfLayer(self):
        self.changeDeleteBtnActivity(True)
        current_table_name = self.currentLayersListItem()
        layer = self.project.mapLayersByName(current_table_name)[0]
        if layer:
            self.setHorizontalLabel(layer)
            for feature in layer.selectedFeatures():
                row_count = self.configRowCount(self.dlg.itemsOfLayer)
                attributes = feature.attributes()
                for col , each_attr in enumerate(attributes):
                    item = QTableWidgetItem(str(each_attr))
                    self.setAlignment(item)
                    self.dlg.itemsOfLayer.setItem(row_count , col, item)

    def changeDeleteBtnActivity(self , is_active):
        self.delete_all.setEnabled(is_active)
        # self.layer_delete.setEnabled(is_active)

    def setAlignment(self, item):
        item.setTextAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignHCenter)

    def currentLayersListItem(self):
        current_row = self.dlg.layersList.currentRow()
        current_table_name = self.dlg.layersList.item(current_row , 1)
        return current_table_name.text()


    def setHorizontalLabel(self , layer):
        field_names = [field.displayName() for field in layer.fields()]
        self.clearList(self.dlg.itemsOfLayer)
        self.dlg.itemsOfLayer.setColumnCount(len(field_names))
        self.dlg.itemsOfLayer.setHorizontalHeaderLabels(field_names)

    def configRowCount(self , table_name):
        row_count = table_name.rowCount()
        table_name.setRowCount(row_count+1)
        return row_count

    def clearList(self , layer_name):
        layer_name.clearContents()  # Clear the table contents
        layer_name.setRowCount(0) 

    def buildLayerToGroupMapping(self, node, current_group=None):
        if node.nodeType() == 0:  # 0 indicates a layer node
            layer_name = node.name()
            if layer_name not in self.layer_to_group:
                self.layer_to_group[layer_name] = current_group
        elif node.nodeType() == 1:  # 1 indicates a group node
            current_group = node
        for child_node in node.children():
            self.buildLayerToGroupMapping(child_node, current_group)
