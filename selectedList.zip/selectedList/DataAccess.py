class DataAccess:

    def __init__(self, dbconn):
        self.db_conn = dbconn

