import sys, os, os.path
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from psycopg2.sql import NULL
import resources, gui
import pandas as pd
from DataAccess import DataAccess
import math

#========================================================

class EX_GUI(QtWidgets.QDialog):

    dataAccess = DataAccess()
    data = None

    def __init__(self):
        super().__init__()
        self.initUI()


    def initUI(self):

        self.ui = gui.Ui_Dialog()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':icons/gui_icons/app.png'))

        # if not self.dataAccess.getConnElect():
        #     self.msgUser('fail', 'در ارتباط با پایگاه داده مشکلی به وجود آمد.')
        #     exit()

        self.ui.chooseExcel.clicked.connect(self.importExcel)
        self.ui.submitData.clicked.connect(self.dataSubmitted)
        self.ui.chooseSchema.currentTextChanged.connect(self.updateTableCombo)
        self.ui.restart.clicked.connect(self.restart)

        self.updateWindow()

        self.show()


    def updateWindow(self):

        self.ui.chooseSchema.clear()
        self.ui.chooseSchema.addItems(self.dataAccess.getAllSchema())
        self.updateTableCombo()
        

    def updateTableCombo(self):
        self.ui.chooseTable.clear()
        print(self.ui.chooseSchema.currentText())
        table_list = self.dataAccess.getAllTables(self.ui.chooseSchema.currentText())
        self.ui.chooseTable.addItems(table_list)


    # Send a message to the user.
    def msgUser(self, type, msg = None):
        self.ui.footer.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.ui.footer.setText('لطفا صبر کنید ...')
            self.ui.footer.setStyleSheet('color: rgb(194, 71, 0)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    def importExcel(self):
        file = QtWidgets.QFileDialog.getOpenFileName(self, 'Open File', '', 'Excel (*.xls *.xlsx)')[0]
        if (file):
            self.msgUser('wait')
            self.ui.settings.setEnabled(True)
            self.ui.submitData.setEnabled(True)
            self.ui.restart.setEnabled(True)
            self.ui.input.setEnabled(False)
            self.data = pd.read_excel(file)
            self.updateSettings()
            self.msgUser('none')


    def updateSettings(self):

        tableName = self.dataAccess.getTableEn(self.ui.chooseTable.currentText())
        schemaName = self.ui.chooseSchema.currentText()
        tableKey = self.dataAccess.getKey(tableName)
        colsEn = self.dataAccess.getAllColNames(tableName,schemaName)
        colsFa = self.dataAccess.getAllFaCols(tableName,schemaName)
        colsFaEn = []
        for item in colsEn:
            if item in colsFa:
                colsFaEn.append(item + ' - ' + colsFa[item])
            else:
                colsFaEn.append(item)

        self.ui.tableFields.setRowCount(len(self.data.keys()))
        self.ui.tableFields.setColumnCount(3)
        self.ui.tableFields.setHorizontalHeaderItem(0, QtWidgets.QTableWidgetItem('ستون اکسل'))
        self.ui.tableFields.setHorizontalHeaderItem(1, QtWidgets.QTableWidgetItem('ستون جدول'))
        self.ui.tableFields.setHorizontalHeaderItem(2, QtWidgets.QTableWidgetItem('کلید'))
        ind = 0
        for key in self.data.keys():
            self.ui.tableFields.setItem(ind, 0, QtWidgets.QTableWidgetItem(key))
            colsCombo = QtWidgets.QComboBox(self)
            colsCombo.addItem('')
            colsCombo.addItems(colsFaEn)
            comboInd = 0
            try:
                comboInd = colsEn.index(key) + 1
            except:
                pass
            colsCombo.setCurrentIndex(comboInd)
            self.ui.tableFields.setCellWidget(ind, 1, colsCombo)
            rb = QtWidgets.QRadioButton('')
            if key == tableKey:
                rb.setChecked(True)
            self.ui.tableFields.setCellWidget(ind, 2, rb)
            ind += 1
        self.ui.tableFields.resizeColumnsToContents()
        self.colsEn = colsEn
        self.tableName = tableName
        self.schemaName = schemaName

    def dataSubmitted(self):

        self.msgUser('wait')

        conf = {}
        conf['keyCol'] = ''
        conf['colMap'] = {}
        conf['colMapInd'] = []
        
        model = self.ui.tableFields.model()
        for row in range(model.rowCount()):
            thisInd = self.ui.tableFields.cellWidget(row, 1).currentIndex()
            if thisInd != 0:
                conf['colMap'][model.data(model.index(row, 0))] = self.colsEn[thisInd - 1]
                conf['colMapInd'].append(self.colsEn[thisInd - 1])
            else:
                self.msgUser('fail', 'لطفا تمام اطلاعات لازم را پر کنید')
                return
            if self.ui.tableFields.cellWidget(row, 2).isChecked():
                conf['keyCol'] = self.colsEn[thisInd - 1]

        if not self.dataAccess.tableColIsUnique(self.tableName, conf['keyCol']):
            self.msgUser('fail', 'لطفا یک کلید مناسب انتخاب کنید')
            return

        values = self.data.values

        updatedKeys = {}
        updatedKeys['error'] = []
        updatedKeys['success'] = []
        updatedKeys['no change'] = []
        updatedKeys['no key'] = []
        
        for row in values:
            updateValues = {}
            key = None
            for idx, val in enumerate(conf['colMapInd']):
                if val != conf['keyCol']:
                    if row[idx] == '' or (not type(row[idx]) is str and math.isnan(float(row[idx]))):
                        updateValues[val] = None
                    else:
                        updateValues[val] = row[idx]
                else:
                    key = row[idx]
            res = self.dataAccess.updateTable(self.schemaName, self.tableName, conf['keyCol'], key, updateValues)
            if res == 'error':
                updatedKeys['error'].append(key)
            if res == 'success':
                updatedKeys['success'].append(key)
            if res == 'no change':
                updatedKeys['no change'].append(key)
            if res == 'no key':
                updatedKeys['no key'].append(key)

        self.msgUser('success', """اتمام عملیات

کلید های آپدیت شده: {}
کلید هایی که با خطا مواجه شدن: {}
کلید های بدون تغییر: {}
کلید هایی که وجود نداشتن: {}
""".format(updatedKeys['success'], updatedKeys['error'], updatedKeys['no change'], updatedKeys['no key']))

    def restart(self):
        self.ui.settings.setEnabled(False)
        self.ui.submitData.setEnabled(False)
        self.ui.restart.setEnabled(False)
        self.ui.input.setEnabled(True)
#========================================================

def main():
    app = QtWidgets.QApplication(sys.argv)
    ex = EX_GUI()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()