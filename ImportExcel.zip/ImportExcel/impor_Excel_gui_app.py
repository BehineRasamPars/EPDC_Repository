import os
from PyQt5 import QtWidgets
from .Import_Excel_Dialog import Import_Excel_Dialog
from qgis import utils
from .DataAccess import DataAccess
from qgis.PyQt.QtWidgets import QMenu
from .rassam import *
from .mylib import *
from psycopg2.sql import NULL
import math
import pandas as pd


class ImportExcel_GUI(QtWidgets.QMainWindow):
    def __init__(self, dbConn):
        super().__init__()
        self.queryMethod = DataAccess(dbConn)
        self.plugin_dir = os.path.dirname(__file__)
        self.first_start = None
        self.initUI()

    def initUI(self):
        self.first_start = True
        self.run()

    def initial_prep(self):
        return True

    def Help_menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(self.plugin_dir + '/icons/help.png'))
        menu = QMenu()
        z = menu.addAction("ویدیو", self.Action2)
        z.setIcon(QIcon(self.plugin_dir + '/icons/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def Action1(self):
        self.Help_Btn()

    def Action2(self):
        save_path = self.plugin_dir + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def Help_Btn(self):
        save_path = self.plugin_dir + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)

    def run(self):
        # Create the dialog with elements (after translation) and keep reference
        # Only create GUI ONCE in callback, so that it will only load when the plugin is started
        if self.first_start == True:
            self.first_start = False
            self.dlg = Import_Excel_Dialog()
            # self.helpMenu()
            self.checkTrigger()
            self.updateWindow()

        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            # Do something useful here - delete the line containing pass and
            # substitute with your code.
            pass

    def openPDF(self):
        filePath = self.addr + '\\user_help\\help.pdf'
        os.startfile(filePath)

    def openVideo(self):
        filePath = self.addr + '\\user_help\\help.mp4'
        os.startfile(filePath)

    def msgUser(self, type, msg=None):  # Send a message to the user.
        self.dlg.footer.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.dlg.footer.setText('لطفا صبر کنید ...')
            self.dlg.footer.setStyleSheet('color: rgb(194, 71, 0)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()

    def importExcel(self):
        file = QtWidgets.QFileDialog.getOpenFileName(
            self.dlg, 'Open File', '', 'Excel (*.xls *.xlsx)')[0]
        dir_path = os.path.dirname(file)
        self.queryMethod.conf['errorLogPath'] = dir_path + '\\excel_error.log'
        self.queryMethod.addNewHandler()
        if (file):
            self.msgUser('wait')
            self.dlg.settings.setEnabled(True)
            self.dlg.submitData.setEnabled(True)
            self.dlg.restart.setEnabled(True)
            self.dlg.input.setEnabled(False)
            self.data = pd.read_excel(file)
            self.updateSettings()
            self.msgUser('none')

    def updateSettings(self):
        transaction = self.dlg.chooseTransaction.currentText()
        # print(transaction)
        schemaName = self.dlg.chooseSchema.currentText()
        tableName = self.queryMethod.getTableEn(
            self.dlg.chooseTable.currentText())
        tableKey = self.queryMethod.getKey(tableName)
        colsEn = self.queryMethod.getAllColNames(tableName,schemaName)
        colsFa = self.queryMethod.getAllFaCols(tableName,schemaName)
        colsFaEn = []
        for item in colsEn:
            if item in colsFa:
                colsFaEn.append(item + ' - ' + colsFa[item])
            else:
                colsFaEn.append(item)

        self.dlg.tableFields.setRowCount(len(self.data.keys()))
        self.dlg.tableFields.setColumnCount(3)
        self.dlg.tableFields.setHorizontalHeaderItem(
            0, QtWidgets.QTableWidgetItem('ستون اکسل'))
        self.dlg.tableFields.setHorizontalHeaderItem(
            1, QtWidgets.QTableWidgetItem('ستون جدول'))
        self.dlg.tableFields.setHorizontalHeaderItem(
            2, QtWidgets.QTableWidgetItem('کلید'))
        ind = 0
        # print(self.data)
        for key in self.data.keys():
            self.dlg.tableFields.setItem(
                ind, 0, QtWidgets.QTableWidgetItem(key))
            colsCombo = QtWidgets.QComboBox(self.dlg)
            colsCombo.addItem('')
            colsCombo.addItems(colsFaEn)
            comboInd = 0
            try:
                comboInd = colsEn.index(key) + 1
            except:
                pass
            colsCombo.setCurrentIndex(comboInd)
            self.dlg.tableFields.setCellWidget(ind, 1, colsCombo)
            rb = QtWidgets.QRadioButton('')
            if key == tableKey:
                rb.setChecked(True)
            self.dlg.tableFields.setCellWidget(ind, 2, rb)
            ind += 1
        self.dlg.tableFields.resizeColumnsToContents()
        self.colsEn = colsEn
        self.tableName = tableName
        self.schemaName = schemaName

    def dataSubmitted(self):

        self.msgUser('wait')

        conf = {}
        conf['keyCol'] = ''
        conf['colMap'] = {}
        conf['colMapInd'] = []

        model = self.dlg.tableFields.model()
        for row in range(model.rowCount()):
            thisInd = self.dlg.tableFields.cellWidget(row, 1).currentIndex()
            if thisInd != 0:
                conf['colMap'][model.data(model.index(
                    row, 0))] = self.colsEn[thisInd - 1]
                conf['colMapInd'].append(self.colsEn[thisInd - 1])
            else:
                self.msgUser('fail', 'لطفا تمام اطلاعات لازم را پر کنید')
                return
            if self.dlg.tableFields.cellWidget(row, 2).isChecked():
                conf['keyCol'] = self.colsEn[thisInd - 1]

        if not self.queryMethod.tableColIsUnique(self.tableName, conf['keyCol'],self.schemaName):
            self.msgUser('fail', 'لطفا یک کلید مناسب انتخاب کنید')
            return

        values = self.data.values

        updatedKeys = {}
        updatedKeys['error'] = []
        updatedKeys['success'] = []
        updatedKeys['no change'] = []
        updatedKeys['added key'] = []
        transaction = self.dlg.chooseTransaction.currentText()
        for row in values:
            updateValues = {}
            key = None
            # print('colmapind {}'.format(conf['comMapInd']))
            for idx, val in enumerate(conf['colMapInd']):
                if val != conf['keyCol']:
                    if row[idx] == '' or (not type(row[idx]) is str and math.isnan(float(row[idx]))):
                        updateValues[val] = None
                    else:
                        updateValues[val] = row[idx]
                else:
                    key = row[idx]

            res = self.queryMethod.updateTable(self.schemaName,
                self.tableName, conf['keyCol'], key, updateValues, transaction)
            if res == 'error':
                updatedKeys['error'].append(key)
            elif res == 'success':
                updatedKeys['success'].append(key)
            elif res == 'no change':
                updatedKeys['no change'].append(key)
            elif type(res) == int:
                updatedKeys['added key'].append(res)

        self.queryMethod.disableLogger()
        self.msgUser('success', """اتمام عملیات

کلید های آپدیت شده: {}
کلید هایی که با خطا مواجه شدن: {}
کلید های بدون تغییر: {}
کلید هایی که اضافه شدند: {}
""".format(updatedKeys['success'], updatedKeys['error'], updatedKeys['no change'], updatedKeys['added key']))

    def restart(self):
        self.dlg.settings.setEnabled(False)
        self.dlg.submitData.setEnabled(False)
        self.dlg.restart.setEnabled(False)
        self.dlg.input.setEnabled(True)

    def checkTrigger(self):
        self.dlg.chooseExcel.clicked.connect(self.importExcel)
        self.dlg.submitData.clicked.connect(self.dataSubmitted)
        self.dlg.restart.clicked.connect(self.restart)
        self.dlg.chooseSchema.currentTextChanged.connect(self.updateTableCombo)

    def updateWindow(self):
        self.dlg.chooseSchema.clear()
        self.dlg.chooseSchema.addItems(self.queryMethod.getAllSchema())
        self.updateTableCombo()


    def updateTableCombo(self):
        self.dlg.chooseTable.clear()
        table_list = self.queryMethod.getAllTables(self.dlg.chooseSchema.currentText())
        self.dlg.chooseTable.addItems(table_list)
