import sys, os, os.path
import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
from .Import_Excel_Dialog import Import_Excel_Dialog
#========================================================

class DataAccess:
    conf = {}
    def __init__(self , dbConn):
        self.dbConn = dbConn
        self.setConf()

    # Get a connection to the database.
    def getConnElect(self):
        try:
            return self.dbConn.getConn()
        except Exception as e:
            logging.error(e)
            return False

    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'
        self.conf['errorLogPath'] = self.conf['mainPath'] + '\\excel_error.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')

    def updateConf(self):
        self.setConf()
        if self.conf['fileLogging']:
            logging.basicConfig(filename=self.conf['logPath'],
                format='%(asctime)s | %(levelname)s | %(message)s', level=logging.INFO)
        else:
            logging.disable()


    def getAllSchema(self):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT schema_name
                FROM information_schema.schemata
                WHERE schema_name NOT LIKE 'pg_%' AND schema_name != 'information_schema' and schema_name not like '%map%';
                """)
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            print(f'getAllSchema {e}')
            logging.error(e)
            return False

    def getAllTables(self, schema_name):
        try:
            cur = self.getConnElect().cursor()
            query = """
                    SELECT smtablename FROM smregister s inner join pg_catalog.pg_tables pt on s.smdatasetname = pt.tablename and pt.schemaname = '{}'
                    ORDER BY smtablename
                """.format(schema_name)
            cur.execute(query)
            result = cur.fetchall()
            if result is not None:
                rows = [r[0] for r in result]
                return rows
            return None
        except Exception as e:
            print(f'getAllTables {e}')
            logging.error(e)
            return False


    def addNewHandler(self):
        self.new_file_handler = logging.FileHandler(self.conf['errorLogPath'])
        self.new_file_handler.setLevel(logging.ERROR)

        # Create formatter for new file handler
        new_formatter = logging.Formatter('%(asctime)s %(name)s - %(levelname)s - %(message)s')
        self.new_file_handler.setFormatter(new_formatter)

        # Add new file handler to logger
        logger = logging.getLogger()
        logger.addHandler(self.new_file_handler)

    def getTableEn(self, nameFa):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    SELECT smdatasetname FROM smregister
                    WHERE smtablename = %s
                    LIMIT 1
                """)
            cur.execute(query, (nameFa,))
            data = cur.fetchone()[0]
            return data
        except Exception as e:
            logging.error(e)
            return False

    def disableLogger(self):
        logger = logging.getLogger()
        logger.removeHandler(self.new_file_handler)

    def getAllColNames(self, tableName, schema_name='public'):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                SELECT
                    column_name
                FROM
                    information_schema.columns
                WHERE
                    table_schema = %s
                    AND table_name = %s
                """, (schema_name,tableName))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False


    def getKey(self, tableName):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    SELECT a.attname
                    FROM   pg_index i
                    JOIN   pg_attribute a ON a.attrelid = i.indrelid
                                        AND a.attnum = ANY(i.indkey)
                    WHERE  i.indrelid = %s::regclass
                    AND    i.indisprimary
                """, (tableName,))
            data = cur.fetchone()[0]
            return data
        except Exception as e:
            logging.error(e)
            return False       


    def getAllFaCols(self, tableName, schema_name='public'):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            # cur.execute("""
            #     SELECT DISTINCT ON (c.column_name)
            #         c.column_name,
            #         s.smfieldcaption 
            #     from information_schema.tables t
            #     inner join information_schema.columns c on c.table_name = t.table_name 
            #                                     and c.table_schema = t.table_schema
            #     INNER JOIN smfieldinfo s ON (c.column_name = s.smfieldname)
            #     where 
            #         t.table_name = %s
            #         AND t.table_schema = 'public'
            #     """, (tableName,))
            cur.execute("""
                SELECT DISTINCT ON (c.column_name)
                    c.column_name,
                    s.field_fa 
                from information_schema.tables t
                inner join information_schema.columns c on c.table_name = t.table_name 
                                                and c.table_schema = t.table_schema
                INNER JOIN translate_table_fields s ON (c.column_name = s.field_en)
                where 
                    t.table_name = %s
                    AND t.table_schema = %s
                """, (tableName,schema_name))
            rows = cur.fetchall()
            names = {}
            for row in rows:
                names[row['column_name']] = row['field_fa']
            return names
        except Exception as e:
            logging.error(e)
            return False

    def compare_keys(self, updateValues_in, updateValues, tableValues):
        for key in tableValues.keys():
            if tableValues[key] == '':
                tableValues[key] = None
        for key in updateValues_in.keys():
            valsEqual = True
            if updateValues_in[key] != tableValues[key]:
                if is_number(updateValues_in[key]) and is_number(tableValues[key]):
                    if float(updateValues_in[key]) != float(tableValues[key]):
                        valsEqual = False
                else:
                    valsEqual = False
            if not valsEqual:
                updateValues[key] = updateValues_in[key]
        if not updateValues:
            return 'no change'

    def do_update(self, updateValues, enum_fields, updateValues_in, schemaName , tableName, keyCol, keyVal, cur, tableValues):
        compare_key = self.compare_keys(updateValues_in, updateValues, tableValues)
        if compare_key != 'no change':
            for k in updateValues.keys():
                if k in enum_fields:
                    new_value_of_enum = self.readEachEnumValues(k ,updateValues_in[k])
                    updateValues_in[k] = new_value_of_enum
            try:
                query = sql.SQL("UPDATE {schemaName}.{tableName} SET {data} WHERE {keyCol} = {keyVal}").format(
                    schemaName = sql.Identifier(schemaName),
                    tableName = sql.Identifier(tableName),
                    keyCol = sql.Identifier(keyCol),
                    data = sql.SQL(', ').join(
                        sql.Composed([sql.Identifier(k), sql.SQL(" = "), sql.Placeholder(k)]) for k in updateValues.keys()
                    ),
                    keyVal = sql.Placeholder('keyVal')
                )
                updateValues['keyVal'] = keyVal
                cur.execute(query, updateValues)
                return 'success'
            except Exception as e:
                logging.error(e)
                print(f'do_update {e}')
                return 'error'
        else:
            return compare_key
        
    def do_insert(self,schemaName, tableName, updateValues, keyVal, cur, updateValues_in, tableValues, unique_key_name):

        try:
            query = f"INSERT INTO {schemaName}.{tableName} ({', '.join(updateValues_in.keys())}) VALUES ({', '.join(['%s'] * len(updateValues_in))}) returning {unique_key_name};"
            # Execute the query with the provided data
            cur.execute(query,tuple(updateValues_in.values()))
            result = cur.fetchone()
            return result[unique_key_name]
        except Exception as e:
            logging.error(e)
            print(f'error{e}')
            return 'error'
        #else:
           # return compare_key
    
    #def search_keys(self, tableName, keyCol, keyVal, cur, updateValues):
        #try:
            #query = sql.SQL("""
                    #SELECT * FROM {} WHERE {} = %s
                #""").format(sql.Identifier(tableName), sql.Identifier(keyCol))
            #cur.execute(query, (keyVal,))
            #tableValues = cur.fetchall()
            # if tableValues:
            #     tableValues = tableValues[0]
            # else:
            
            
            # ye khoruji tru false az in begiram tu khod updatetable
            #if not tableValues:
                #self.do_insert(tableName, updateValues,  keyVal, cur)
                #return 'added key'
        #except Exception as e:
            #logging.error(e)
            #print(e)
            #return 'error'

    def updateTable(self, schema_name, tableName, keyCol, keyVal, updateValues_in, transaction):
        # be functionaled
        #
        #print('inside updateTable')
        updateValues = {}
        tableValues = {}
        #for a_key, a_val in updateValues_in:
        conn = self.getConnElect()
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        enum_fields = self.readEnumFieldOfTable(schema_name,tableName)
        conn = None
        is_update = False
        try:
            if keyCol is not None:
                query = sql.SQL("""
                        SELECT * FROM {}.{} WHERE {} = %s
                    """).format(sql.Identifier(schema_name),sql.Identifier(tableName), sql.Identifier(keyCol))
                cur.execute(query, (keyVal,))
                tableValues = cur.fetchall()
                if tableValues:
                    tableValues = tableValues[0]
                    is_update = True

        except Exception as e:
            logging.error(e)
            print(f'updateTable {e}')
            return 'error'
        if transaction == "افزودن و به روزرسانی":
            if is_update:
                return self.do_update(updateValues, enum_fields, updateValues_in, schema_name, tableName, keyCol, keyVal, cur, tableValues)
            else:
                return self.do_insert(schema_name, tableName, updateValues,  keyVal, cur, updateValues_in, tableValues, keyCol)
        if transaction == "به روزرسانی":
            if is_update:
                return self.do_update(updateValues, enum_fields, updateValues_in, schema_name, tableName, keyCol, keyVal, cur, tableValues)
            else:
                return 'error'
        if transaction == "افزودن":
            if not is_update :
                return self.do_insert(schema_name, tableName, updateValues,  keyVal, cur, updateValues_in, tableValues, keyCol)
            else:
                return 'error'
                # compare_key = self.compare_keys(updateValues_in, updateValues, tableValues)
                # if compare_key == 'no change':
                #     return compare_key

    def readEnumFieldOfTable(self, schema_name,table_name):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""SELECT attname FROM pg_attribute WHERE attrelid = (SELECT c.oid FROM pg_class c JOIN pg_namespace n ON c.relnamespace = n.oid WHERE c.relname = %s and n.nspname = %s) AND atttypid IN ( SELECT oid FROM pg_type WHERE typcategory = 'E');""")
            cur.execute(query , (schema_name,table_name,))
            data = cur.fetchall()
            return [result[0] for result in data]
        except Exception as e:
            print(f'readEnumFieldOfTable {e}')
            return False


    def readEachEnumValues(self, enum_name , enum_value):
        try:
            cur = self.getConnElect().cursor()
            query = """select enu.enumlabel
                            from information_schema.columns col
                            join information_schema.tables tab on tab.table_schema = col.table_schema
                                                            and tab.table_name = col.table_name
                                                            and tab.table_type = 'BASE TABLE'
                            join pg_type typ on col.udt_name = typ.typname
                            join pg_enum enu on typ.oid = enu.enumtypid
                            where col.table_schema not in ('information_schema', 'pg_catalog')
                                and typ.typtype = 'e' and col.column_name = '{enumName}'""".format(enumName = enum_name)
            cur.execute(query)
            data = cur.fetchall()
            final_result = [result[0] for result in data]
            all_word =  replace_per_name(enum_value)
            for each_value, word in zip(all_word, final_result):
                if all(ord(char1) == ord(char2) for char1 in each_value for char2 in word):
                    return each_value
        except Exception as e:
            print('to ini ?',e)
            return False

    def tableColIsUnique(self, tableName, colName,schemaName='public'):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    SELECT NOT EXISTS (
                        SELECT
                            {colName},
                            count(*)
                        FROM
                            {schemaName}.{tableName}
                        GROUP BY
                            {colName}
                        HAVING
                            count(*) > 1
                    )
                """).format(colName=sql.Identifier(colName), tableName=sql.Identifier(tableName),schemaName=sql.Identifier(schemaName))
            cur.execute(query)
            data = cur.fetchone()[0]
            return data
        except Exception as e:
            return False