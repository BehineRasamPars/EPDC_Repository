# General tools for my own use.

import sys, os, os.path
import time, datetime
import csv
import re


def replace_per_name(per_name):
    arr = []
    arr.append(per_name)
    arr.append(per_name.replace('\n','').replace('ی','ي').replace('ک','ك'))
    arr.append(per_name.replace('\n','').replace('ي','ی').replace('ک','ك'))
    arr.append(per_name.replace('\n','').replace('ي','ی') )
    arr.append(per_name.replace('\n','').replace('ک','ك'))
    arr.append(per_name.replace('\n','').replace('ی','ي') )
    arr.append(per_name.replace('\n','').replace('ك','ک') )
    arr.append(per_name.replace('\n','').replace('ي','ی').replace('ك','ک') )
    arr.append(per_name.replace('\n','').replace('ی','ي').replace('ك','ک') )
    return arr


def strToList(input, delimiter = ','):
    outList = []
    reader = csv.reader(input.split('\n'), delimiter=delimiter)
    for row in reader:
        outList = row
    outList = list(map(str.strip, outList))
    return outList


def listToStr(input, quoteWrap = False):
    if not quoteWrap:
        outStr = ','.join(input)
    else:
        outStr = ','.join(f"'{w}'" for w in input)
    return outStr


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


def is_number(n):
    if n is None:
        return False
    try:
        float(n)   # Type-casting the string to `float`.
                   # If string is not a valid `float`, 
                   # it'll raise `ValueError` exception
    except ValueError:
        return False
    return True


def password_check(password):
    """
    Verify the strength of 'password'
    Returns a dict indicating the wrong criteria
    A password is considered strong if:
        8 characters length or more
        1 digit or more
        1 symbol or more
        1 uppercase letter or more
        1 lowercase letter or more
    """

    # calculating the length
    length_error = len(password) < 8

    # searching for digits
    digit_error = re.search(r"\d", password) is None

    # searching for uppercase
    uppercase_error = re.search(r"[A-Z]", password) is None

    # searching for lowercase
    lowercase_error = re.search(r"[a-z]", password) is None

    # searching for symbols
    symbol_error = re.search(r"[ !#$%&'()*+,-./[\\\]^_`{|}~"+r'"]', password) is None

    # overall result
    password_ok = not ( length_error or digit_error or uppercase_error or lowercase_error or symbol_error )

    return {
        'password_ok' : password_ok,
        'length_error' : length_error,
        'digit_error' : digit_error,
        'uppercase_error' : uppercase_error,
        'lowercase_error' : lowercase_error,
        'symbol_error' : symbol_error,
    }


def customPassCheck(password):

    msg = ''
    ok = False

    fun_res = password_check(password)

    if fun_res['length_error']:
        msg = 'طول رمز عبور شما کوتاه است'
    elif fun_res['uppercase_error']:
        msg = 'لطفا در رمز عبور خود از حروف بزرگ هم استفاده کنید'
    elif fun_res['lowercase_error']:
        msg = 'لطفا در رمز عبور خود از حروف کوچک هم استفاده کنید'
    elif fun_res['digit_error']:
        msg = 'لطفا در رمز عبور خود از اعداد هم استفاده کنید'
    else:
        ok = True

    return {
        'ok': ok,
        'msg': msg
    }