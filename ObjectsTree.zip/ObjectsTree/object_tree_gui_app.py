import sys, os, os.path
import datetime, time
from typing import TYPE_CHECKING
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from qgis.PyQt.QtWidgets import QAction, QFileDialog
from .resources import *
import jdatetime
from PyQt5.QtWidgets import QApplication, QMainWindow, QTreeWidget , QMenu , QTreeWidgetItem, QStyledItemDelegate, QVBoxLayout, QWidget , QTabWidget
from qgis.PyQt.QtWidgets import QAction, QMenu, QGridLayout, QDockWidget, QWidget , QTabWidget, QStackedWidget
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from qgis.core import QgsProject, QgsFeatureRequest
from PyQt5.QtCore import pyqtSlot
# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .objects_tree_dialog import ObjectsTreeDialog
import pyplugin_installer
from qgis import utils
from .rassam import *
from qgis.utils import iface
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu , QStyledItemDelegate
from PyQt5.QtGui import QFontDatabase
from .utils import listToStr

class TabbedDockWidget(QDockWidget):
    def __init__(self):
        super().__init__("ابزار ها", iface.mainWindow())
        self.tab_widget = QTabWidget(self)
        self.setWidget(self.tab_widget)



class ObjectTree_GUI(QtWidgets.QMainWindow):
    def __init__(self , usePlugin):
        super().__init__()
        self.usePlugin = usePlugin
        self.plugin_dir = os.path.dirname(__file__)
        self.initUI()


    def initUI(self):
        self.dlg = ObjectsTreeDialog()
        self.mainwindow = utils.iface.mainWindow()
        self.triger_functions()
        self.run()

    def triger_functions(self):
        self.dlg.objectTree.itemExpanded.connect(self.item_expanded)
        self.dlg.objectTree.viewport().installEventFilter(self)
        self.dlg.objectTree.customContextMenuRequested.connect(self.generateMenu)

    def removePanel(self):
        iface.removeDockWidget(self.dock)
        
    def getConn(self):
        self.DBManager = self.usePlugin.dBConnection
        return self.DBManager.getConn()

    def getDbQuery(self):
        db_query = DBQuery(self.conn)
        return db_query

    def initial_prep(self):
        self.conn = self.getConn()
        self.setStyleForTree()

        self.fill_dist_name()
        self.addPanel()
        self.initial_msgBox()
        #self.Help_menu()
        return True

    def run(self):
        
        """Run method that performs all the real work"""
        prep = self.initial_prep()
        if prep is not False:
            # show the dialog
            # self.dlg.show()
            # Run the dialog event loop
            # result = self.dlg.exec_()
            # See if OK was pressed
            # if result:
            #     Do something useful here - delete the line containing pass and
            #     substitute with your code.
            pass

        #self.DBManager.closeConn()

        
    def Help_menu(self):
        x = self.dlg.HelpBtn
        x.setIcon(QIcon(self.plugin_dir + '/help.png'))
        menu = QMenu()
        z = menu.addAction("ویدیو" , self.Action2)
        z.setIcon(QIcon(self.plugin_dir + '/vidhelp.png'))
        self.dlg.HelpBtn.setMenu(menu)

    def Action1(self):
        self.Help_Btn()

    def Action2(self):
        save_path =self.plugin_dir + '/user_help'
        file_name = "help_vid.mp4"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)
        
    def Help_Btn(self):
        save_path =self.plugin_dir + '/user_help'
        file_name = "help_pdf.pdf"
        completeName = os.path.join(save_path, file_name)
        os.startfile(completeName)
    

    def item_expanded(self, item):
        self.sort_with_index(item)
        level = item.data(0, Qt.UserRole)
        function_mapping = {
            1: self.fill_hv_substat,
            2: self.fill_mv_feeder,
            3: self.fill_mdsub,
            4: self.fill_lv_feeder
        }
        function = function_mapping.get(level, lambda _: None)
        function(item)

    def sort_with_index(self , item , index=0):
        item.sortChildren(index, Qt.AscendingOrder) 

    def fill_dist_name(self):
        query_conn = self.getDbQuery()
        dist_name_list = query_conn.getDistName()
        # root_item = QTreeWidgetItem(self.dlg.objectTree, ["نام امور"])
        # root_item.setTextAlignment(0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.fill_children(self.dlg.objectTree , dist_name_list , 1)
        #utils.iface.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.dock)

    def fill_hv_substat(self , parent_item):
        #make query to get all hv_substat where dist_name is input dist_name and put it in hv_substat_list
        query_conn = self.getDbQuery()
        dist_name = parent_item.text(0) 
        self.clear_child_list(parent_item)
        hv_substat_list = query_conn.getHvSubstat(dist_name)
        icon_name = self.plugin_dir + '/icons/hv_substat.png'
        self.fill_children(parent_item , hv_substat_list , 2 , icon_name)

    def fill_mv_feeder(self , parent_item):
        query_conn = self.getDbQuery()
        hv_substat_name = self.getParentNameFromMultiPartName(parent_item.text(0)) 
        self.clear_child_list(parent_item)
        mv_feeder_list = query_conn.getMvFeeder(hv_substat_name)
        icon_name = self.plugin_dir + '/icons/mv_feeder.png'
        self.fill_children(parent_item , mv_feeder_list , 3 , icon_name)

    def fill_pl_mdsub(self , parent_item , feeder_name):
        query_conn = self.getDbQuery()
        self.clear_child_list(parent_item)
        pl_mdsub_list = query_conn.getPlMdsub(feeder_name)
        icon_name = self.plugin_dir + '/icons/pl_mdsub.png'
        self.fill_children(parent_item , pl_mdsub_list , 4 , icon_name)

    def fill_pd_mdsub(self , parent_item , feeder_name):
        query_conn = self.getDbQuery()
        self.clear_child_list(parent_item)
        pd_mdsub_list = query_conn.getPdMdsub(feeder_name)
        icon_name = self.plugin_dir + '/icons/pd_mdsub.png'
        self.fill_children(parent_item , pd_mdsub_list , 4 , icon_name)

    def fill_mdsub(self , parent_item):
        self.clear_child_list(parent_item)
        pd_parent = QTreeWidgetItem(parent_item, ['زمینی'])
        pl_parent = QTreeWidgetItem(parent_item, ['هوایی'])
        mv_feeder_name = self.getParentNameFromMultiPartName(parent_item.text(0)) 
        self.fill_pl_mdsub(pl_parent , mv_feeder_name)
        self.fill_pd_mdsub(pd_parent , mv_feeder_name)

    def fill_lv_feeder(self, parent_item):
        query_conn = self.getDbQuery()
        post_code = self.getParentNameFromMultiPartName(parent_item.text(0)) 
        self.clear_child_list(parent_item)
        lv_feeder_list = query_conn.getLvFeeder(post_code)
        icon_name = self.plugin_dir + '/icons/lv_feeder.png'
        self.fill_children(parent_item , lv_feeder_list , 0 , icon_name)

    def fill_children(self,parent_item , child_item_list , level , icon_name=None):
        child_item = None
        for each_children in child_item_list:
            final_name = self.checkFinalName(each_children)
            child_item = QTreeWidgetItem(parent_item, [final_name])
            child_item.setData(0, Qt.UserRole, level)
            if level:
                QTreeWidgetItem(child_item , [''])

            self.setIconForItem(child_item , icon_name)

        if child_item_list and level:
            QTreeWidgetItem(child_item , [''])
    
    def checkFinalName(self , name):
        final_name = name
        if type(name) is tuple:
            final_name = listToStr(name)
        return final_name

    def getParentNameFromMultiPartName(self , parent_name):
        return parent_name.split('-')[0].strip()

    def setIconForItem(self, child_item , icon_name):
            icon = QIcon(icon_name)  # Replace with the path to your icon file
            child_item.setIcon(0, icon)

    def clear_child_list(self, item):
        while item.childCount() > 0:
            child_item = item.takeChild(0)
            del child_item

    def setStyleForTree(self):
        self.dlg.objectTree.clear()
        self.dlg.objectTree.header().setDefaultAlignment(Qt.AlignRight|Qt.AlignVCenter)
        
    def getTableData(self , tree_data , item_value):
        if tree_data[0] == 'mdsub':
            if 'PL' in item_value:
                return 'pl_mdsub' , 'pl_mds_cod'
            return 'pd_mdsub' , 'ID'
        return tree_data[0] , tree_data[1]

    def showOnMapFunc(self):
        selected_items = self.dlg.objectTree.selectedItems()
        name_mapping = {
            1: ['hv_substat' , 'su_name'],
            2: ['mv_feeder' , 'name'],
            3: ['mdsub' , ''],
            -1: ['lv_feeder' , 'ID']
        }
        item_value = selected_items[0].text(0)
        userrole = selected_items[0].data(0, Qt.UserRole)
        if userrole in (0,1,2,3,4):
            level = selected_items[0].data(0, Qt.UserRole) - 1
            try:
                tree_data = name_mapping[level]
            except KeyError as e :
                self.msgUser('fail','لطفا سطر مناسب انتخاب کنید')
                return
            table_name , table_col = self.getTableData(tree_data , item_value)
            self.zoomto(table_name=table_name , table_col = table_col , value=item_value)

 
    def zoomto(self , table_name , table_col , value):
        try:
            layer = self.get_layer_by_tablename(table_name)
           
            layer.removeSelection()
            layer.selectByExpression(f'"{table_col}" = \'{value}\'')
            box = layer.boundingBoxOfSelected()
            box.grow(1)
            self.canvas = iface.mapCanvas()
            self.canvas.setExtent(box)
            self.canvas.setSelectionColor(QColor("red"))
            self.canvas.refresh()
        except Exception as e:
            print(e)
            
    def get_layer_by_tablename(self, tablename):
        layers = QgsProject.instance().mapLayers().values()
        if len(layers) == 0:
            return None
        layer = None
        for cur_layer in layers:
            uri_table = self.get_layer_source_table_name(cur_layer)
            if uri_table is not None and uri_table == tablename:
                layer = cur_layer
                break
        return layer

    def get_layer_source_table_name(self , layer):
        if layer is None:
            return None
        uri_table = None
        uri = layer.dataProvider().dataSourceUri().lower()
        pos_ini = uri.find('table=')
        pos_end_schema = uri.rfind('.')
        pos_fi = uri.find('" ')
        if pos_ini != -1 and pos_fi != -1:
            uri_table = uri[pos_end_schema+2:pos_fi]
        return uri_table
    
    def initial_msgBox(self):
        self.msgBox = QtWidgets.QMessageBox()
        self.msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
    def msgUser(self, type, msg=None):  # Send a message to the user.
        if type == 'success':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("موفقیت")
        elif type == 'fail':
            self.msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            self.msgBox.setText(msg)
            self.msgBox.setWindowTitle("شکست")
        result = self.msgBox.exec_()
        # QtWidgets.qApp.processEvents()

    def initialDock(self):
        self.dock = QDockWidget('درخت عوارض', utils.iface.mainWindow())
        self.dock.setWidget(self.dlg.objectTree)
        self.fill_dist_name()
        utils.iface.addDockWidget(QtCore.Qt.RightDockWidgetArea, self.dock)

    def addPanel(self):
        if not hasattr(self, 'tabbed_dock_widget'):
            self.tabbed_dock_widget = TabbedDockWidget()
            iface.addDockWidget(Qt.RightDockWidgetArea, self.tabbed_dock_widget)
        self.addOtherDockToTab()
        self.addCurrentDock()


    def addOtherDockToTab(self):
        self.mainwindow = utils.iface.mainWindow()
        right_dock_widgets = self.mainwindow.findChildren(QDockWidget)
        for dock_widget in right_dock_widgets:
            if self.mainwindow.dockWidgetArea(dock_widget) == Qt.RightDockWidgetArea and dock_widget.windowTitle() =='ابزار ترسیم':
                self.tabbed_dock_widget.tab_widget.addTab(dock_widget,dock_widget.windowTitle())

    def addCurrentDock(self):
        self.dock = QDockWidget(' ', self.tabbed_dock_widget)
        self.dock.setWidget(self.dlg.objectTree)  # Replace with your widget
        self.tabbed_dock_widget.tab_widget.addTab(self.dock,'درخت عوارض') 
        self.dock.setFloating(False)
        self.changeDockStyle()


    def eventFilter(self, source, event):
        if(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.dlg.objectTree.viewport()):
                item = self.dlg.objectTree.itemAt(event.pos())
                if item:
                    self.menu = QtWidgets.QMenu(self)
                    self.menu.addAction('انتخاب و نمایش بر روی نقشه', self.showOnMapFunc)
                    self.changeMenuStyle()
                else:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                
        return super(ObjectTree_GUI, self).eventFilter(source, event)

    def generateMenu(self, pos):
        self.menu.exec_(self.dlg.objectTree.mapToGlobal(pos))

    def changeMenuStyle(self):
        self.menu.setStyleSheet("font-family: B koodak; font-size: 12px;")

    def changeDockStyle(self):
        self.dlg.objectTree.setStyleSheet("font-family: B koodak; font-size: 14px;")
        self.tabbed_dock_widget.tab_widget.tabBar().setStyleSheet("font-family: B koodak; font-size: 16px;")
