def listToStr(iterator):
    return_str = ' | '.join(map(str, iterator))
    return return_str

def getFirstItemOfStr(iterator):
    return_str = iterator.split(' | ')
    if return_str:
        return return_str[0]
    return iterator
