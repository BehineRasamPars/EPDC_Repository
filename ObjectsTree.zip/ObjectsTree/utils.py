def listToStr(iterator):
    return_str = ' - '.join(map(str, iterator))
    return return_str
