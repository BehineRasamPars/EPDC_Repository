import qgis
from qgis import utils
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu
import pyplugin_installer
import subprocess
import sys, os, os.path
import configparser
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import psycopg2
from psycopg2 import sql
from qgis.gui import QgsLayerTreeViewMenuProvider
from qgis.core import QgsDataSourceUri, QgsCredentials, QgsProject, QgsExpressionContextUtils
#===========================================================

class DBConnection:

    loginData = qgis.core.QgsDataSourceUri()
    conn = None

    def __init__(self, host, port, dbName):
        self.loginData.setConnection(host, port, dbName, None, None, 1)

    def __del__(self):
        self.closeConn()

    def getConnIfValid(self, username, password):
        try:
            conn = psycopg2.connect(user = username,
                                  password = password,
                                  host = self.loginData.host(),
                                  port = self.loginData.port(),
                                  dbname = self.loginData.database())
            conn.autocommit = True
            return conn
        except Exception as e:
            print(e)
            return False

    # return connection if success; else None.
    def getConn(self):
        if (not self.conn):
            connInfo = self.loginData.connectionInfo()
            inUser = None
            inPass = None
            success = True
            while (success):
                (success, inUser, inPass) = QgsCredentials.instance().get(connInfo, inUser, inPass)
                conn = self.getConnIfValid(inUser, inPass)
                if (conn):
                    QgsCredentials.instance().put(connInfo, inUser, inPass)
                    self.validData = True
                    self.loginData.setUsername(inUser)
                    self.loginData.setPassword(inPass)
                    self.conn = conn
                    break
        return self.conn

    # return username if a valid one entered. None otherwise.
    def getUsername(self):
        return self.loginData.username()
        
    def getHost(self):
        return self.loginData.host()
        
    def getPass(self):
        return self.loginData.password()
        
    def closeConn(self):
        if (self.conn):
            self.conn.close()
            self.conn = None

# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


class UsePlugin:

    pluginName = None
    updateChecked = False
    projVals = {}

    def __init__(self):
        dirName = os.path.basename(getAppDir())
        self.pluginName = dirName


    def update(self):
        if not self.updateChecked:
            pyplugin_installer.instance().fetchAvailablePlugins(False)
            pyplugin_installer.instance().upgradeAllUpgradeable()
            self.updateChecked = True
            mypluginInstance = utils.plugins[self.pluginName]
            mypluginInstance.run()
            return True
        else:
            return False


    def projVariables(self):
        variables = {}
        project = qgis.core.QgsProject.instance()
        variables['host'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('host')
        variables['dbname'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('dbname')
        variables['port'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('port')        
        variables['version'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('version')
        variables['url_port'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('url_port')
        variables['db_host'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('db_host')
        if variables['db_host'] is None:
            variables['db_host'] = variables['host']
        if variables['url_port'] is None:
            variables['url_port'] = '80'
        variables['ssl'] = 'http' if variables['url_port'] == '80' else 'https'
        # if None in variables.values():
        #    return False
        return variables


    def checkProjVariables(self):

        projVals = self.projVariables()
        self.projVals = projVals

        if not projVals:
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "متغیر های پروژه به درستی تنظیم نشده اند."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return False
        else:
            return projVals


    def isUserAllowed(self):
        dBConnection = DBConnection(self.projVals['db_host'], self.projVals['port'], self.projVals['dbname'])
        conn = dBConnection.getConn()
        
        if dBConnection.getUsername():
            if dBConnection.getUsername() in [ 'serveradmin', 'postgres', 'rassam' ]:
                return True
            cur = conn.cursor()
            cur.execute("""
                    SELECT
                        *
                    FROM
                        public.plugin_role
                    INNER JOIN (
                            SELECT
                                r.rolname as username, r1.rolname as "role"
                            FROM
                                pg_catalog.pg_roles r
                            LEFT JOIN pg_catalog.pg_auth_members m ON (m.member = r.oid)
                            LEFT JOIN pg_roles r1 ON (m.roleid = r1.oid)
                            WHERE
                                r1.rolname = %s OR r.rolname = %s
                        ) AS table1
                        ON (public.plugin_role.role = table1.role OR public.plugin_role.role = table1.username)
                    WHERE plugin = %s
                """, (dBConnection.getUsername(), dBConnection.getUsername(), self.pluginName))
            if cur.fetchall():
                return True
        return False


    def checkUserAllowed(self):
        user_allowed=self.isUserAllowed()
        if not user_allowed:
            return False
        else:
            return True


    # Edit this according to your needs:
    def checkAll(self):
        
        if self.update():
            return False
        
        if not self.checkProjVariables():
            return False
        
        if not self.checkUserAllowed():
            return False

        return True

    def getValue(self, name):
        if name == 'qgis_proj':
            return self.projVals['host'] + ':' + self.projVals['url_port'] + '/QGIS_Proj/'
        elif name == 'host':
            return self.projVals['host']
        elif name == 'dbname':
            return self.projVals['dbname']
        elif name == 'port':
            return self.projVals['port']
        elif name == 'version':
            return self.projVals['version']
        elif name == 'rep_addr':
            return self.projVals['host']  + ':' + self.projVals['url_port'] + '/plugins/'
        elif name == 'ssl':
            return self.projVals['ssl'] + '://'
        elif name == 'db_host':
            return self.projVals['db_host'] 


class DBQuery:

    def __init__(self, dbconn):
        self.db_conn = dbconn

    
    def getDistName(self):
        cursor = self.db_conn.cursor()
        try:
            query = 'select pd_rgn_nam from pow_distr_rigo_boundary order by pd_rgn_nam'
            cursor.execute(query)
            result = cursor.fetchall()
            final_result = list(map(lambda x: x[0], result))
            return final_result
        except Exception as e :
            print(e)
            return None


    def getHvSubstat(self , dist_name):
        cursor = self.db_conn.cursor()
        try:
            query = """select su_name || ' | ' || COALESCE(dispa_code,' ') from hv_substat where dist_name = '{}'""".format(dist_name)
            cursor.execute(query)
            result = cursor.fetchall()
            # final_result = list(map(lambda x: x[0], result))
            return result
        except Exception as e :
            print(e)
            return None

    def getMvFeeder(self , hv_substat_name):
        cursor = self.db_conn.cursor()
        try:
            query = """select mf.name || ' | (' || COALESCE(feeder_code,' ') || ')' from mv_feeder mf inner join hv_substat hs on st_intersects(mf.smgeometry , st_buffer(hs.smgeometry,10))  where su_name = '{}' order by mf.name""".format(hv_substat_name)
            #query = """select name from mv_feeder mf inner join hv_substat hs on mf.base_code = hs."ID" where su_name = '{}'""".format(hv_substat_name)
            cursor.execute(query)
            result = cursor.fetchall()
            # final_result = list(map(lambda x: x[0], result))
            return result
        except Exception as e :
            print(e)
            return None

    def getPlMdsub(self , feeder_name):
        cursor = self.db_conn.cursor()
        try:
            query = """select pl_mds_cod ||' | '|| loc_cod || ' : ' || COALESCE(total_capacity,0) || ' kva' from pl_mdsub where feeder_name = '{}'""".format(feeder_name)
            cursor.execute(query)
            result = cursor.fetchall()
            # final_result = list(map(lambda x: x[0], result))
            return result
        except Exception as e :
            print(e)
            return None

    def getPdMdsub(self , feeder_name):
        cursor = self.db_conn.cursor()
        try:
            query = """select "ID"||' | '|| loc_cod || ' : ' || COALESCE(total_capacity,0) || ' kva' from pd_mdsub where feeder_name = '{}'""".format(feeder_name)
            cursor.execute(query)
            result = cursor.fetchall()
            # final_result = list(map(lambda x: x[0], result))
            return result
        except Exception as e :
            print(e)
            return None

    def getLvFeeder(self , post_id):
        cursor = self.db_conn.cursor()
        try:
            query = self.create_mdsub_query(post_id)
            cursor.execute(query)
            result = cursor.fetchall()
            final_result = list(map(lambda x: x[0], result))
            return final_result
        except Exception as e :
            print(e)
            return None
    
    def create_mdsub_query(self , post_id):
        if 'PL' in post_id:
            query = """select "ID" from lv_feeder lf inner join pl_mdsub pl on st_intersects(lf.smgeometry , st_buffer(pl.smgeometry,10)) where pl.pl_mds_cod = '{}'""".format(post_id)
            return query
        query = """select lf."ID" from lv_feeder lf inner join pd_mdsub pd on st_intersects(lf.smgeometry , st_buffer(pd.smgeometry,10)) where pd."ID" = '{}'""".format(post_id)
        return query 

    


