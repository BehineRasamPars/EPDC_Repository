# General tools for my own use.

import sys, os, os.path
import csv



def strToList(input, delimiter = ','):
    outList = []
    reader = csv.reader(input.split('\n'), delimiter=delimiter)
    for row in reader:
        outList = row
    outList = list(map(str.strip, outList))
    return outList


def listToStr(input, quoteWrap = False):
    if not quoteWrap:
        outStr = ','.join(input)
    else:
        outStr = ','.join(f"'{w}'" for w in input)
    return outStr


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path
